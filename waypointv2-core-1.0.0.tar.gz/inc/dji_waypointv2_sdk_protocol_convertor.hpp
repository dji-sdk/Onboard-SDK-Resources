//
//  dji_waypointv2_sdk_protocol_convertor.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 03/07/2018.
//

#ifndef dji_waypointv2_sdk_protocol_convertor_hpp
#define dji_waypointv2_sdk_protocol_convertor_hpp

#include <stdio.h>
#include "dji_waypointv2_protocol_struct_defines.hpp"
#include "proto/WaypointV2.pb.h"
#include <log/djicommonlogsystemprovider.hpp>


#define WAYPOINT_V2(fmt, ...)\
LogCenterProvider::GetInstance().INFOLog(fmt, ##__VA_ARGS__)

#ifndef RADIAN
#define RADIAN(x) ((double)(x)*M_PI/180.0)
#endif

#ifndef DEGREE
#define DEGREE(x) ((double)(x)*180.0/M_PI)
#endif

namespace dji {
	namespace waypointv2 {
		
		class WaypointMission;
        
		template<typename T>
		T *moveToNewObj(T &&t) {
			T *newObj = new T(std::forward<T>(t));
			return newObj;
		}
        
        const LocationCoordinate &kInvalidLocationCoordinate();
		
        class DataConverter {
        public:
            //Check location valid
            static bool LocationCoordinateIsValid(const LocationCoordinate &coordinate);
            
            static ProtocolRelativeLocation CalculateRelativePosition(const LocationCoordinate& reference_location, const LocationCoordinate& absolute_location);
            static LocationCoordinate CalculateAbsolutePosition(const LocationCoordinate& reference_location, const ProtocolRelativeLocation& relative_location);
            
            static dji_fc2_set_API_WP2_MISSION_INIT_req ConvertSDKInitializationMissionToProtocol(const std::shared_ptr<WaypointMission> mission);
            static std::shared_ptr<WaypointMission>  ConvertProtocolInitializationMissionToSDK(const dji_fc2_set_API_WP2_MISSION_INIT_req& init_data);
            
            static void* ConvertWaypointsInformationToProtocol(const std::shared_ptr<WaypointMission> mission, int start_index, int max_end_index, int max_bytes_size, int& out_end_index, int& out_length);
            static void ConvertProtocolWaypointMissionToSDK(std::shared_ptr<WaypointMission> mission, const ProtocolDownloadListData* waypoints_data, const LocationCoordinate& ref_location);
			
            static void* ConvertSDKActionsToProtocol(const std::vector<WaypointActionConfig>& action_configs, int start_index, int end_index, int max_bytes_length, int &out_end_index, int& output_length);
            static std::vector<WaypointActionConfig> ConvertProtocolActionsToSDK(void* action_datas, int data_length);
			static void* ConvertOneSDKActionsToProtocol(const WaypointActionConfig& one_action_config, int& output_length);
			
			static ProtocolBreakRestoreType ConvertSDKInterruptTypeToProtocol(InterruptRecoverAction interrupt_action);
			static InterruptRecoverAction ConvertProtocolInterruptTypeToSDK(ProtocolBreakRestoreType interrupt_type);
			
			static ProtocolWaypointType ConvertSDKWaypointTypeToProtocol(WaypointType input_type);
			static WaypointType ConvertProtocolWaypointTypeToSDK(ProtocolWaypointType input_type);
            static ExecuteState ConvertProtocolExecuteStateToSDK(ProtocolExecuteState protocol_exec_state);
			static uint16_t ConvertVersionFromStringToInt(const std::string& version);
			static std::string ConvertVersionFromIntToString(uint16_t version);
        private:
			
			static uint16_t GetWaypointActuatorFunctionID(const WaypointActionConfig& action_config);
			
            static void* ConvertSDKOneWaypointToProtocol(const WaypointItem& waypoint, int& out_length, const LocationCoordinate & ref_location);
			
            static void* GetWaypointTriggerData(const WaypointActionConfig& action_config, int& output_lengt);
            
            static void* GetWaypointActuatorData(const WaypointActionConfig& action_config, int& output_lenth);
            
            static ProtocolTriggerType GetProtocolTriggerType(WaypointActionTriggerType type);
            
            static ProtocolActuatorType GetProtcolActuatorType(WaypointActionActuatorType type);
            
            static WaypointActionConfig ConvertOneProtocolActionToSDK(void* action_datas, int& data_offset, int& data_length);
            
            static WaypointActionTriggerType GetSDKTriggerType(ProtocolTriggerType type);
            
            static WaypointActionActuatorType GetSDKActuatorType(ProtocolActuatorType type);
            
            static GimbalActionType GetSDKGimbalActionFunctionID(uint16_t functionID);
            
            static SprayActionType GetSDKSprayActionFunctionID(uint16_t functionID);
                        
            static CameraActionType GetSDKCameraActionFunctionID(uint16_t functionID);
			
			static AircraftControlActionType GetSDKAircraftControlActionFunctionID(uint16_t functionID);
        };
	}
}


#endif /* dji_waypointv2_sdk_protocol_convertor_hpp */
