//
//  djiwaypointv2workermanager.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djiwaypointv2workermanager_hpp
#define djiwaypointv2workermanager_hpp

#include <stdio.h>
#include <3rdparty/include/djicommonworker.h>

#define DISPATCH_TO_WORK_QUEUE(callback, ...)\
ModuleManager::GetInstance().GetWorkerManager().work_queue_->enqueue([callback, __VA_ARGS__](){\
if (callback) {\
callback(__VA_ARGS__);\
}\
})

#define NULL_LOGIC_WORKER_RETURN \
if (ModuleManager::GetInstance().GetWorkerManager().work_queue_ == nullptr) {\
return;\
}

namespace dji {
	namespace waypointv2 {
		using namespace common;
		class WorkerManager {
		public:
			static WorkerManager &GetInstance();
			std::shared_ptr<Worker> work_queue_;
		private:
			WorkerManager();
			~WorkerManager();
		};
	}
}

#endif /* djiwaypointv2workermanager_hpp */
