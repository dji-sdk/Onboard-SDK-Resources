//
//  djicommondeviceeventdispatcher.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 08/05/2018.
//

#ifndef djicommondeviceeventdispatcher_hpp
#define djicommondeviceeventdispatcher_hpp

#include <stdio.h>
#include <set>
#include "djicommoncommondefines.hpp"

namespace dji {
	namespace common {
		//这个类只负责通知状态改变，具体当前状态应该通过 DeviceStateProvider 去拿。
		
		class IDeviceEventDispatcherListener {
		public:
            IDeviceEventDispatcherListener() {};
            virtual ~IDeviceEventDispatcherListener() {};
			virtual void HandleDeviceStateChange(uint64_t device_id, DeviceEvent event) = 0;
		};
		
		//其他模块应该Add Listener 到dispatcher就可以了。
		class DeviceEventDispatcher {
		public:
			DeviceEventDispatcher(const DeviceEventDispatcher&) = delete;
			DeviceEventDispatcher& operator=(const DeviceEventDispatcher&) = delete;
			static DeviceEventDispatcher& GetInstance();
			//SharedLib调用这个方法，由这个方法来派发。
			void OnDeviceStateChange(uint64_t device_id, DeviceEvent event);
			//不加Remove, 这是一个工程配置相关类。一个工程配置一个总的Listener，自己去派发。
			void AddListener(IDeviceEventDispatcherListener* listener);
		protected:
			virtual ~DeviceEventDispatcher() {};
			DeviceEventDispatcher(){};
		private:
			std::set<IDeviceEventDispatcherListener*> listeners_;
		};
	}
}


#endif /* djicommondeviceeventdispatcher_hpp */
