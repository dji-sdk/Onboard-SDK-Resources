//
//  djicommondevicestateprovider.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 07/05/2018.
//

#ifndef djicommondevicestateprovider_hpp
#define djicommondevicestateprovider_hpp

#include "djicommoncommondefines.hpp"
#include <stdio.h>

namespace dji {
	namespace common {
		//此类用于拿上层一些设备状态的接口类
		class DeviceStateProvider {
			public:
			DeviceStateProvider(const DeviceStateProvider&) = delete;
			DeviceStateProvider& operator=(const DeviceStateProvider&) = delete;
			static DeviceStateProvider& GetInstance();
			
			virtual bool IsDeviceIsOsmo(uint64_t device_id) const;
			virtual DroneType GetDeviceDroneType(uint64_t device_id) const;
            virtual RCDroneType GetDeviceRCDroneType(uint64_t device_id) const;
            virtual bool IsDeviceSupportNavigationMode(uint64_t device_id) const;
			
			virtual bool IsDeviceConnected(uint64_t device_id) const;
			virtual RCMode GetDeviceRCMode(uint64_t device_id) const;
			virtual std::string GetDeviceSerialNumber(uint64_t device_id) const;
			virtual bool IsDeviceMotorOn(uint64_t device_id) const;
			virtual bool IsDeviceSupportGEO(uint64_t device_id) const;
			virtual int GetDeviceMCProtocolVersion(uint64_t device_id) const;
			virtual bool IsDeviceUseDJIFlightDB(uint64_t device_id) const;
			virtual bool IsDeviceSupportDynamicDB(uint64_t device_id) const;
			virtual bool IsDeviceUseLicenseUnlock(uint64_t device_id) const;
			virtual bool IsDeviceInGoHomeMode(uint64_t device_id) const;
			virtual bool IsDeviceInSmartMode(uint64_t device_id) const;
			virtual std::vector<uint64_t> GetDeviceUnlockAreaIds(uint64_t device_id) const;
            virtual Location GetDeviceLocation(uint64_t device_id) const;
			virtual ProductType GetDeviceProductType(uint64_t device_id) const;
			virtual bool IsDeviceSupportWPV2(uint64_t device_id) const;
			//handle
			void SetIsDeviceConnectedHandle(ReturnDeviceBoolValueHandle handle);
			void SetDeviceRCModeHandle(ReturnDeviceRCModeValueHandle handle);
			void SetDeviceSerialNumberHandle(ReturnDeviceStringValueHandle handle);
			void SetDeviceMotorOnHandle(ReturnDeviceBoolValueHandle handle);
			void SetIsDeviceSupportGEOHandle(ReturnDeviceBoolValueHandle handle);
			void SetDeviceMCProtocolVersionHandle(ReturnDeviceIntValueHandle handle);
			
			void SetIsDeviceUseDJIFlightDBHandle(ReturnDeviceBoolValueHandle handle);
			void SetIsDeviceSupportDynamicDBHandle(ReturnDeviceBoolValueHandle handle);
			void SetIsDeviceUseLicenseUnlockHandle(ReturnDeviceBoolValueHandle handle);
			void SetIsDeviceInGoHomeModeHandle(ReturnDeviceBoolValueHandle handle);
			void SetIsDeviceInSmartModeHandle(ReturnDeviceBoolValueHandle handle);
			void SetDeviceUnlockAreaIdsHandle(ReturnDeviceIntVectorValueHandle handle);
			
			void SetIsDeviceIsOsmoHandle(ReturnDeviceBoolValueHandle handle);
			void SetDeviceDroneTypeValueHandle(ReturnDeviceDroneTypeValueHandle handle);
            void SetDeviceRCDroneTypeValueHandle(ReturnDeviceRCDroneTypeValueHandle handle);
			void SetIsDeviceSupportNavigationModeHandle(ReturnDeviceBoolValueHandle handle);
			void SetDeviceProductTypeValueHandle(ReturnDeviceProductTypeValueHandle handle);
			void SetDeviceLocationHandle(ReturnDeviceLocationValueHandle handle);
			void SetIsSupportWPV2Handle(ReturnDeviceBoolValueHandle handle);
        protected:
			virtual ~DeviceStateProvider() {};
			DeviceStateProvider(){};
			private:
			ReturnDeviceBoolValueHandle is_device_connected_handle_;
			ReturnDeviceRCModeValueHandle get_device_rc_mode_handle_;
			ReturnDeviceStringValueHandle get_device_serial_number_handle_;
			ReturnDeviceBoolValueHandle get_device_motor_on_handle_;
			ReturnDeviceBoolValueHandle is_device_support_geo_handle_;
			ReturnDeviceIntValueHandle get_device_mc_protocol_version_handle_;
			ReturnDeviceBoolValueHandle is_device_use_dji_flight_db_handle_;
			ReturnDeviceBoolValueHandle is_device_support_dynamic_db_handle_;
			ReturnDeviceBoolValueHandle is_device_use_license_unlock_handle_;
			ReturnDeviceBoolValueHandle is_device_in_go_home_handle_;
			ReturnDeviceBoolValueHandle is_device_in_smart_mode_handle_;
			ReturnDeviceIntVectorValueHandle get_device_unlock_area_ids_handle_;
			ReturnDeviceBoolValueHandle is_device_is_osmo_handle_;
			ReturnDeviceDroneTypeValueHandle	get_device_drone_type_handle_;
            ReturnDeviceRCDroneTypeValueHandle get_device_rc_drone_type_handle_;
			ReturnDeviceBoolValueHandle	is_device_support_navigation_mode_handle;
			ReturnDeviceProductTypeValueHandle get_device_product_type_handle_;
			ReturnDeviceLocationValueHandle get_device_location_handle_;
			ReturnDeviceBoolValueHandle	is_device_is_support_wpv2_handle_;
		};
	}
}


#endif /* djicommondevicestateprovider_hpp */
