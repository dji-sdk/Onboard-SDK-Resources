//
//  dji_waypointv2_sdk_error.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 10/05/2018.
//

#ifndef dji_waypointv2_sdk_error_hpp
#define dji_waypointv2_sdk_error_hpp

#include <cstdint>

namespace dji {
	namespace waypointv2 {
		enum AbstractErrorCode {
			
			NoError = 0,
			//SDK 内部错误，参数检查， 根据飞机回包，飞控返回数据等获取。
			CommandCanNotExecute = -1,
			CommandExecutionFailed = -2,
			InvalidParameters = -3,
			Timeout = -4,
            ProdcutConnectFailed = -5,
            SystemBusy = -6,
            OperationCancelByUser = -7,
            
			//以下都是飞控会返回的错误
			//Common 错误
			InvalidInputDataFCLength = -1001,
			InvalidInputDataFloatNumber = -1002,
			
			//Mission 航线执行相关错误
			InitMissionCountOverRange = -2001,
			InitMissionCountTooLess = -2002,
			InitMissionEndIndexInvalid = -2003,
			InitMissionGlobalMaxSpeedInvalid = -2004,
			InitMissionCruiseSpeedInvalid = -2005,
			InitMissionGotoFirstWaypointInvalid = -2006,
			InitMissionFinishedActionInvalid = -2007,
			InitMissionRCLostControlActionInvalid = -2008,
			InitMissionReferenceLocationInvalid = -2009,
			InitMissionExistRunning = -2010,
			UploadMissionIndexInvalid = -2011,
			UploadMissionCountOverInitTotalCount = -2012,
			UploadMissionStartIndexNotInEndOfLastUpload = -2013,
			UploadMissionDistanceTooClose = -2014,
			UploadMissionDistanceToFar = -2015,
			UploadMissionMaxCruiseSpeedOverGlobalMaxSpeed = -2016,
			UploadMissionCruiseSpeedOverLocalMaxSpeed = -2017,
			UploadMissionCruiseSpeedOverGlobalMaxSpeed = -2018,
			UploadMissionYawModeInvalid = -2019,
			UploadMissionYawControlDegreeInvalid = -2020,
			UploadMissionYawControlDirectionInvalid = -2021,
			UploadMissionWaypointTypeInvalid = -2022,
			UploadMissionDampingDistanceInvalid = -2023,
			UploadMissionCannotSetExitLineType = -2024,
			UploadMissionIndexNotContinue = -2025,
			UploadMissionEnterLineTypeSetToStartPointInvalid = -2026,
			UploadMissionDampingInvalid = -2027,
			UploadMissionCoordinateInvalid = -2028,
            FirstWaypointTypeInvalid = -2029,
            MissionFlyingRadiusLimit = -2030,
            MissionFlyingHeightLimit = -2031,
			MissionVersionNotMatched = -2032,
            
            //下载相关
			DownloadMissionRangeOverStorageCount = -3001,
			DownloadMissionNotInitialized = -3002,
			DownloadMissionNotUploaded = -3003,
            
            //执行相关
			MissionControlStartCurrentPointToFirstPointTooFar = -4001,
			MissionControlStartStopInvalid = -4002,
			MissionControlPauseResumeInvalid = -4003,
			MissionControlInterruptRecoverInvalid = -4004,
			MissionControlUploadedPointTooLess = -4005,
			MissionControlStartedNoInRunning = -4006,
			MissionControlAlreadyStarted = -4007,
			MissionControlAlreadyStopped = -4008,
			MissionControlMissionAlreadyPaused = -4009,
			MissionControlNoRunningMissionForResume = -4010,
			MissionControlNoRunningMissionForRecover = -4011,
			MissionControlAlreadyInterrupt = -4012,
			MissionControlNotSupportPauseResume = -4013,
			MissionControlNotSupportInterruptResume = -4014,
			MissionControlBreakPointNotRecord = -4015,
			MissionControlProjectionPointNotInCurrentWaypointLine = -4016,
			MissionControlProjectionPointNotNextWaypointLine = -4017,
			MissionControlProjectionPointNotNextNextWaypointLine = -4018,

			//飞机状态检查错误
			MissionStateAircraftFlyingStatusBad = -5001,
			MissionStateHomePointNotRecord = -5002,
			MissionStateGPSSignalWeak = -5003,
			MissionStateRTKNotReady = -5004,
			
			//飞机安全状态错误
			MissionSecureStateNFZZoneCross = -6001,
			MissionSecureStateAircraftLowBattery = -6002,
			
			//Action Common错误
			UploadActionIDDuplicated = -7001,
			UploadActionItemsSpaceNotEnough = -7002,
			UploadActionBufferNotEnough = -7003,
			DownloadActionIDNotFound = -7004,
			DownloadActionIDOverRange = -7005,
			DownloadActionNoActionStored = -7006,
            
			//触发器Common错误
			UploadActionTriggerTypeInvalid = -8001,
			UploadActionTriggerReachEndIndexLessStartIndex = -8002,
			UploadActionTriggerReachIntervalCountInvalid = -8003,
			UploadActionTriggerReachAutoTerminateInvalid = -8004,
            UploadActionTriggerAssociateTypeInvalid = -8005,
            UploadActionTriggerSimpleIntervalTypeInvalid = -8006,
            
			//执行器Common错误
			UploadActionActuatorExecuteNotSupport = -9001,
			UploadActionActuatorTypeInvalid = -9002,
			UploadActionActuatorFunctionInvalid = -9003,
			
			//Spray执行器相关错误
			UploadActionActuatorSprayExternalSprayModeInvalid = -10001,
			UploadActionActuatorSprayFlowSpeedInvalid = -10002,
			UploadActionActuatorSprayFlowSpeedPreMuInvalid = -10003,

            ActionActuatorGimbalAngleInvalid = -11001,
            ActionActuatorGimbalDurationInvalid = -11002,
            ActionActuatorGimbalArriveTagAngleFailed = -11003,
            ActionActuatorGimbalSendCommandToGimbalFailed = -11004,
            
			//
			UnknownError = 0xFFFF,
		};
		
		AbstractErrorCode ConvertInternalMissionError(uint32_t internal_error);
	}
}

#endif /* dji_waypointv2_sdk_error_hpp */
