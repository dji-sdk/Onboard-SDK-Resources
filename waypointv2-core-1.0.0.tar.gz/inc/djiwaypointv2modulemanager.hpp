//
//  djiwaypointv2modulemanager.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djiwaypointv2modulemanager_hpp
#define djiwaypointv2modulemanager_hpp

#include <stdio.h>
#include <djicommonlifecycle.hpp>
#include <device/djicommondeviceeventdispatcher.hpp>

namespace dji {
	namespace waypointv2 {
		using namespace common;
		class LogicManager;
		class WorkerManager;
		class PackManager;
		class ModuleManager : public ILifeCycle, IDeviceEventDispatcherListener {
		public:
			ModuleManager();
			virtual ~ModuleManager();
			static ModuleManager& GetInstance();
			virtual void Setup() override;
			virtual void Cleanup() override;
			virtual void HandleDeviceStateChange(uint64_t device_id, DeviceEvent event) override;
			
			LogicManager& GetLogicManager();
			WorkerManager& GetWorkerManager();
			PackManager& GetPackManager();
		private:
			ModuleManager(const ModuleManager&) = delete;
			ModuleManager& operator=(const ModuleManager&) = delete;
		private:
			LogicManager* logic_manager_ = nullptr;
			PackManager* pack_manager_ = nullptr;
		};
	}
}


#endif /* djiwaypointv2modulemanager_hpp */
