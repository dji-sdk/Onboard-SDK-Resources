//
//  dji_waypointv2_defines.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 2018/10/10.
//

#ifndef dji_waypointv2_defines_h
#define dji_waypointv2_defines_h

namespace dji {
	namespace waypointv2 {
		typedef std::function<void(uint64_t, const WaypointStateChangeInformation&)> WaypointStateChangeCallback;
        typedef std::function<void(uint64_t, const ActionStateChangeInformation&)> ActionStateChangeCallback;
        typedef std::function<void(uint64_t, const waypointv1::V1WaypointStateChangeInformation&)> V1WaypointStateChangeCallback;

    }
}


#endif /* dji_waypointv2_defines_h */
