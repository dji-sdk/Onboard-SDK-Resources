//
//  djiwaypointv2fsmtempstatetimer.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 11/05/2018.
//

#ifndef djiwaypointv2fsmtempstatetimer_hpp
#define djiwaypointv2fsmtempstatetimer_hpp

#include <timer/djicommoncancellablecountdowner.hpp>

namespace dji {
	namespace waypointv2 {
		using namespace common;
		class FSMTempStateTimer {
		public:
			FSMTempStateTimer();
			~FSMTempStateTimer();
			void StartTimer(int current_state, float timeout_in_second, OperationBlock timeout_callback,  OperationBlock success_callback = nullptr);
			void OnFSMStateChangeTo(int state);
			void CallSuccessCallbackAndReset();
		private:
			std::shared_ptr<CancellableCountdowner> countdowner_ = nullptr;
			int current_state_ = 0;
			OperationBlock success_callback_ = nullptr;
		};
	}
}

#endif /* djiwaypointv2fsmtempstatetimer_hpp */
