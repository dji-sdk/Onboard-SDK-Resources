//
//  djiwaypointv2logicmanager.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djiwaypointv2logicmanager_hpp
#define djiwaypointv2logicmanager_hpp

#include <djicommonlifecycle.hpp>
#include <device/djicommondeviceeventdispatcher.hpp>
#include <memory>
#include <map>
#include <WaypointV2.pb.h>
#include <WaypointV1.pb.h>
#include <djiwaypointv2abstractionfsmbase.hpp>
#include <djiwaypointv2actionfsmbase.hpp>
#include <dji_waypointv2_defines.hpp>
#include <dji_waypointv2_waypointv1_adapter.hpp>
#include <djiflysafeasynccaptureprotect.h>

namespace dji {
	namespace waypointv2 {
		using namespace common;
		class Abstraction;
		class WaypointMission;
		class WaypointActionConfig;
        class V1WaypointAdaptor;
		//所有Abstraction的状态都在这里汇总，起到一个集线器的作用。
		class AbstractionStateListenerWrapper : public AbstractionListener {
		public:
			virtual void didUpdateState(uint64_t device_id, int prev_state, int cur_state, int event, const std::string& data_infos);
			WaypointStateChangeCallback state_change_callback_ = nullptr;
		};
        
        class ActionStateListenerWrapper : public ActionStateListener {
        public:
            virtual void didUpdateState(uint64_t device_id, int prev_state, int cur_state, int event, const std::string& data_infos);
            ActionStateChangeCallback action_state_change_callback_ = nullptr;
        };
        
        class V1WaypointStateListenerWrapper : public ActionStateListener {
        public:
            virtual void didUpdateState(uint64_t device_id, int prev_state, int cur_state, int event, const std::string& data_infos);
            V1WaypointStateChangeCallback v1_state_change_callback_ = nullptr;
        };
        
		class LogicManager : public ILifeCycle, public IDeviceEventDispatcherListener, public AsyncCaptureProtect {
		public:
			
// Life Cycle
			
			LogicManager();
			virtual ~LogicManager();
			virtual void Setup() override;
			virtual void Cleanup() override;
			
// Device Manage
			
			void RegisterDeviceAbstraction(uint64_t device_id);
			void UnregisterDeviceAbstraction(uint64_t device_id);
			
// Notify Event
			
			virtual void HandleDeviceStateChange(uint64_t device_id, DeviceEvent event) override;
			void NotifyDeviceStateChange(uint64_t device_id, DeviceEvent event);
			
            void UploadV1MissionData(uint64_t device_id, const std::shared_ptr<waypointv1::V1WaypointMission> mission, const LocationCoordinate& ref_location, CommonErrorCallback callback);
            void RetryV1UploadData(uint64_t device_id, CommonErrorCallback callback);
            void GetV1FlightPathCoordinates(uint64_t device_id, const std::shared_ptr<waypointv1::V1WaypointMission> mission, const LocationCoordinate& ref_location, std::function<void(const std::vector<LocationCoordinate>&)> callback);
            void DownloadV1Mission(uint64_t device_id,  CommonErrorCallback callback);
            waypointv1::V1WaypointMission GetCachedV1Mission(uint64_t device_id);
            std::vector<WaypointActionConfig> GetCachedAction(uint64_t device_id);
            void GetFlightPathCoordinates(uint64_t device_id, std::shared_ptr<waypointv2::WaypointMission> mission, std::function<void(const std::vector<LocationCoordinate>&)> callback);
			
// Mission Operation

			void UploadMissionData(uint64_t device_id, std::shared_ptr<waypointv2::WaypointMission> mission, CommonErrorCallback callback);
            void CancelUploadMission(uint64_t device_id, CommonErrorCallback callback);
			void RetryUploadData(uint64_t device_id, CommonErrorCallback callback);
			void DownloadMission(uint64_t device_id, CommonErrorCallback callback);
			WaypointMission GetCachedMission(uint64_t device_id);
			void StartMission(uint64_t device_id, CommonErrorCallback callback);
			void StopMission(uint64_t device_id, CommonErrorCallback callback);
			void PauseMission(uint64_t device_id, CommonErrorCallback callback);
			void ResumeMission(uint64_t device_id, CommonErrorCallback callback);
			
			void GetStorageActionStartEndIndex(uint64_t device_id, std::function<void(uint16_t start_index, uint16_t end_index, CommonErrorCode)> callback);
			void UploadActionData(uint64_t device_id, const std::vector<WaypointActionConfig>& action_configs, CommonErrorCallback callback);
			void DownloadActionData(uint64_t device_id,  CommonErrorCallback callback);
			
			AbstractionState GetCurrentAbstractionState(uint64_t device_id);
            uint16_t GetActionCount(uint64_t device_id);
            
			void InterruptMission(uint64_t device_id, CommonErrorCallback callback);
			void RecoverMission(uint64_t device_id, InterruptRecoverAction recoveAction,  CommonErrorCallback callback);
			
			void GetCruiseSpeed(uint64_t device_id, std::function<void(float cruise_speed, CommonErrorCode error_code)> callback);
			void SetCruiseSpeed(uint64_t device_id, float cruise_speed, CommonErrorCallback callback);
			//只允许设置一次。
			void SetWaypointStateChangeCallback(WaypointStateChangeCallback stateChangeCallback, CommonErrorCallback callback);
            void SetActionStateChangeCallback(ActionStateChangeCallback stateChangeCallback, CommonErrorCallback callback);
			void SetIsWaypointV1AdaptorSupported(bool is_supported);
            void SetV1WaypointStateChangeCallback(V1WaypointStateChangeCallback stateChangeCallback, CommonErrorCallback callback);
            void OnAbstractionStateUpdate(uint64_t device_id, AbstractionState prev_state, AbstractionState cur_state, AbstractionEvent event, const std::string& data_infos);
            void OnActionStateUpdate(uint64_t device_id, ActionState prev_state, ActionState cur_state, ActionEvent event, const std::string& data_infos);
            
		private:
			std::map<uint64_t, std::shared_ptr<Abstraction>> abstraction_map_;
			bool is_waypoint_v1_adapotor_supported_ = false;
            std::map<uint64_t, std::shared_ptr<V1WaypointToV2Adaptor>> adator_map_;
            std::shared_ptr<AbstractionStateListenerWrapper> listener_wrapper_ = nullptr;
            std::shared_ptr<ActionStateListenerWrapper> action_listener_wrapper_ = nullptr;
            std::shared_ptr<V1WaypointStateListenerWrapper> v1_listener_wrapper_ = nullptr;
		};
	}
}

#endif /* djiwaypointv2logicmanager_hpp */
