//
//  dji_waypointv2_waypointv1_convertor.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 2018/12/15.
//

#ifndef dji_waypointv2_waypointv1_convertor_hpp
#define dji_waypointv2_waypointv1_convertor_hpp

#include <WaypointV2.pb.h>
#include <WaypointV1.pb.h>
#include <memory.h>

namespace dji {
	namespace waypointv2 {
		using namespace waypointv1;
		
		class V1WaypointMissionConvertor {
		public:
			static void ConvertV1MissionToV2(const std::shared_ptr<waypointv1::V1WaypointMission> v1_input_mission, std::shared_ptr <waypointv2::WaypointMission> v1_output_mission, std::vector<WaypointActionConfig>& output_actions, const LocationCoordinate& ref_location);
			static void ConvertV2MissionToV1(const std::shared_ptr <waypointv2::WaypointMission> v2_input_mission, const std::vector<WaypointActionConfig>& input_actions, std::shared_ptr<waypointv1::V1WaypointMission> v1_output_mission);
			static void ConvertV1ActionToV2(const ::dji::protobuf::RepeatedPtrField< ::dji::waypointv1::WaypointAction >& action_list, int waypoint_index, bool is_clockwise, int& start_index, std::vector<WaypointActionConfig>& output_actions);
			static void ConvertV1ActionToV2Actuator(const WaypointAction& action, int waypoint_index, bool is_clockwise, int& start_index, std::vector<WaypointActionActuator>& output_actions);
			static uint32_t ConvertV1MissionIDToV2(uint16_t v1_mission_id);
			static uint16_t	ConvertV2MissionIDToV1(uint32_t v2_mission_id, bool& is_v1_mission_id);
		};
	}
}

#endif /* dji_waypointv2_waypointv1_convertor_hpp */
