//
//  dji_waypointv2_protocol_struct_defines.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 03/07/2018.
//

#ifndef dji_waypointv2_protocol_struct_defines_hpp
#define dji_waypointv2_protocol_struct_defines_hpp

#include <stdio.h>
#include <stdint.h>

#define V2_DEFALUT_VERSION ("100.000")

namespace dji {
	namespace waypointv2 {
#pragma mark - Mission And Waypoint
		
#pragma pack(1)
		
		enum ProtocolWaypointType {
			ProtocolWaypointTypeCurvatureContinuousPassed  = 0,	//曲率连续，且飞机过点不停
			ProtocolWaypointTypeCurvatureContinuousStop = 1,	//曲率连续，且飞机到点停止
			ProtocolWaypointTypeCurvatureBreakStop = 2,			//曲率不连续，飞机到点停止
			ProtocolWaypointTypeCurvatureCoordinateTurning = 3,	//协调转弯，飞机在该店前转弯，不经过改点。
			ProtocolWaypointTypeStraightIn = 4,					//直线进入点，只能用于首个航点，表示飞机以某个长度的直线进入航线
			ProtocolWaypointTypeStraightOut = 5,				//直线退出点，只能用于末尾航点，表示飞机以某个长度的直线退出航线
		};
		
		enum ProtocolWaypointYawMode {
			ProtocolWaypointYawModeAuto = 0,					//跟随轨迹，同时支持打杆控制
			ProtocolWaypointYawModeUsingInitialDirection = 1,	//不转yaw
			ProtocolWaypointYawModeControlByRC = 2,				//RC控制
			ProtocolWaypointYawModeWaypointYawAngleControl = 3,	//根据航点yaw 角度进行控制。
			ProtocolWaypointYawModeTowardPointOfInterest = 4,	//朝向兴趣点
			ProtocolWaypointYawModeCameraFollow = 5,			//跟随相机转动
		};
		
		/**
		 *	相对参考点计算出来的坐标
		 */
		typedef struct {
			float relative_pos_x;	//经度
			float relative_pos_y;	//纬度
			float relative_pos_z;	//高度
		}ProtocolRelativeLocation;
		
		typedef struct
		{
			// 协议版本号，用于区分不同版本的协议
			uint16_t version;
            // 保留，暂时不用
            uint8_t reserve  :7;
            // 初始化信息、航点信息、action信息是否要持久化存储到DJI_FLIGHT的标志位。（为1 要持久化存储，为0不持久化存储）
            uint8_t save_file:1;
			// 任务编号，用于标识用户规划的各个任务
			uint32_t mission_id;
			// 任务的总航点数，不超过65535
			uint16_t mis_total_len;
			// 开始任务前要上传的最少航点数，最少2个，最多不大于mis_total_len且不大于飞控内部允许同时存储的最大航点数
			uint16_t cur_total_len;
			// 任务执行次数（0：1次；1：1次；2：2次……0xFF：无限循环）
			uint8_t exec_num;
			// 任务结束后动作（0-原地悬停；1-返航；2-原地降落；3-返回初始点悬停； 4-释放当前控制设备MSDK/OSDK权限）
			uint8_t action_on_finish;
			// 任务最大速度（单位：0.01m/s，范围2-15m/s）
			uint16_t global_max_velocity;
			// 任务巡航速度（单位：0.01m/s，范围0- global_max_vel）
			uint16_t global_cruise_velocity;
			// 任务起始点序号（从0开始编号）, 该起始点序号加上cur_total_len应小于mis_total_len.
			uint16_t start_index;
			// 遥控失联后动作（0-退出waypoint，随飞机失控逻辑动作；1-继续运行waypoint任务）
			uint8_t action_on_rc_lost;
			// 从当前点飞向第一个航点时的方式（0-安全智能模式，当前点高度低于目标点高度时先爬升至目标高度再飞向目标；当前点高度高于目标点高度时先水平飞向目标点上方再降落至目标高度；1-当前点直接直线飞向目标点）
			uint8_t goto_first_flag;
			// 初始参考点纬度，单位：rad，范围：（-π/2，π/2）
			double reference_latitude;
			// 初始参考点经度，单位：rad，范围：（-π，π）
			double reference_longitude;
			// 初始参考点绝对高度，单位：m
			float reference_altitude;
		} dji_fc2_set_API_WP2_MISSION_INIT_req;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败）
			uint32_t result;
		} dji_fc2_set_API_WP2_MISSION_INIT_rsp;
		
		// 该API用于将各个航点信息上传至飞控，而各个航点的信息包含有航点位置信息以及航点独有的配置信息，这样每个航点的信息长度可能不一致，所以上传航点接口要支持变长航点信息的上传。
		// 其中，位置信息和航点各配置标志位是每个航点都有的信息。航点各配置项根据各配置标志位来决定有没有，如果配置有，那么各配置项在航点信息里的顺序按照下表备注3的顺序进行排列。
		// 用户上传的航点位置信息是相对于初始参考点的北东坐标，向上为正。
		// 同时该API支持批量上传航点信息。
		// 触发行为：
		// 1.记录设置结果、失败原因及其它信息；
		// 2.设置成功即完成航点数据的上传；
		// 3.所有航点数据上传完毕会推送完成的ack
		typedef struct
		{
			// 上传包里第一个航点的序号（从0开始编号）。上传的起始航点序号应该与飞控已存储的航点队列衔接（暂定），如果是第一次上传航点，该起始航点应该与初始化里的起始航点序号一致。
			uint16_t start_index;
			// 上传包里最后一个航点的序号，不小于start_index，同时要小于任务设置的总航点数。
			// uint8_t
			uint16_t end_index;
			// 航点信息定义另附文档解释
			uint8_t waypoint_struct[1];
		} dji_fc2_set_API_WP2_WAYPOINTS_UPLOAD_req;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败）
			uint32_t result;
			// 上传的第一个航点的序号
			uint16_t start_index;
			// 上传的最后一个航点的序号
			uint16_t end_index;
		} dji_fc2_set_API_WP2_WAYPOINTS_UPLOAD_rsp;
		// ========== commands end =====

		typedef struct {
			ProtocolRelativeLocation waypoint_location;
			uint8_t waypoint_type;  // 0. 曲率连续点，飞机过点不停。 1. 曲率连续点，飞机到点停止。 2. 曲率不连续，飞机到点停止。3. 协调转弯点，飞机不经过改点。4. 直线进入点，只对首航点有效。5. 直线退出点，只对末尾航点有效。
			uint8_t yaw_mode;		// 0. 自动跟随Flight轨迹 1. 不转yaw。2. 遥控器控制 3.根据航点yaw角度控制 4. 朝向hotpoint  5. 相机跟随
			uint16_t use_local_cruise_velocity:1; //设置航点巡航速度
			uint16_t use_local_max_velocity:1;	//设置航点最大速度
			uint16_t reserved:14;
			/**
			 *	数据段根据不同属性来进行拼接
			 */
		}ProtocolWaypointFixedInfo;
		
		/**
		 *	yaw_mode模式是3有效
		 */
		typedef struct {
			float angle;
			uint8_t direction;
		}ProtocolYawConfig;
		
#pragma pack()
		
#pragma mark - Push State Event

#pragma pack(1)
		
		enum ProtocolMissionPauseReason {
			ProtocolMissionPauseReasonPausedByUser = 0x00, //用户主动暂停
			ProtocolMissionPauseReasonPausedByAvoid = 0x01, //避障触发暂停
		};
		
		enum ProtocolExecuteState {
			None = 0x00, //地面站没有启动
			ProtocolExecuteStatePrepareing = 0x10, //任务准备，从地面起飞阶段
			ProtocolExecuteStateEnterLine = 0x20, //进入航线，去到第一个点
			ProtocolExecuteStateExecutingLine = 0x30, //执行航线
            ProtocolExecuteStatePaused = 0x40, //执行航线暂停
            ProtocolExecuteStateInterrupting = 0x50, //中断
			ProtocolExecuteStateExiting = 0x60, //退出航线 有可能收不到，因为会很快切换到 Finished 10h可能捕捉不到
 			ProtocolExecuteStateFinishedGoHome = 0x70, //任务结束 Go home
            ProtocolExecuteStateFinishedLanding = 0x71, //任务结束 Landing
            ProtocolExecuteStateFinishedGoToFirstPoint = 0x72, //任务结束 Go to first waypoint
		};
		
        typedef struct {
            uint8_t cur_mission_exec_num;
            uint8_t finished_all_exec_num:1;
            uint8_t reserved:7;
        }dji_fc2_finished_one_exec_mission;
        
        enum ProtocolMissionQuitReason {
            ProtocolMissionQuitReasonReserved = 0x00,
            ProtocolMissionQuitReasonMotorOnInGround = 0x01,
            ProtocolMissionQuitReasonAutoTakeOffFailed = 0x02,
            ProtocolMissionQuitReasonAutoTakeOffHightLimit = 0x03,
            ProtocolMissionQuitReasonRequestAutoNotExecuteAutoTakeOff = 0x04,
            ProtocolMissionQuitReasonRequestStartMissionFailed = 0x05,
            ProtocolMissionQuitReasonExecuteGotoFirstPointFailed = 0x06,
            ProtocolMissionQuitReasonUnknown = 0x07,
        };

        typedef struct {
            uint8_t quit_reason;
        }dji_fc2_quit_reason_data;
        
        enum ProtocolMissionAvoidState {
            ProtocolMissionAvoidStateStart = 0x01,//触发避障
            ProtocolMissionAvoidStateExit = 0x02,   //脱离避障碍物
        };
        
        typedef struct {
            uint8_t quit_reason;
        }dji_fc2_avoid_state_data;
        
        
        enum ProtocolActionEventExecState {
            ProtocolActionEventExecStateIdel = 0x01, //空闲状态
            ProtocolActionEventExecStateExecuting = 0x02, //忙碌状态
        };
        
        typedef struct {
            uint16_t action_id;
            uint8_t pre_actuator_state;
            uint8_t cur_actuator_state;
            uint32_t result;    //cmd 结果值
        }dji_fc2_action_event_data;
        
        enum ProtocolInterruptEventReason {
            ProtocolInterruptEventReasonPause = 0x00, //暂停
            ProtocolInterruptEventReasonControlRCStick = 0x10, //用户打杆触发中断
            ProtocolInterruptEventReasonUrgent = 0x11, //触发紧急中断，如紧急刹车
            ProtocolInterruptEventReasonLimitRadius = 0x12, //限远中断
            ProtocolInterruptEventReasonLimitHeight = 0x13, //限高中断
            ProtocolInterruptEventReasonAvoidSwitchWithoutGPS       = 0x14, //避障开关打开时，如果雷达未打开会触发中断
            ProtocolInterruptEventReasonNoPotion = 0x15, // 农机:无药水的时候触发中断
        };
        
        typedef struct {
            uint8_t interrupt_reason;
        }dji_fc2_interrupt_event_data;

        
        enum ProtocolRecoverEventReason {
            ProtocolRecoverEventReasonResumed = 0x00, //暂停恢复
            ProtocolRecoverEventReasonStartInterruptRecover = 0x10, //开始中断恢复（农机）
            ProtocolRecoverEventReasonFinishedInterruptRecover = 0x20, //完成中断恢复（农机）
            ProtocolRecoverEventReasonFInterrupRecoverFailed = 0x30, //中断恢复失败
        };
        
        typedef struct {
            uint8_t recover_reason;
        }dji_fc2_recover_event_data;
        
        enum ProtocolFinishedEventReason {
            ProtocolFinishedEventReasonDone = 0x00, //任务正常结束
            ProtocolFinishedEventReasonStoped = 0x10, //用户触发结束
            ProtocolFinishedEventReasonMotorOnInGround = 0x20, //飞机在地面且电机已经启动
            ProtocolFinishedEventReasonAutoTakeOffTimeout = 0x21, //自动起飞超时
            ProtocolFinishedEventReasonAutoTakeHeightError = 0x22, //自动起飞高度无法到达指定高度
            ProtocolFinishedEventReasonAutoTakeOffCannotExecute = 0x23, //自动起飞被无法执行
            ProtocolFinishedEventReasonFinishedByHighPriority = 0x24, //地面站任务被更高优先级打断
            ProtocolFinishedEventReasonInternalError = 0x25, //内部错误：
        };
        
        typedef struct {
            uint8_t finished_reason;
        }dji_fc2_finished_event_data;

        enum ProtocolExecuteEvent {
            ProtocolExecuteEventStarted = 0x00,
            ProtocolExecuteEventInterrupt = 0x01,
            ProtocolExecuteEventRecover = 0x02,
            ProtocolExecuteEventFinished = 0x03,
            
            ProtocolExecuteEventReachPoint = 0x10,
            ProtocolExecuteEventReachLastPoint = 0x11,
            ProtocolExecuteEventAvoidStateUpdate = 0x12,
            
            ProtocolExecuteEventUploadFinished = 0x20, //上传完成,固件上并没有实现。
            ProtocolExecuteEventActionExecuteEvent = 0x30, //Action执行
        };
        
		// 状态推送API用于推送地面站运行的状态信息，推送频率：10Hz。推送的信息包含两部分：通用数据和各机型特有数据，因此buffer是变长的，其中特有数据部分的具体数据组成和含义详见各机型的说明文档。
		typedef struct
		{
			// 通用数据版本号，当前的通用数据版本号common_data_version = 1
			uint8_t common_data_version;
			// 通用数据段数据长度（不包括通用版本号和数据长度变量的长度）
			uint16_t common_data_length;
			// 当前航点序号（0—任务最大航点数-1）
			uint16_t cur_waypoint_index;
			// 地面站任务执行状态（0x00:地面站没有启动；0x10：任务准备；0x20：进入航线；0x30：执行航线飞行任务；0x40：中断状态；0x50：退出航线；0x60：任务结束）
			uint8_t gs_state;
			// 飞机飞行速度大小（单位：0.01m/s）
			uint16_t velocity;
			// 飞机前飞标志位（1：飞机前飞，0：飞机倒飞）
			uint8_t fly_forward:1;
			// 保留位
			uint8_t reserved   :7;
			// 当前机型特有推送数据版本号
			uint8_t unique_data_version;
			// 当前机型特有推送数据长度（不包括特有数据版本号和数据长度变量的长度）
			uint16_t unique_data_length;
			// 当前机型特有数据，具体特有推送的数据见各机型的相关说明文档
			uint8_t unique_data_t[0];
		} dji_fc2_set_API_WP2_DATA_PUSH_req;
		
        //Reach Point 事件的数据
        typedef struct {
            uint16_t waypoint_index;
        } dji_fc2_reach_point_data;
        
		// 事件推送API用于某些特定事件发生时推送地面站信息到外部模块。不同事件推送的信息具体含义和长度不尽相同，需要视具体事件类型而定。
		typedef struct
		{
			// 当前触发推送的事件（0x00：任务完成事件；0x01：到点事件；0x02：航点上传完成事件；0x03：任务暂停事件；0x04：任务退出事件；0x10：action状态切换事件）
			uint8_t event;
			// 事件推送飞控时间戳
			uint32_t timestamp;
			
			// 当前事件下推送的数据。不同的事件类型推送的数据有所差异，详见各事件类型说明；同时需要说明的一点是：同一个事件，不管是什么机型，推送的数据结构都应该是一致的
			uint8_t event_push_data[0];
		} dji_fc2_set_API_WP2_EVENT_DATA_PUSH_req;
	
#pragma pack()
		
#pragma mark - Action
		
#pragma pack(1)
		
		enum ProtocolTriggerType {
			ProtocolTriggerTypeReserved =  0,
			ProtocolTriggerTypeReachPoints = 1,
			ProtocolTriggerTypeAssociate = 2,
			ProtocolTriggerTypeTrajectory = 3,
			ProtocolTriggerTypeSimpleInterval = 4,
            ProtocolTriggerTypeSimpleReachPoint = 5,
		};
		
		enum ProtocolActuatorType {
			ProtocolActuatorTypeReserved = 0,
			ProtocolActuatorTypeCamera = 1,
			ProtocolActuatorTypeGimbal = 2,
			ProtocolActuatorTypeSpray = 3,
			ProtocolActuatorTypeAircraftControl = 4,
		};
		
		enum ProtocolCameraAction {
			ProtocolCameraActionShootPhoto = 0x0001,
			ProtocolCameraActionStartRecordVideo = 0x0002,
            ProtocolCameraActionStopRecordVideo = 0x0003,
            ProtocolCameraActionFocus = 0x0004,
			ProtocolCameraFocal = 0x005,
		};
		
		enum ProtocolGimbalAction {
			ProtocolGimbalActionRotate = 0x0001,
            ProtocolGimbalAircraftRotateGimbal = 0x0002,
		};
		
		enum ProtocolSprayAction {
			 ProtocolSprayActionSpray = 0x0001,
		};
		
		enum ProtocolAircraftControlAction {
			ProtocolAircraftControlActionRotateYaw = 0x0001,
			ProtocolAircraftControlActionFlyControl = 0x0002,
		};
		
		enum ProtocolIntervalType {
			ProtocolIntervalTypeReserved = 0,
			ProtocolIntervalTypeTime = 1,
			ProtocolIntervalTypeDistance = 2,
		};
		
		typedef struct {
			uint16_t start_index;
			uint16_t end_index;
			uint16_t interval_count;
			uint16_t auto_exit_count;
		}ProtocolReachPointsTriggerParam;
		
        typedef struct {
            uint16_t start_index;
            uint16_t auto_exit_count  ;
        }ProtocolSimpleReachPointsTriggerParam;
        
		typedef struct {
			uint8_t associate_type;
			uint8_t waiting_time;
			uint16_t associate_action_id;
		}ProtocolAssociateTriggerParam;
		
		typedef struct {
			uint16_t start_index;
			uint16_t end_index;
		}ProtocolTrajectoryTriggerParam;
		
		typedef struct {
			uint16_t start_index; //开始位置
			uint16_t interval_value; //时间间隔（0.01s）距离间隔 （0.01m）距离间隔
			uint8_t interval_type;	//定时 or 定距
		}ProtocolSimpleIntervalTriggerParam;
		
		typedef struct {
			uint8_t spray_mode;
			uint8_t flow_speed_valid_flag;
			float flow_speed;
			float flow_speed_per_mu;
		}ProtocolActionSprayActuator;
		
		typedef struct {
			uint8_t retry_times;
		}ProtocolActionCameraActuator;
		
		typedef struct {
			uint16_t x_position;
			uint16_t y_position;
			uint8_t retry_times;
			uint8_t focus_dealy_times;
		}ProtocolCameraFocusActuator;
		
		typedef struct {
			uint16_t focal_distance; //焦距  0.1mm [0~1000]
			uint8_t retry_times;	//重试次数
		}ProtocolCameraZoomLengthActuator;
		
		typedef struct {
			int16_t gimbal_roll;
			int16_t gimbal_pitch;
			int16_t gimbal_yaw;
			uint8_t is_absolute:1;
			uint8_t roll_ignore:1;
			uint8_t pitch_ignore:1;
			uint8_t yaw_ignore:1;
			uint8_t abs_mode_yaw_ref:1;
			uint8_t reserved:3;
			uint8_t duration_time;
		}ProtocolActionRotateGimbalActuator;

		typedef struct {
			int16_t gimbal_roll;
			int16_t gimbal_pitch;
			int16_t gimbal_yaw;
			uint8_t roll_ignore:1;
			uint8_t pitch_ignore:1;
			uint8_t yaw_ignore:1;
			uint8_t reserved:5;
		}ProtocolActionAircraftRotateGimbalActuator;
		
		typedef struct {
			uint8_t is_relative:1; //0转动角度是相对于真北角度，1 转动角度是相对yaw角度
			uint8_t reserved:7;
			float yaw_angle; //角度
		}ProtocolAircraftControlRotateYawActuator;
		
		typedef struct {
			uint8_t fly_status:1;
			uint8_t reserved:7;
		}ProtocolAircraftControlFlyControlActuator;
		
		typedef struct {
			uint32_t result_code;
			uint16_t error_index;
		}ProtocolUploadActionResultData;
		
		typedef struct {
			uint32_t result_code;
			uint16_t total_count;
			uint8_t data[0];
		}ProtocolDownloadActionDatas;
	
		
#pragma pack()
		
#pragma mark - Request Data
		
#pragma pack(1)
		
		enum ProtocolBreakRestoreType {
			ProtocolBreakRestoreTypeBreakMission = 1, 						// 1：中断任务
			ProtocolBreakRestoreTypeGoBackToRecordPoint = 2,				// 2：返回断点
			ProtocolBreakRestoreTypeGoBackToCurrentProjectionPoint = 3,		// 3：返回当前航线的投影点
			ProtocolBreakRestoreTypeGoBackToNextProjectionPoint = 4,		// 4：返回下一航线的投影点
			ProtocolBreakRestoreTypeGoBackToNextNextProjectionPoint = 5,    // 5：返回下下航线的投影点。
		};
				
        enum ProtocolStartStopType {
            ProtocolStartStopTypeStart = 1,                                 // 1. 开始任务
            ProtocolStartStopTypeStop = 2,                                  // 2. 停止任务
        };
        
		// 开始/结束航线任务
		// 边界条件：
		// 输入参数gostop需为1或2
		// 触发行为：
		// 1.记录设置结果、失败原因及其它信息；
		// 2.启动成功后进入waypoint模式；
		// 3.关闭成功后退出waypoint模式
		typedef struct
		{
			// 请求开始/结束任务（1：启动；2：停止）输入参数gostop需为1或2
			uint8_t go_stop;
		} dji_fc2_set_API_WP2_GO_STOP_req;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败）
			uint32_t result;
		} dji_fc2_set_API_WP2_GO_STOP_rsp;
		
        enum ProtocolPauseResumeType {
            ProtocolPauseResumeTypePause = 1,                                // 1. 暂停任务
            ProtocolPauseResumeTypeResume = 2,                               // 2. 恢复任务
        };
        
		// 暂停/恢复航线任务（该API与中断/恢复航线任务API只能有一个可以生效，对于关闭中断/恢复功能的飞机，使用该API；否则使用中断/恢复任务API）
		// 边界条件：
		// 输入参数pause_recovery需为1或2
		// 触发条件：
		// 1.记录设置结果、失败原因及其它信息；
		// 2.暂停成功后航线任务暂停；
		// 3.恢复成功后航线任务继续执行
		typedef struct
		{
			// 请求暂停/恢复任务（1：暂停；2：恢复）输入参数pause_recovery需为1或2
			uint8_t pause_recovery;
		} dji_fc2_set_API_WP2_PAUSE_RECOVERY_MISSION_req;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败）
			uint32_t result;
		} dji_fc2_set_API_WP2_PAUSE_RECOVERY_MISSION_rsp;
	
		// 设置中断、恢复航线任务（该API与暂停/恢复航线任务API只能有一个可以生效，对于开启中断/恢复功能的飞机，使用该API；否则使用暂停/恢复任务API）
		// 边界条件：
		// 触发行为：1.设置中断/恢复航线任务
		// 2.无论成功失败都要打印
		typedef struct
		{
			// 1：中断任务；2：返回断点；3：返回当前航线的投影点；4：返回下一航线的投影点；5：返回下下航线的投影点。
			uint8_t cmd;
		} dji_fc2_set_API_WP2_BREAK_RESTORE_WAYPOINT_FLY_req;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败）
			uint32_t result;
		} dji_fc2_set_API_WP2_BREAK_RESTORE_WAYPOINT_FLY_rsp;
		
		// 设置航线全局巡航速度
		// 触发条件：
		// 1. 返回设置结果；
		// 2.无论成功失败都要打印
		typedef struct
		{
			// 任务全局巡航速度,不大于任务最大全局巡航速度（单位：0.01m/s，范围0- global_max_vel）
			uint16_t global_cruise_vel;
		} dji_fc2_set_API_WP2_SET_GLOBAL_CRUISE_VEL_req;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败）
			uint32_t result;
		} dji_fc2_set_API_WP2_SET_GLOBAL_CRUISE_VEL_rsp;
		
		typedef struct
		{
			// 返回码（0：成功；其它为失败），只有返回码为0时，才会有后续信息，否则只返回result.
			uint32_t result;
			// 任务巡航速度（单位：0.01m/s，范围0- global_max_vel）
			uint16_t global_cruise_vel;
		} dji_fc2_get_API_WP2_GET_GLOBAL_CRUISE_VEL_rsp;
		
		
		typedef struct {
			uint16_t start_index; //开始位置
			uint16_t end_index;	//结束位置
		}ProtocolDownloadInputData;
		
		typedef struct
		{
			// 是否设置初始盘旋圆，1：设置有盘旋圆并使用设置的盘旋圆信息；0：未设置盘旋圆信息，使用默认的盘旋圆
			uint8_t has_climb_circle;
			// 盘旋圆纬度，unit:rad,range: -pi/2~pi/2
			double climb_circle_lati;
			// 盘旋圆经度，unit:rad,range: -pi~pi
			double climb_circle_longti;
			// 盘旋圆半径，unit:m
			float climb_circle_radius;
		} dji_fc2_set_API_WP2_SET_CLIMB_CIRCLE_req;
		
#pragma pack()
		
#pragma mark - Response Data
		
#pragma pack(1)
		
		typedef struct {
			uint32_t result; //0成功  其他错误码
			uint16_t start_index; //开始位置
			uint16_t end_index;	//结束位置
		}ProtocolUploadResultData;
		
		typedef struct {
			uint32_t result;		//0成功  其他错误码
			uint16_t start_index;	//FC存储Waypoints开始位置
			uint16_t end_index;		//FC存储Waypoints结束位置
		}ProtocolStorageStartEndIndexData;
		
		typedef struct {
			uint32_t result_code;	//0成功  其他错误码
			uint16_t start_index;	//下载Waypoints数据开始位置
			uint16_t end_index;		//下载Waypoints数据结束位置
			uint8_t data[0];		//数据段
		}ProtocolDownloadListData;
		
		typedef struct{
			uint32_t result_code;	//0成功  其他错误码
			dji_fc2_set_API_WP2_MISSION_INIT_req init_data;	//下载航点初始化数据
		}ProtocolDownloadInitializationData;
		
		typedef struct {
            uint32_t result_code;
			uint16_t start_index; //最大可用字节数
			uint16_t end_index;	//剩余最大字节数
		}ProtocolActionStorageInfo;
		
		typedef struct
		{
			// 返回码（0：成功；其他为失败）
			uint32_t result;
			// 航线任务中断点的经度（-3.14 到 3.14）
			double break_point_long;
			// 航线任务中断点的纬度（-1.57 到 1.57）
			double break_point_lati;
			// 航线任务中断点的绝对高度（m）
			float break_point_alti;
			// 航线任务的mission_id，用于区分不同的航线任务
			uint32_t mission_id;
			// 中断任务时的航点index，用于表示从哪个航点开始的航段任务被中断
			uint16_t break_wp_index;
			// 断点信息是否有效的标志位（0 信息无效，1 信息有效），用于判断获取的断点信息是否有效
			uint8_t break_info_is_valid;
		} dji_fc2_get_API_WP2_GET_BREAK_POINT_INFO_rsp;
		
#pragma pack()
	}
}

#endif /* dji_waypointv2_protocol_struct_defines_hpp */
