//
//  dji_common_account_data_provider.hpp
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/13.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_account_data_provider_hpp
#define dji_common_account_data_provider_hpp

#include <stdio.h>
#include <djicommoncommondefines.hpp>
#include <string>
/**
 * 这个类用于外部向CSDK提供账号信息的功能，由使用者提供相应的handle实现
 */

namespace dji {
    namespace common {
        class AccountDataProvider {
        public:
            AccountDataProvider( const AccountDataProvider& ) = delete;
            AccountDataProvider& operator=(const AccountDataProvider&) = delete;
            
            virtual std::string GetToken() const;
            std::string GetUserAPICenterID() const;
            std::string GetEamil() const;
            std::string GetPhoneNumber() const;
            std::string GetCurrentWorkingAccountName() const;
            bool IsTokenValid() const;
            bool IsUserLogin() const;
            
            
            void SetGetTokenHandle(ReturnStringValueHandle handle);
            void SetGetUserAPICenterIDHandle(ReturnStringValueHandle handle);
            void SetGetEmailHandle(ReturnStringValueHandle handle);
            void SetGetPhoneNumbertHandle(ReturnStringValueHandle handle);
            void SetIsTokenValidHandle(ReturnBoolValueHandle handle);
            void SetIsUserLoginHandle(ReturnBoolValueHandle handle);
            
            static AccountDataProvider& GetInstance();
        protected:
            AccountDataProvider() {};
            virtual ~AccountDataProvider() {};
        private:
            //实现在上层
            ReturnStringValueHandle get_token_handle_;
            ReturnStringValueHandle get_user_center_id_handle_;
            ReturnStringValueHandle get_email_handle_;
            ReturnStringValueHandle get_phone_number_handle_;
            ReturnBoolValueHandle get_is_token_valid_handle_;
            ReturnBoolValueHandle get_is_user_login_handle_;
        };
    }
}

#endif /* dji_common_account_data_provider_hpp */
