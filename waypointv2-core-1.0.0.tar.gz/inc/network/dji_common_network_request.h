//
//  dji_common_network_request.hpp
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/13.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_network_request_hpp
#define dji_common_network_request_hpp

#include <stdio.h>
#include <map>
#include <string>

namespace dji {
    namespace common {
        enum class NetworkRequestMethod;
        
        class NetworkRequest {
        public:
            virtual ~NetworkRequest() {};
            NetworkRequest(NetworkRequestMethod request_method);
            //是否使用表单
            virtual bool IsUsedForm() const {return false;}
            //POST/GET
            std::string GetRequestMethodName() const;
            //Base Url
            virtual std::string GetBaseUrl() const {return "";}
            //Debug Url
            virtual std::string GetDebugUrl() const {return "";}
            //API
            virtual std::string GetRequestAPI() const {return "";}
            //请求header map
            virtual std::map<std::string, std::string> GetRequestHeaders() const {
                std::map<std::string, std::string> headers;
                return headers;
            }
            virtual bool UseRequestBody() const { return false;}
            //直接获取body
            virtual std::string GetRequestBody() const {return "";}
        private:
            NetworkRequestMethod request_method_;
        };
    }
}

#endif /* dji_common_network_request_hpp */
