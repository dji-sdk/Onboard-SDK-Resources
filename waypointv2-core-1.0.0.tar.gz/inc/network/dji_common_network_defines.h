//
//  dji_common_network_defines.h
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/13.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_network_defines_h
#define dji_common_network_defines_h
#include <string>
#include <functional>
#include <memory>
#include "dji_common_network_request.h"

namespace dji {
    namespace common {
        //网络请求类型 目前只支持GET/POST
        enum class NetworkRequestMethod {
            GET,
            POST,
        };
        
        typedef std::string JSONBuffer;
        
        struct NetworkResponseData {
            JSONBuffer rsp_headers; //响应头
            JSONBuffer rsp_bodys;   //响应体(binary or json)
        };
        
        typedef std::function<void(const NetworkResponseData& responseData, bool is_success)> ResponseCallback;
        typedef std::function<void(std::shared_ptr<const NetworkRequest> request, ResponseCallback callback)> NetworkRequestHandle;
        //下载文件结果
        typedef std::function<void(bool result)> BoolResponseCallback;
        //下载文件进度
        typedef std::function<void(float download_progress)> DownloadProgressCallback;
        //下载文件Handle
        typedef std::function<int(const std::string& url, const std::string& filePath, DownloadProgressCallback progress_callback, BoolResponseCallback callback)> NetworkDownloadDataHandle;
        //取消文件下载
        typedef std::function<void(int net_op_id)> NetworkDownloadStopHandle;

        
        
    }
}

#endif /* dji_common_network_defines_h */
