//
//  djicommonlifecycle.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djicommonlifecycle_hpp
#define djicommonlifecycle_hpp

#include <stdio.h>


namespace dji {
	namespace common {
		class ILifeCycle {
		public:
			ILifeCycle() {}
			virtual ~ILifeCycle() {}
			virtual void Setup() = 0;
			virtual void Cleanup() = 0;
		};
	}
}


#endif /* djicommonlifecycle_hpp */
