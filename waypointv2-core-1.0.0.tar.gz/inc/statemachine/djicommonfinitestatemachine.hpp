//
//  djicommonfinitestatemachine.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djicommonfinitestatemachine_hpp
#define djicommonfinitestatemachine_hpp

#include <stdio.h>
#include <vector>
#include <memory>
#include <map>
#include <set>
#include <assert.h>
#include "djicommonmacros.h"

#if defined (__linux__)
#include <algorithm>
#endif

//如果需要传递信息 需要加一个  typename. 且在transit的时候传入。 但是目前看来无此需求。 保留实现
namespace dji {
	namespace common {
		template <typename StateType>
		class FiniteStateMachineStateListener {
		public:
			virtual ~FiniteStateMachineStateListener(){}
			//看情况 是否需要加FiniteStateMachine对象。 可扩展
			virtual void StateChanged(StateType prev_state, StateType cur_state) = 0;
		};
		
		template <typename StateType>
		class FiniteStateMachine {
		public:
			FiniteStateMachine() {}
			~FiniteStateMachine() {}
			
			void AddStates(const std::vector<StateType>& states, StateType init_state) {
				this->states_.insert(this->states_.end(), states.begin(), states.end());
#if DEBUG
				auto find_pos = std::find(states.begin(), states.end(), init_state);
                assert(find_pos != states.end());
#endif
				this->current_state_ = init_state;
			}
			
			void AddTransitions(const std::vector<StateType>& from_states, const std::vector<StateType>& to_states) {
				for (auto from_iter = from_states.begin(); from_iter != from_states.end(); ++from_iter) {
					auto from_transitions_iter = this->transitions_.find(*from_iter);
					if (from_transitions_iter != this->transitions_.end()) {
						from_transitions_iter->second.insert(to_states.begin(), to_states.end());
					} else {
						std::set<StateType> result_transitions;
						result_transitions.insert(to_states.begin(), to_states.end());
						this->transitions_.insert(std::make_pair(*from_iter, result_transitions));
					}
				}
			}
			
			void AddTransitions(StateType form_state, const std::vector<StateType>& to_states) {
				auto from_transitions_iter = this->transitions_.find(form_state);
				if (from_transitions_iter != this->transitions_.end()) {
					from_transitions_iter->second.insert(to_states.begin(), to_states.end());
				} else {
					std::set<StateType> result_transitions;
					result_transitions.insert(to_states.begin(), to_states.end());
					this->transitions_.insert(std::make_pair(form_state, result_transitions));
				}
			}
			
			void AddTransitions(const std::vector<StateType>& from_states, StateType to_state) {
				for (auto from_iter = from_states.begin(); from_iter != from_states.end(); ++from_iter) {
					auto from_transitions_iter = this->transitions_.find(*from_iter);
					if (from_transitions_iter != this->transitions_.end()) {
						from_transitions_iter->second.insert(to_state);
					} else {
						std::set<StateType> result_transitions;
						result_transitions.insert(to_state);
						this->transitions_.insert(std::make_pair(*from_iter, result_transitions));
					}
				}
			}
			
			bool TryTransitToState(StateType state) {
				if (CanTransitToState(state)) {
					this->TransitToState(state);
					return true;
				}
				return false;
			}
			
			bool CanTransitToState(StateType state) {
				auto next_states = this->transitions_[this->current_state_];
				if (next_states.empty()) {
					return false;
				}
				
				auto state_pos = std::find(next_states.begin(), next_states.end(), state);
				if (state_pos != next_states.end()) {
					return true;
				}
				return false;
			}
			
			void TransitToState(StateType state) {
				if (!this->CanTransitToState(state)) {
					DEBUG_ASSERT
					printf("Transit State failed, check current state and input state transit relationship\n");
					return;
				}
				this->ForceTransitToState(state);
			}
			
			void ForceTransitToState(StateType state) {
				auto preState = this->current_state_;
				this->current_state_ = state;
				
				auto listeners = listeners_;
				for (auto iter = listeners.begin(); iter != listeners.end(); ++iter) {
					(*iter)->StateChanged(preState, this->current_state_);
				}
			}
			
			StateType GetCurrentState() {
				return this->current_state_;
			}
			
			void AddListener(std::shared_ptr<FiniteStateMachineStateListener<StateType>> listener) {
				this->listeners_.insert(listener);
			}
			
			void RemoveListener(std::shared_ptr<FiniteStateMachineStateListener<StateType>> listener) {
				this->listeners_.erase(listener);
			}
			
			void RemoveAllListeners() {
				this->listeners_.clear();
			}
			
		private:
			std::vector<StateType> states_;
			StateType current_state_;
			std::set<std::shared_ptr<FiniteStateMachineStateListener<StateType>>> listeners_;
			std::map<StateType, std::set<StateType>> transitions_;
		};
	}
}

#endif /* djicommonfinitestatemachine_hpp */
