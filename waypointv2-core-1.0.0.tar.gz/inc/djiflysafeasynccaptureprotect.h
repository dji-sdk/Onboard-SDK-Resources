//
//  djiflysafeasynccaptureprotect.h
//  DJIFlySafeCore
//
//  Created by jason zheng on 2018/1/11.
//

#ifndef djiflysafeasynccaptureprotect_h
#define djiflysafeasynccaptureprotect_h
#include <stdio.h>
#include <functional>

#define WeakDummy(__TARGET__)\
std::weak_ptr<Dummy> __TARGET__(this->dummy_ptr_)

#define WeakDummyReturn(__TARGET__)\
std::shared_ptr<Dummy> strong_dummy_prt = __TARGET__.lock();\
if (!strong_dummy_prt) return;

#define WeakDummyCallbackReturn(__TARGET__, callback, ...)\
std::shared_ptr<Dummy> strong_dummy_prt = __TARGET__.lock();\
if (!strong_dummy_prt) {\
if (callback) {\
callback(__VA_ARGS__);\
}\
return;\
}\


namespace dji {
    namespace common {
        //dummy
        class Dummy {
        public:
            Dummy() {};
            ~Dummy() {};
        };
        
        //base
        class AsyncCaptureProtect {
        public:
            AsyncCaptureProtect() {
                dummy_ptr_ = std::make_shared<Dummy>();
            };
            virtual ~AsyncCaptureProtect() {
                dummy_ptr_ = nullptr;
            };
            
            std::shared_ptr<Dummy> dummy_ptr_;
        };
    }
}

#endif /* djiflysafeasynccaptureprotect_h */
