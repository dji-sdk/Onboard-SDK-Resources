//
//  djicommonpackmamanger.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djicommonpackmamanger_hpp
#define djicommonpackmamanger_hpp

#include <map>
#include <voidbuffer/djicommonvoidbuffer.hpp>
#include <3rdparty/include/djicommonworker.h>
#include <packmanager/djicommonpackmanagerdefines.hpp>
#include <packmanager/djicommonpackobserver.hpp>

namespace dji
{
	namespace common
	{
		class IPackManager {
		public:
			virtual ~IPackManager(){};
			
			virtual void SendPack(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval, PackRspCallback rsp_cb, uint16_t seq_num = 0) = 0;
     		//Use this method when you don't care about the response. When it return false, it might mean the link buffer is full.
            virtual bool DirectSendPack(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval) = 0;
			virtual int RegisterPushPackInfoListener(PackType type, PackDataSourceCallback cb) = 0;
			virtual void unRegisterPushPackInfoListener(PackType type, int register_id) = 0;
		};
		
		class PackManagerBaseImpl: public PackObserver, public IPackManager
		{
		public:
            PackManagerBaseImpl(const PackManagerBaseImpl&) = delete;
            PackManagerBaseImpl& operator=(const PackManagerBaseImpl&) = delete;
            static PackManagerBaseImpl& GetInstance();
			virtual ~PackManagerBaseImpl();
			//发送包(这里的retry_interval是以秒为单位的，各平台需要自己做转化)
			virtual void SendPack(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval, PackRspCallback rsp_cb, uint16_t seq_num = 0);
			
			void UpdatePushPackInfo(uint64_t device_id, PackType push_type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, uint16_t seq_num, const void *data, int data_length);

            //Use this method when you don't care about the response. When it return false, it might mean the link buffer is full.
            virtual bool DirectSendPack(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval);
			
			//发送包handler
			void SetReqHandler(PackReqHandle cb);
            void SetDirectReqHandler(PackDirectReqHandle cb);
            
			//注册监听
			virtual int RegisterPushPackInfoListener(PackType type, PackDataSourceCallback cb);
			virtual void unRegisterPushPackInfoListener(PackType type, int register_id);
		protected:
            PackManagerBaseImpl();
			virtual std::shared_ptr<VoidBuffer> GetRspData();
			virtual bool MockPackTimeout();
			virtual uint8_t MockPackRetCode();
		private:
			PackReqHandle req_handle_ = nullptr;
            PackDirectReqHandle direct_req_handle_ = nullptr;
			std::map<PackType, std::map<int, PackDataSourceCallback>> push_pack_info_listeners_;
			std::shared_ptr<Worker> work_queue_;
		};
	}
}

#endif /* djicommonpackmamanger_hpp */
