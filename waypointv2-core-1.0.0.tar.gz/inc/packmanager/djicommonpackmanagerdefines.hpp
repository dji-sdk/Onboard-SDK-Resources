//
//  djicommonpackmanagerdefines.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djicommonpackmanagerdefines_hpp
#define djicommonpackmanagerdefines_hpp

#include <functional>
#include "packmanager/djicommonpackmanagermcstructs.h"

namespace dji
{
	namespace common
	{
		enum PackType
		{
			//Push
			OFDMPushOsd,
			OFDMPushLowFreqOsd,
			MCPushGroundStationStatus,
			MCPushGroundStationEvent,
			
			//0x22, 0x01 初始化航线任务
			InitWaypointMission,
			//0x22, 0x02 上传航点信息
			UploadWaypointsInfo,
			//0x22, 0x03 开始结束航点
			StartStopWaypointMission,
			//0x22, 0x05 设置全局巡航速度
			SetGlobalCruiseSpeed,
			//0x22, 0x06 获取全局巡航速度
			GetGlobalCruiseSpeed,
			//0x22, 0x07 恢复暂停Mission
			PauseResumeWaypointMission,
			//0x22, 0x08 下载航线初始化信息
			DownloadInitInfo,
			//0x22, 0x09 下载航点信息
			DownloadWaypointMission,
			//0x22, 0x0D 获取飞控存储的最大航点数目
			GetMaxWaypointCount,
			//0x22, 0x0E 获取飞控存储的首尾航点索引
			GetStorageWaypointStartEndIndex,
			//0x22, 0x17 中断恢复Mission
			InterruptRecoverMission,
			//0x22, 0x18 上传航点Action配置
			UploadActionConfig,
            //0x22, 0x19 下载航点Action配置
			DownloadActionConfig,
			//0x22, 0x1B 当前面Mission状态推送
			StateDataInfoPush,
			//0x22, 0x1C 当前面Mission事件推送
			EventDataInfoPush,
            //0x22, 0x1E 获取Action存储的开始结束位置。
            GetStorageActionStartEndIndex,
			//0x22, 0x22 设置VOLT飞机的螺旋上升圆盘信息
			SetClimbCircleInfo,
			//0x22, 0x27 获取农机中断航点任务后的断点信息
			GetBreakPointInfo,
// Firmware Upgrade
            //00 07，请求进入loader模式
            EnterUpgradeModeRequest,
            //00 0c，请求设备当前状态，用于确认是否已进入loader模式
            QueryDeviceState,
            //00 08，请求设备接收固件数据
            FirmwareDataReceiveRequest,
            //00 09，传输固件包
            FirmwareDataTransfer,
            //00 2A，通用文件传输协议，230用改方式传输升级固件
            CommonFileTransfer,
            //00 0A，固件发送完毕需要发送end pack
            FirmwareDataTransferFinish,
            //00 0B，重启设备
            RebootDevice,
            //00 01，旧飞机获取固件版本号
            GetVersion,
            //00 42，推送包，用于监听固件升级进度
            UpgradeStatePush,
            //06 AB，推送包，用于文件传输流量控制
            TrafficControl,
            //00 4F，获取飞机文件
            GetDeviceFile,
			// End Firmware Upgrade
            //00 41 固件升级成功用于停止固件升级状态推送
            UpgradeSetAction,
#pragma mark - End Firmware Upgrade
			
			SendAppGPS,                 //03 20（发送app GPS）
			SendAppTFR,                 //03 3f（发送0期tfr）
			SendDJIFlightTFR,          //03 cd（发送3期tfr）
			SendLicenseData,            //11 10（发送license数据）
			SendUserId,                 //11 15（发送user_id）
			SendV1WhiteListData,      //03 41（发送v1白名单数据）
			RequestLicenseInfoList,    //11 11（请求飞控license item列表）
			RequestLicenseSwitchEnable,//11 12（设置飞控license item开关状态）
			QueryLicenseIdWithAreaId,//11 13（查询area_id所在license_id）
			QueryLicenseKeyVersion,    //11 16（查询飞控license key版本）
			RequestV1WhiteListEnable, //03 47（设置v1白名单开关状态）
			
			MCPushWhilteListInfo,
			MCPushUnlockInfo,
		};
		
		enum class PackState
		{
			Success    = 0,
			Timeout    = 1,
			Cancel     = 2,
		};
        
        enum DJIPackSenderType {
            DJIPackSenderType_None = 0,     //空
            DJIPackSenderType_Camera = 1,   //相机
            DJIPackSenderType_Mobile = 2,   //手机
            DJIPackSenderType_MC = 3,       //主控
            DJIPackSenderType_Gimbal = 4,   //云台
            DJIPackSenderType_Center = 5,   //中心板
            DJIPackSenderType_RC = 6,       //遥控器
            DJIPackSenderType_Wifi = 7,     //Wifi
            DJIPackSenderType_AirDM368 = 8, //天空DM368 或者1860, 385
            DJIPackSenderType_AirOFDM = 9,  //OFDM 1765
            DJIPackSenderType_PC = 10,      //PC
            DJIPackSenderType_Battery = 11, //电池
            DJIPackSenderType_ElectricallyControll = 12,  //电调
            DJIPackSenderType_GroundDM368 = 13, //地面端DM368
            DJIPackSenderType_GroundOFDM = 14,  //地面端(高清图传1765) 3c 072
            DJIPackSenderType_AirConvert = 15,  //串并转换(天空)
            DJIPackSenderType_GroundConvert = 16,   //串并转换(地面)
            DJIPackSenderType_SingleVision = 17,    //单目
            DJIPackSenderType_DJIFlight = 17,    //1860上负责飞控功能的模块，seq=5
            DJIPackSenderType_DoubleVision = 18,    //双目
            DJIPackSenderType_AirFPGA = 19,     //FPGA(射频基带)
            DJIPackSenderType_GroundFPGA = 20,  //FPGA(射频基带)
            DJIPackSenderType_Simulator = 21,
            DJIPackSenderType_Battery_Ronin2 = 23,
            DJIPackSenderType_IMU = 25, //外置IMU
            DJIPackSenderType_GPS = 26, //GPS
            DJIPackSenderType_GroundWifi = 27,//Wi-Fi模块（地面端）
            DJIPackSenderType_SignalConvert = 28, // seq = 0 农用机信号转换板; seq = 1 眼镜
            DJIPackSenderType_PMU = 29, //PMU 电源管理
            DJIPackSenderType_Radio = 31,    //广播
            DJIPackSenderType_All = 0xff,   //全集
            
            DJIPackSenderType_RTK = 0x1000,   //RTK
        };
        
        typedef enum
        {
            DJICmdTypeNoAck = 0, // 无须应答
            DJICmdTypeAckPush = 1, // 需要应答（在执行命令之前，先返回一个应答包，只包含返回码且固定为0x01，表示已经接收到该请求包。命令的执行结果则通过状态推送的方式来通知请求者）
            DJICmdTypeAckData = 2, // 需要应答（在命令执行完成后，返回响应包）
        } DJICmdType;

#pragma pack(1)
        typedef struct
        {
            uint8_t type:5;//发送/接收者类型
            uint8_t seq:3; //发送/接收者编号
        } DJIPackSenderStruct;
        
        typedef struct {
            uint8_t encry_type:4;  //加密类型   0 = 无加密
            //1 = AES加密
            //2 = 私有加密
            //3 = 自定义加密
            uint8_t reserve:1; //保留
            //是否需要应答，0无须应答，1 = 需要应答（在执行命令之前，先返回一个应答包，只包含返回码且固定为0x01，表示已经接收到该请求包。命令的执行结果则通过状态推送的方式来通知请求者）2 = 需要应答（在命令执行完成后，返回响应包）
            uint8_t is_need_res:2;
            bool is_response:1;   //是否应答包，否则是请求包
        } DJIPackCmdTypeStruct;

#pragma pack()
		//listen
		typedef std::function<void(uint64_t device_id, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, uint16_t seq_num, void *data, int data_length)> PackDataSourceCallback;
		//send
		//没有ret_code返回-1
		typedef std::function<void(PackState state, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *rsp_data, int rsp_data_length, uint8_t ret_code)> PackRspCallback;
		typedef std::function<void(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval, PackRspCallback rsp_cb, uint16_t seq_num)> PackReqHandle;
        typedef std::function<bool(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval)> PackDirectReqHandle;
	}
}

#endif /* djicommonpackmanagerdefines_hpp */
