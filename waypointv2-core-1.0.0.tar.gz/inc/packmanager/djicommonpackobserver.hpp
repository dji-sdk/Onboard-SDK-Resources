//
//  djicommonpackobserver.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djicommonpackobserver_hpp
#define djicommonpackobserver_hpp

#include <stdio.h>
#include <map>
#include "djicommonpackobserver.hpp"
#include "packmanager/djicommonpackmanagerdefines.hpp"

namespace dji
{
	namespace common
	{
		class PackObserver
		{
		public:
			PackObserver();
			~PackObserver();
			void SubscribePushInfo(PackType push_info_type, PackObserver *observer);
			int GetPushInfoRegisterId(PackType push_info_type);
		private:
			std::map<PackType, int> push_info_register_id_list_;
		};
	}
}
#endif /* djicommonpackobserver_hpp */
