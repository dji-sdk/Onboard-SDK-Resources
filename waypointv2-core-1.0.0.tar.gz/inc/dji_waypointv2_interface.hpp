#ifndef WAYPOINTV2_CORE_DJI_WAYPOINTV2_INTERFACE_HPP
#define WAYPOINTV2_CORE_DJI_WAYPOINTV2_INTERFACE_HPP

#include <functional>
#include <unordered_map>
#include <vector>

#include "dji_log.hpp"
#include "dji_command.hpp"
#include "dji_ack.hpp"
#include "dji_open_protocol.hpp"

// TODO change name and license thing
#include "WaypointV2.pb.h"

namespace DJI
{
namespace OSDK
{

class Vehicle;

class WaypointV2Interface
{
public:
  typedef int CommonErrorCode;
  typedef std::function<void(CommonErrorCode)> CommonErrorCallback;

  const double RAD_2_DEGREE = 57.2957795;

  WaypointV2Interface(Vehicle *vehicle);
  ~WaypointV2Interface();

  void start(CommonErrorCallback errorCallback);

  void stop(CommonErrorCallback errorCallback);

  void pause(CommonErrorCallback errorCallback);

  void resume(CommonErrorCallback errorCallback);

  void getCurrentSpeed(std::function<void(float cruise_speed, CommonErrorCode error_code)> callback);

  void setCurrentSpeed(float speed, CommonErrorCallback errorCallback);

  void updatePushData(uint8_t cmd_id, uint16_t seq_num, const void *data, int data_length);

  void uploadMission(const WayPointInitSettings &initSettings,
                     const std::vector<WayPointSettings> &waypts,
                     CommonErrorCallback errorCallback);

  void uploadMission(const dji::waypointv2::WaypointMission &waypointMission,
                     CommonErrorCallback errorCallback);

  bool DownloadMission(dji::waypointv2::WaypointMission &outMission,
                       CommonErrorCallback errorCallback);

  void uploadAction(const std::vector<dji::waypointv2::WaypointActionConfig> &actions,
                    CommonErrorCallback errorCallback);

  inline dji::waypointv2::AbstractionState getCurrentState() { return currentState; }

  inline dji::waypointv2::AbstractionState getPrevState() { return prevState; }

  inline dji::waypointv2::ActionState getCurrentActionState() { return currentActionState; }

  inline dji::waypointv2::ActionState getPrevActionState() { return prevActionState; }

protected:
  void setUpCMDMap();

  void setUpStateMsgMap();

  void setUpActionStateMsgMap();

  static void sendCmdCallback(Vehicle *vehiclePtr, RecvContainer recvFrame,
                              UserData userData);

protected:
  Vehicle* vehiclePtr;

  int kDeviceID;

  WayPointInitSettings info;

  std::unordered_map<int, const uint8_t*> cmdMap;
  std::unordered_map<int, const char*> stateMsgMap;
  std::unordered_map<int, const char*> actionStateMsgMap;
  dji::waypointv2::AbstractionState prevState;
  dji::waypointv2::AbstractionState currentState;
  dji::waypointv2::ActionState prevActionState;
  dji::waypointv2::ActionState currentActionState;
};
} // namespace OSDK
} // namespace DJI

#endif //WAYPOINTV2_CORE_DJI_WAYPOINTV2_INTERFACE_HPP
