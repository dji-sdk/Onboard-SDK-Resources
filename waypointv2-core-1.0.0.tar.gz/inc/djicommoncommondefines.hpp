//
//  djicommoncommondefines.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djicommoncommondefines_hpp
#define djicommoncommondefines_hpp

#include <stdio.h>
#include <string>
#include <functional>
#include <vector>

namespace dji {
	namespace common {
		enum class RCMode
		{
			//master模式下，限飞功能按照正常逻辑跑
			Master,
			//slave模式下，不上传限飞数据，精准数据库不考虑升级，限飞和解禁不弹窗，白名单入口去掉
			Slave,
		};
		
		enum class MCModeType {
			Manual = 0,   //手动档
			Atti = 1,     //姿态档
			Atti_CL = 2,  //姿态档下的Course Lock
			Atti_Hover = 3,   //姿态档下悬停
			Hover = 4,    //悬停中(需要跟飞控确认跟GPS_Atti有什么区别)
			GPS_Blake = 5,    //刹车中
			GPS_Atti = 6, //GPS档
			GPS_CL = 7,   //GPS档下的Course Lock
			GPS_HomeLock = 8, //GPS档下的Home Lock
			GPS_HotPoint = 9, //GPS档下的热点环绕
			AssistedTakeOff = 10, //摇杆起飞
			AutoTakeOff = 11, //一键起飞
			AutoLanding = 12, //GPS档降落
			AttiLanding = 13, //姿态档下降落
			Navi_Go = 14, //waypoint模式，地面站
			Go_Home = 15, //返航
			Click_Go = 16,    //单点地面站
			Joystick = 17,    //摇杆模式
			GPS_Atti_Wristband = 18, //手环模式
			Cinematic = 19,//电影院模式，mavic新固件支持
			Atti_Limited = 23,    //姿态限高
			Draw = 24,    //画线飞行
			Follow_Me = 25,   //跟随
			Vision_Tracking = 26, //p4 视觉跟随
			Vision_TapToGo = 27, //p4 指点飞行
			Pano = 28, //pano
			Farming = 29, //植保
			FPV = 30, //FPV? 好像是给穿越机用的
			GPS_Sport = 31, //运动模式
			GPS_Begineer = 32, //新手模式
			TouchDownLanding = 33, //30cm限低降落模式，需要确认才能落地
			NOE = 35, //noe 地形跟随模式，demo for wm220
			GestureControl = 36, //手势控制模式，for wm100
			QuickMovie = 37, //一键短片模式，for wm100
			TripodGPS = 38, //  三脚架模式，demo for wm220
			Vision_Tracking_CourceLock = 39, //  tracking中的course lock 模式。
			EngineStart = 41, //电机起转的那一瞬间，从mavic第二版用户固件开始
			FixedWing = 42, //固定翼，目前弃用
			AutoAvoid = 43, //打杆避障功能 ，等同于GPS_Atti
			OnHandTakeOff = 44, //掌上起飞
		};
		
		enum class DroneType {
			Unknown = 0,   //未知
			Inspire = 1,
			P3S = 2,
			P3X = 3,
			P3C = 4,   //P3C
			N1 = 5,    //开放式机架
			ACEONE = 6,
			WKM = 7,
			NAZA = 8,
			A2 = 9,
			A3 = 10,
			P4 = 11,
			A2_ARG = 12,
			A3_IMU = 13,
			A3_PM820 = 14,
			P3_4K = 15,
			WM220 = 16,
			Inspire2 = 17,
			P4P = 18,
			N3 = 20,
			WM100 = 21,
			A3_PM820Pro = 23,
			WM230 = 24, //eagle1
			M200 = 25,   //行业200
			N3_AGR = 26,
			P4A = 27,
			M210 = 28,   //行业210 双云台
			P3SE = 29, //P3SE 魔改版本P3C，
			M210RTK = 30,   //210+RTK
			
			PM930 = 33, //930的飞控枚举
			P4E = 34, //p4e
			P4P_SDR = 36, //p4p+sdr
			OtherMC = 0xff,    //其他的飞控
		};
		//遥控器类型
        enum class RCDroneType {
            Unknown          = 0,
            Inspire          = 1,
            Phantom3Xor3S    = 2,
            Phantom3C        = 3,
            LightBridge      = 4,
            Phantom3XW       = 5,
            SDR              = 6, //sdr rc for wm220
            In2              = 7,
            TomatoPro        = 8,
            WM100            = 9, //WM100 遥控器
            Datalink3        = 10, //datalink3
            GL300I           = 11, //P4A 遥控器
            Phantom3SE       = 12, //P3SE 遥控器
            IN2ProfessinalRC = 13,//专业版遥控器
            //230 的遥控器，可以用在 wm230 和 wm100
            WM230            = 14,
            GL300L           = 15, //P4P+SDR 遥控器
        };
		
		enum class ProductType {
			None = 0x00,
			Banana = 0x01,     //Inspire1
			LitchiC = 0x02,    //Phantom3C
			LitchiS = 0x03,    //Phantom3S
			LitchiX = 0x04,    //Phantom3X
			Longan = 0x05,   //手持云台，代号:龙眼
			N1 = 0x06,   //N1的界面
			TomatoX = 0x07, //p4
			LightBridge2 = 0x08, //LightBridge2，高清图传2
			BigBanana = 0x09,    //Inspire1配大相机(等待删除,改用其他方式)
			A3 = 10, //A3飞控
			PM820 = 11, //M600
			P3_4K = 12, //wifi 3x
			WM220 = 13, //小飞机
			XT = 14, //Flir相机独立的产品
			INSPIRE_RAW = 15,
			DJIDiscardProductType_andoird_A2 = 16, //不再使用16这个数字，andoird使用了16来代表a2+lb2
			Orange = 17,//inspire2
			OSMOX5 = 18, //x5
			OSMOX5R = 19, //x5R
			OSMOCV600 = 20, //x3.5
			WM22L = 21, //小飞机低端版
			HG300 = 22, //手机OSMO
			INSPIRE_ZOOM = 23,//inspire zoom x3.5
			TomatoPro = 24, // P4P
			N3 = 25,  //N3
			WM100 = 26, // WM100
			PM820Pro = 27, // M600 Pro
			TomatoAdvanced = 28, // P4A
			P3SE = 29, //P3c魔改版，P3SE
			AG405 = 30, //农业机
			
			M200 = 31, //M200 行业机
			WristWatch = 32, //手环
			M210 = 33, //M210 行业机（挂双云台）
			M210RTK = 34, //M210RTK 行业机（带RTK）
			
			DataLink3 = 37, // DataLink 3 (USB/行业应DataLink3单遥控器)
			
			WM230 = 38, //eagle 平台小飞机，代号: Unicorn
			
			Garlic = 39,//pm930 8旋翼系列
			
			HG301 = 45, //Osmo mobile2
			
			Ronin2 = 0xFE, //ronin2
			
			NotSupported = 0xFF, //不支持的产品
			
			ProductTypeCount,
		};  //用于标识产品
		
        enum class SystemLanguage {
            Chinese         = 0,
            Englist         = 1,
            Japanese        = 2,
        };
        
        enum DeviceEvent {
            //注册设备
            DeviceRegister,
            //注销设备
            DeviceUnregister,
            //飞控连上
            DeviceFlightControllerConnect,
            //飞控断连
            DeviceFlightControllerDisconnect,
            //设备连接状态改变（关心具体哪个设备断开连接）
            DeviceConnectedStateChange,
            //某个设备位置发生变化
            DeviceLocationChange,
            //某个设备遥控器主从机模式发生变化
            DeviceRCModeStateChange,
            //某个设备飞控序列号发生变化
            DeviceSerialNumberChange,
            //某个设备起桨状态发生变化
            DeviceMotorOnStateChange,
            //某个设备是否支持动态数据库
            DeviceSupportDynamicDBStateChange,
            //某个设备是否使用DJIFlightDB
            DeviceUseDJIFlightDBStateChange,
            //在限飞区内起飞失败
            DeviceTakeOffFailedInFlyLimitZone,
            //解禁区域发生变化
            DeviceUnlockAreaIdsStateChange,
            //隐藏版本号发生变化
            DeviceMCProtocolVersionChange,
            //GO Home或者智能模式状态发生变化
            DeviceModeStateChange,
            //license unlcok状态发生变化
            DeviceLicenseUnlockStateChange,
            //设备的产品码发生改变
            DeviceProductCodeChange,
			//是否支持WPV2发生状态改变。
			DeviceWPV2SupportedCahnge,
        };
        
        enum class SystemEvent {
            //网络状态改变
            NetworkChanged,
            //手机位置改变
            PhoneLocationChanged,
            //用户账号改变
            AccountChanged,
            //国家码变化
            CountryCodeChanged,
        };
        
        struct Location {
            double latitude;
            double longitude;
            double height;
        };
        
		typedef std::function<std::string()> ReturnStringValueHandle;
		typedef std::function<bool()> ReturnBoolValueHandle;
        typedef std::function<SystemLanguage()> ReturnSystemLanguageValueHandle;
		typedef std::function<void(const char *fmt)> LogActionHandle;
		//device
		typedef std::function<bool(uint64_t)> ReturnDeviceBoolValueHandle;
		typedef std::function<RCMode(uint64_t)> ReturnDeviceRCModeValueHandle;
		typedef std::function<std::string(uint64_t)> ReturnDeviceStringValueHandle;
		typedef std::function<int(uint64_t)> ReturnDeviceIntValueHandle;
		typedef std::function<std::vector<uint64_t>(uint64_t)> ReturnDeviceIntVectorValueHandle;
		typedef std::function<DroneType(uint64_t)> ReturnDeviceDroneTypeValueHandle;
        typedef std::function<RCDroneType(uint64_t)> ReturnDeviceRCDroneTypeValueHandle;
		typedef std::function<ProductType(uint64_t)> ReturnDeviceProductTypeValueHandle;

		typedef int CommonErrorCode;
		//callbacks
		typedef std::function<void(CommonErrorCode)> CommonErrorCallback;
		typedef std::function<void(bool)> BoolValueCallback;
		typedef std::function<void(int)> IntValueCallback;
		typedef std::function<void(bool, int)> AppTFRUploadCallback;
		typedef std::function<void(bool, const std::string &, const std::string &)> DJIFlightTFRUploadCallback;
		typedef std::function<Location()> ReturnLocationValueHandle;
		typedef std::function<Location(uint64_t)> ReturnDeviceLocationValueHandle;
	}
}

#endif /* djicommoncommondefines_hpp */
