#ifndef __buffer__
#define __buffer__
#include <memory>
#if defined (__linux__)
#include <cstring>
#endif

namespace dji
{
    namespace common
    {

        class  Buffer
        {
        public:
            Buffer(const unsigned char* p = nullptr, unsigned int dlen = 0);
            Buffer(const Buffer& src);
            virtual ~Buffer(void){ clear(); }

            Buffer&    operator = (const Buffer& src);
            Buffer&    operator += (const Buffer& src)
            {
                return append(src, src.size());
            }

            Buffer&    assign(const unsigned char* p, unsigned int dlen);
            void	   attach(unsigned char* p, unsigned int dlen);
            unsigned char*	   detach();
            Buffer&    append(const unsigned char* p, unsigned int dlen);
            Buffer&    replace(unsigned int pos, unsigned int dlen, const unsigned char* tar, unsigned int tarlen);

            void        resize(unsigned int newlen);

            inline void clear(void) { assign(nullptr, 0); }

            inline bool operator ==(const Buffer& _R) const {
                return (len == _R.len) && (len == 0 || (memcmp(data, _R.data, len * sizeof(unsigned char)) == 0));
            }

            inline bool operator !=(const Buffer& _R) const {
                return !operator==(_R);
            }

            inline bool operator < (const Buffer& _R) const
            {
                if (data == NULL || _R.data == NULL){ return data < _R.data ? true : false; }
                unsigned int  minlen = len > _R.len ? _R.len : len;
                int mv = memcmp(data, _R.data, minlen * sizeof(unsigned char));
                if (mv == 0) {
                    if (len <= _R.len) {
                        return false;
                    }
                }
                return mv < 0 ? true : false;
            }

            bool     bits(unsigned int _i) const;
            void     bitset(unsigned int _i, bool v);
            void     bitsmerge(const Buffer& src);
            void     bitsand(const Buffer& src);

            inline unsigned char&		at(unsigned int pos) { return data[pos]; }
            inline const unsigned char&	at(unsigned int pos) const { return data[pos]; }
            inline unsigned char&		operator [] (unsigned int pos) { return data[pos]; }
            inline const unsigned char&	operator [] (unsigned int pos) const { return data[pos]; }
            inline				operator unsigned char* (void) const { return data; }
            inline unsigned int		size(void) const { return len; }

        private:
            unsigned int      grow(unsigned int newlen);
            unsigned int      shrink(unsigned int newlen);

        private:
            unsigned int		room;
            unsigned int		len;
            unsigned char*		data;
        };
    }
}
#endif
