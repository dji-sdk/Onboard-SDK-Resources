//
//  dji_waypointv2_engine.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 03/07/2018.
//

#ifndef dji_waypointv2_engine_hpp
#define dji_waypointv2_engine_hpp

#include <stdio.h>
#include <djicommoncommondefines.hpp>
#include <memory>
#include <WaypointV2.pb.h>
#include <WaypointV1.pb.h>
#include <dji_waypointv2_defines.hpp>

#define kInvalidDeviceId -1

namespace dji {
	namespace waypointv2 {
		
		using namespace common;
		class WaypointMission;
		class WaypointActionConfig;
		
// Device Manage
		
		//启动WaypointV2功能模块，主要负责设备连接以及断开连接后注册/销毁对应设备的Waypoint Abstraction.
		void StartWaypointV2Module();
		
		//Waypoint Mission Abstraction 状态回调接口
		void SetWaypointStateChangeCallback(WaypointStateChangeCallback stateChangeCallback, CommonErrorCallback callback);

		//Action状态回调接口
        void SetActionStateChangeCallback(ActionStateChangeCallback stateChangeCallback, CommonErrorCallback callback);
		
		//设置当前是否支持V1 Adaptor
		void SetIsWaypointV1AdaptorSupported(bool is_supported);
		
        //V1状态回调
        void SetV1WaypointStateChangeCallback(V1WaypointStateChangeCallback v1_state_change_callback, CommonErrorCallback callback);
		
        //上传V1 Mission到飞机
        void UploadV1MissionData(uint64_t device_id, const waypointv1::V1WaypointMission& mission, const LocationCoordinate& ref_location, CommonErrorCallback callback);
        
        //重传V1 Mission到飞机
        void RetryV1UploadData(uint64_t device_id, CommonErrorCallback callback);
        
        //获取V1 Mission飞行轨迹。
        void GetV1FlightPathCoordinates(uint64_t device_id, const waypointv1::V1WaypointMission& mission, const LocationCoordinate& ref_location, std::function<void(const std::vector<LocationCoordinate>&)> callback);
        
        //下载得到一个V1版本的Mission
        void DownloadV1Mission(uint64_t device_id,  CommonErrorCallback callback);
        
        //获取当前正在执行的V1 Mission
        waypointv1::V1WaypointMission GetCachedV1Mission(uint64_t device_id);
        
		//上传Mission到飞机
		void UploadMissionData(uint64_t device_id, const waypointv2::WaypointMission& mission, CommonErrorCallback callback);
		
        //取消当前正在上传的Mission
        void CancelUploadMission(uint64_t device_id, CommonErrorCallback callback);
        
		//获取Mission飞行轨迹。
		void GetFlightPathCoordinates(uint64_t device_id, const waypointv2::WaypointMission& mission, std::function<void(const std::vector<LocationCoordinate>&)> callback);
        
		//重传航点信息
		void RetryUploadData(uint64_t device_id, CommonErrorCallback callback);
		
		//下载正在执行的Mission, 下载后会存储起来。 通过 GetCachedMission 获取
		void DownloadMission(uint64_t device_id,  CommonErrorCallback callback);
        
		//获取当前正在执行的Mission
		WaypointMission GetCachedMission(uint64_t device_id);
		
		////获取当前正在执行State
		AbstractionState GetCurrentAbstractionState(uint64_t device_id);
		
        uint16_t GetActionCount(uint64_t device_id);
        
		//上传Action 配置信息
		void UploadActionData(uint64_t device_id, const std::vector<WaypointActionConfig>& action_configs, CommonErrorCallback callback);
		
		//下载Action 配置信息
		void DownloadActionData(uint64_t device_id,  CommonErrorCallback callback);
		
		//开始Mission.
		void StartMission(uint64_t device_id, CommonErrorCallback callback);
		
		//停止Mission.
		void StopMission(uint64_t device_id, CommonErrorCallback callback);
		
		//暂停Mission
		void PauseMission(uint64_t device_id, CommonErrorCallback callback);
		
		//恢复Mission
		void ResumeMission(uint64_t device_id, CommonErrorCallback callback);
	
		//中断Mission
		void InterruptMission(uint64_t device_id, CommonErrorCallback callback);
		
		//恢复Mission，中断后使用
		void RecoverMission(uint64_t device_id, InterruptRecoverAction action, CommonErrorCallback callback);
		
		//获取当前飞机巡航速度
		void GetCruiseSpeed(uint64_t device_id, std::function<void(float cruise_speed, CommonErrorCode error_code)> callback);
		
		//设置当前飞机巡航速度
		void SetCruiseSpeed(uint64_t device_id, float cruise_speed, CommonErrorCallback callback);
	
		//获取存储Action当前存储信息
		void GetStorageActionStartEndIndex(uint64_t device_id, std::function<void(uint16_t start_index, uint16_t end_index, CommonErrorCode)> callback);
	}
}


#endif /* dji_waypointv2_engine_hpp */
