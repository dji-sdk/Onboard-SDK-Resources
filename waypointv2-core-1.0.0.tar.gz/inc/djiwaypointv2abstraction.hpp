//
//  djiwaypointv2abstraction.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djiwaypointv2abstraction_hpp
#define djiwaypointv2abstraction_hpp

#include <djicommonlifecycle.hpp>
#include <packmanager/djicommonpackmamanger.hpp>
#include <device/djicommondevicestateprovider.hpp>
#include <djiflysafeasynccaptureprotect.h>
#include <proto/WaypointV2.pb.h>
#include "djiwaypointv2abstractionfsmbase.hpp"
#include "djiwaypointv2actionfsmbase.hpp"
#include <djiwaypointv2logicmanager.hpp>
#include "djiwaypointv2abstractioncachedata.hpp"
#include <dji_waypointv2_sdk_error.hpp>
#include "djiwaypointv2fsmtempstatetimer.hpp"
#include <dji_waypointv2_protocol_struct_defines.hpp>
#include <dji_waypointv2_pack_manager.hpp>

#define TEST_UPLOAD_WAYPOINT_SPEED (1)
#define TEST_DOWNLOAD_WAYPOINT_SPEED (1)

#define TEST_UPLOAD_ACTION_SPEED (1)
#define TEST_DOWNLOAD_ACTION_SPEED (1)


namespace dji {
	namespace waypointv2 {
		using namespace common;
		
		struct BaseWaypointPackConfig {
			DJIPackSenderStruct sender_;
			DJIPackSenderStruct receiver_;
		};
		
		class DeviceState {
		public:
			bool is_connected_ = false;
			ProductType product_type_ = ProductType::None;
			bool is_wpv2_supported_ = true;
		};
		
		class Abstraction : public ILifeCycle, public AbstractionFSMBase, public ActionFSMBase,  public AsyncCaptureProtect {
		public:
			Abstraction(uint64_t device_id);
			virtual ~Abstraction();
			virtual void Setup();
			virtual void Cleanup();
			virtual void SetupFSM();
            virtual void SetupActionFSM();
			void Reset();
			void StartListen();
			void StopListen();
		public:
			void InitializeMission(const std::shared_ptr<WaypointMission> mission, CommonErrorCallback callback);
            
            void RecursiveUploadData(const std::shared_ptr<WaypointMission> mission, int start_index, int end_index, bool is_retry_upload, CommonErrorCallback callback);
			void UploadData(const std::shared_ptr<WaypointMission> mission, CommonErrorCallback callback);
			void RetryUploadData(CommonErrorCallback callback);
			void CancelUploadMission(CommonErrorCallback callback);
            
			void DownloadInitializeInformation(std::function<void(std::shared_ptr<WaypointMission>, CommonErrorCode)> callback);
			void RecursiveDownloadWaypointsData(std::shared_ptr<WaypointMission> mission, int start_index, int end_index, int total_end_index, CommonErrorCallback callback);
			void GetStorageWaypointStartEndIndex(std::function<void(uint16_t startIndex, uint16_t endIndex, CommonErrorCode error_code)>);
			WaypointMission GetCachedMission();
			AbstractionState GetCurrentAbstractionState();
            uint16_t GetActionCount();
            
			void DownloadMisson(CommonErrorCallback callback);
			void StartMisson(CommonErrorCallback callback);
			void StopMission(CommonErrorCallback callback);
			void PauseMission(CommonErrorCallback callback);
			void ResumeMission(CommonErrorCallback callback);
/*********************************************************************************/
#pragma mark - MG Only
/*********************************************************************************/
			
			void InterruptMission(CommonErrorCallback callback);
			void RecoverMission(InterruptRecoverAction recoveAction,  CommonErrorCallback callback);
			
/*********************************************************************************/
#pragma mark - Property
/*********************************************************************************/
			
			void GetCruiseSpeed(std::function<void(float cruise_speed, CommonErrorCode error_code)> callback);
			void SetCruiseSpeed(float cruise_speed, CommonErrorCallback callback);
			
/*********************************************************************************/
#pragma mark - Actions
/*********************************************************************************/
			
			void GetStorageActionStartEndIndex(std::function<void(uint16_t start_index, uint16_t end_index, CommonErrorCode)> callback);
			void UploadActionData(const std::vector<WaypointActionConfig>& action_configs, CommonErrorCallback callback);
			void RecursiveUploadActionData(const std::vector<WaypointActionConfig>& action_configs, int start_index, int end_index,  bool is_retry_upload, std::function<void(CommonErrorCode error_code, int error_action_index)> callback);
            void RetryUploadActionData(CommonErrorCallback callback);
			void DownloadActionData(CommonErrorCallback callback);
            void TriggerActionDownloadEvent(const std::vector<WaypointActionConfig> action_list, CommonErrorCode error_code);
            void RecursiveDownloadActionData(std::vector<WaypointActionConfig>& result_actions, uint16_t start_index, uint16_t end_index, uint16_t total_index, CommonErrorCallback callback);
            std::vector<WaypointActionConfig> GetCachedActions();
            
		public:
      common::DeviceStateProvider& DeviceStateProvider();
      waypointv2::PackManager& PackManager();
		public:
			void TryResumeFSMIfNecessary();
			AbstractionState ComputeCurrentState();
            ActionState ComputeCurrentActionState(AbstractionState abstraction_state);
            void RecoverExecutingMission();
            void RecoverActionCacheInformations();
            
			void InitDeviceStates();
			void DeviceStateChanged(DeviceEvent event);
			void UpdateDeviceStates(DeviceEvent event);
			void OnDeviceConnectedStateChangeChanged();
			void OnDeviceProductCodeChanged();
			void OnDeviceSupportWPV2Changed();
            void OnDeviceDisconnected();
            
			void OnMCPushGroundStationStatus(uint64_t device_id, const void *data, int data_length);
            void SendMCPushStationEvent(uint64_t device_id, uint16_t seq_num);
            void OnMCPushGroundStationEvent(uint64_t device_id, uint16_t seq_num, const void *data, int data_length);
            
			void OnInterruptEventReceived(const void *data, int data_length);
            void OnRecoverEventReceived(const void *data, int data_length);
            void OnFinishedEventReceived(const void *data, int data_length);
            
            bool CanDownloadMission();
			static CommonErrorCode CanDownloadMissionInState(AbstractionState state);
			AbstractionState GetStateFromMissionStatus(uint8_t gs_state_value);
			AbstractionEvent GetEventFromMissionStatus(dji_fc2_set_API_WP2_DATA_PUSH_req status);
            
            std::string GetExecutionProgressWithEvent(dji_fc2_set_API_WP2_EVENT_DATA_PUSH_req* event, int data_length);
            std::string GetExecutionActionProgressWithEvent(dji_fc2_set_API_WP2_EVENT_DATA_PUSH_req* gs_mission_event_data, int data_length, ActionEvent& event);
            WaypointExecuteData GetCurrentExecutionProgres();
			AbstractErrorCode GetCurrentError();
            
		private:
			static CommonErrorCode GenerateRecPackWithDefaultResultCode(PackState state, const void *rsp_data, int rsp_data_length);
			BaseWaypointPackConfig GetDJIFlightPackConfig();
			BaseWaypointPackConfig GetDJIMCPackConfig();
			ProtocolExecuteState CalculateProtocolGSState(uint8_t);
			
			bool TryTransitToUpdateStateForWaypointUpload(int index, AbstractErrorCode error, const std::shared_ptr<WaypointMission> mission);
            bool TryTransitToUpdateActionState(int index, AbstractErrorCode error, const std::vector<WaypointActionConfig> action_configs);
            void TriggerDownloadEvent(std::shared_ptr<WaypointMission> result_mission, CommonErrorCode error_code);
		private:
			//Useless now
			void GetFCMaxCacheWaypointCount();
            void GetFCMaxCacheWaypointCount(std::function<void(uint16_t fc_max_cache_point_count, CommonErrorCode error_code)>);

		private:
			uint64_t device_id_ = 0;
			DeviceState device_state_;
            bool is_downloading_ = false;
            bool is_downloading_action_ = false;
			bool is_recovering_ = false;
            bool is_recovering_action_info_ = false;
			uint32_t event_timestamp_ = 0;

			
			AbstractionState candidate_state_ = AbstractionStateUnknown;
			AbstractionCacheData* cache_data_ = nullptr;
			std::map<PackType, int> push_pack_register_map_;
			
			uint16_t fc_max_cache_waypoint_count_ = 0;
			
#pragma mark - Help Test Methods
            
            int64_t GetCurrentTime();
			
			void RecordUploadWaypointStartPosition(int start_index, long timestamp);
			void LogUploadWaypointSpeedForWaypoint(int end_index, CommonErrorCode error_code);

            void RecordUploadOneWaypointStartPosition(int start_index, int bytes_size, int64_t timestamp);
            void LogUploadOneWaypointSpeedForWaypoint(int end_index, CommonErrorCode error_code);

            void RecordUploadOneActionStartPosition(int start_index, int bytes_size, int64_t timestamp);
            void LogUploadOneActionSpeedForWaypoint(int end_index, CommonErrorCode error_code);
            
			void RecordUploadActionStartPosition(int start_index, long timestamp);
			void LogUploadActionSpeedForWaypoint(int end_index, CommonErrorCode error_code);

			void RecordDownloadWaypointStartPosition(int start_index, long timestamp);
			void LogDownloadSpeedForWaypoint(int end_index, CommonErrorCode error_code);

            int send_pack_size_ = 0;
            
#if (TEST_UPLOAD_WAYPOINT_SPEED)
			long start_upload_waypoint_time_stamp_ = 0;
			int start_upload_waypoint_index_ = 0;
            
            int64_t start_send_one_pack_waypoint_time_stamp_ = 0;
            int send_one_pack_size_ = 0;
#endif
			
#if (TEST_UPLOAD_ACTION_SPEED)
			int start_upload_actions_index_ = 0;
            long start_upload_actions_time_stamp_ = 0;
            
            int64_t start_send_one_pack_action_time_stamp_ = 0;
            int send_one_action_pack_size_ = 0;
#endif
			
#if (TEST_DOWNLOAD_WAYPOINT_SPEED)
			long start_download_waypoint_time_stamp_ = 0;
			int start_download_waypoint_index_ = 0;
#endif
			
		};
	}
}

#endif /* djiwaypointv2abstraction_hpp */
