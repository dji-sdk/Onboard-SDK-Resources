//
//  djicommonwhiteboxkeychain.hpp
//  DJIcommonCore
//
//  Created by Tim Lee on 13/12/2017.
//

#ifndef djicommonwhiteboxkeychain_hpp
#define djicommonwhiteboxkeychain_hpp

#include <stdio.h>
#include <string>

namespace dji {
	namespace common {
		enum class DJIWhiteBoxKeyChainInfoIndex {
			DJIGOGEOFenceSignatureKey,
			DJIGEO1860DBAESKey,
			DJISDKFenceSignatureKey,
			DJIcommonCircleTFRPublicKey,
			DJIcommonCircleDBSecretKey,
			DJIAirmapKey,
			DJIAirmapSignatureKey,
			DJINFZSignatureKey,
            DJIcommonAppId,
            DJIcommonAppSecret,
            DJIcommonPreciseDBSecretKey,
            DJIUpgradeCfgSignKey,
		};
		
		/**
		 返回敏感数据的表示，如果敏感数据不能转换成字符串返回nil
		 @param access_key_index 密钥序号
		 */
		std::string GetWhiteBoxKeyChainString(DJIWhiteBoxKeyChainInfoIndex access_key_index);
	}
}

#endif /* djicommonwhiteboxkeychain_hpp */
