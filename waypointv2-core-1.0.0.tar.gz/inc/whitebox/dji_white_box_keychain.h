//
//  dji_white_box_keychain.h
//  DJIAppService
//
//  Created by sunny.li on 2017/7/31.
//  Copyright © 2017年 DJI. All rights reserved.
//

#ifndef dji_white_box_keychain_h
#define dji_white_box_keychain_h

#include <sys/types.h>
#include <stdint.h>

struct dji_key_chain_info
{
    uint8_t *data;
    uint32_t length;
    uint8_t *iv;
};

struct dji_key_chain_info get_key_chain_info_for_index_csdk(uint64_t index);

#endif /* dji_white_box_keychain_h */
