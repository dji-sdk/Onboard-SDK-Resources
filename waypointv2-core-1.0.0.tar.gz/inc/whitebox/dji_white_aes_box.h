//
//  dji_white_aes_box.h
//  DJIAppService
//
//  Created by sunny.li on 2017/7/27.
//  Copyright © 2017年 DJI. All rights reserved.
//

#ifndef dji_white_aes_box_h
#define dji_white_aes_box_h

#include <stdio.h>
#include <stdint.h>

// 加解密使用的是CBC方式
/**
 使用白盒加密进行加密

 @param inData 需要加密的数据指针
 @param inLength 需要加密的数据长度
 @param outData 输出加密后的数据，需要使用free进行释放，如果失败返回NULL
 @param iv 初始化向量，长度必须是16字节
 @return 加密后数据的长度，加密失败返回长度0
 */
int dji_white_box_encrypt(uint8_t *inData, uint32_t inLength, uint8_t **outData, uint8_t *iv);

/**
 使用白盒加密进行解密

 @param inData 需要解密的数据
 @param inLength 需要解密数据的长度
 @param outData 输出解密后的数据，需要使用free进行释放，如果失败返回NULL
 @param iv 初始化向量，长度必须是16字节
 @return 解密后数据的长度，解密失败返回长度0
 */
int dji_white_box_decrypt(uint8_t *inData, uint32_t inLength, uint8_t **outData, uint8_t *iv);

#endif /* dji_white_aes_box_h */
