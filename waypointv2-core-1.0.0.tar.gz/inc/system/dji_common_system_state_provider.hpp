//
//  dji_common_system_state_provider.hpp
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/13.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_system_state_provider_hpp
#define dji_common_system_state_provider_hpp

#include <stdio.h>
#include <djicommoncommondefines.hpp>

namespace dji {
    namespace  common {
        //此类用于拿上层一些系统状态的接口类
        class SystemStateProvider {
        public:
            SystemStateProvider(const SystemStateProvider&) = delete;
            SystemStateProvider& operator=(const SystemStateProvider&) = delete;
            
            virtual bool IsNetworkConnected() const;
            //暂时不需要系统位置
            virtual Location GetPhoneLocation() const;
            virtual std::string GetCountryCode() const;
            std::string GetClientVersion() const;
            std::string GetClientOS() const;
            SystemLanguage GetClientLanguage() const;
            void SetIsNetworkConnectedHandle(ReturnBoolValueHandle handle);
            void SetPhoneLocationHandle(ReturnLocationValueHandle handle);
            void SetCountryCodeHandle(ReturnStringValueHandle handle);
            void SetClientVersionHandle(ReturnStringValueHandle handle);
            void SetClientOSHandle(ReturnStringValueHandle handle);
            void SetClientLanguageHandle(ReturnSystemLanguageValueHandle handle);
            
            static SystemStateProvider& GetInstance();
        protected:
            virtual ~SystemStateProvider() {};
            SystemStateProvider(){};
        private:
            ReturnBoolValueHandle is_networking_connected_handle_;
            ReturnLocationValueHandle get_phone_location_handle_;
            ReturnStringValueHandle get_country_code_handle_;
            ReturnStringValueHandle get_client_version_handle_;
            ReturnStringValueHandle get_client_os_handle_;
            ReturnSystemLanguageValueHandle get_client_language_handle_;
        };
    }
}

#endif /* dji_common_system_state_provider_hpp */
