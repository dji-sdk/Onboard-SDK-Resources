//
//  dji_waypointv2_waypointv1_adapter.hpp
//  DJIWaypointV2Core
//
//  Created by DJI on 2018/12/28.
//

#ifndef dji_waypointv2_waypointv1_adapter_hpp
#define dji_waypointv2_waypointv1_adapter_hpp

#include <WaypointV2.pb.h>
#include <WaypointV1.pb.h>
#include <memory>

namespace dji {
    namespace waypointv2 {
        
        using namespace waypointv1;
        
        class V1WaypointStateListenerWrapper;
        class Abstraction;
        
        class V1WaypointToV2Adaptor {
        public:
            void SetupAbstraction(uint64_t device_id, const std::shared_ptr<Abstraction> abstraction, const std::shared_ptr<V1WaypointStateListenerWrapper> wrapper);
            void CleanupAbstraction();
        public:
            void OnV1MissionStartUpload(const std::shared_ptr<waypointv1::V1WaypointMission> v1_mission_ptr, const std::shared_ptr<waypointv2::WaypointMission> v2_mission_ptr, const std::vector<WaypointActionConfig> actions);
            void OnV1MissionStartDownload();
            void OnV1MissionDownloaded();
            void OnAbstractionStateUpdate(AbstractionState prev_state, AbstractionState cur_state, AbstractionEvent event, const std::string& data_infos);
            void OnActionStateUpdate(ActionState prev_state, ActionState cur_state, ActionEvent event, const std::string& data_infos);
            
            V1AbstractionState GetV1AbstractionState(AbstractionState state);
            V1AbstractionEvent GetV1AbstractionEvent(AbstractionEvent event);
            V1AbstractionEvent GetV1AbstractionEvent(ActionEvent event);
            V1ExecuteState GetV1ExecuteState(ExecuteState exec_state);
            
            
            bool IsWaypointInRetryUploadState();
            bool IsActionInRetryUploadState();
            
            void ResetUploadState();
            void ResetDownloadState();
            
            std::string ConvertWaypointDataToV1(AbstractionEvent event, const std::string& data_info);
            std::string ConvertActionDataToV1(ActionEvent event, const std::string& data_info);
            
            std::shared_ptr<waypointv1::V1WaypointMission> GetV1CacheMission();
        private:
            uint64_t device_id_;
            
            bool is_v1_waypoint_mission_uploading_ = false;
            bool is_v1_action_can_uploading_ = false;
            bool is_v1_waypoint_mission_downloading_ = false;
            uint16_t need_download_action_count_ = 0;
            uint16_t need_download_waypoint_count_ = 0;
            
            std::vector<WaypointActionConfig> cache_actions_;
            std::shared_ptr<Abstraction> abstraction_ = nullptr;
            std::shared_ptr<waypointv1::V1WaypointMission> v1_cache_mission_ = nullptr;
            std::shared_ptr<waypointv2::WaypointMission> v2_cache_mission_ = nullptr;
            std::shared_ptr<V1WaypointStateListenerWrapper> listener_wrapper_ = nullptr;
        };
    }
}

#endif /* dji_waypointv2_waypointv1_adapter_hpp */
