//
//  djicommoncancellablecountdowner.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 11/05/2018.
//

#ifndef djicommoncancellablecountdowner_hpp
#define djicommoncancellablecountdowner_hpp

#include "djicommontimer.h"

namespace dji {
	namespace common {
		typedef std::function<void(void)> OperationBlock;
		
		class CancellableCountdowner : public TimerProtocol {
		public:
			CancellableCountdowner();
			~CancellableCountdowner();
			bool IsCountingDown();
			bool CallbackAfterCountdowner(float seconds, OperationBlock operation_block);
			bool CallbackAfterCountdownerOnCancel(float seconds, OperationBlock operation_block, OperationBlock cancel_block);
			void Cancel();
		private:
			std::shared_ptr<Timer> countdowner_delay_timer_ = nullptr;
			std::shared_ptr<TimerScheduler> scheduler_ = nullptr;
			int current_session_ = 0;
			int next_session_ = 0;
			std::mutex mutex_;
			OperationBlock on_cancel_block_ = nullptr;
		};
	}
}

#endif /* djicommoncancellablecountdowner_hpp */
