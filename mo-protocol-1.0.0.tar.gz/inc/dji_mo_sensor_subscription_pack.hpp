//
//  dji_mo_sensor_subscription_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 8/15/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_sensor_subscription_pack_hpp
#define dji_mo_sensor_subscription_pack_hpp

#include "dji_mo_pack.hpp"
#include "dji_mo_protocol_command_ids.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

class MOSensorSubscribePack : public MOPack
{
  public:
  MOSensorSubscribePack(DJIMOSensorID sensorID);
  MOSensorSubscribePack(uint8_t* data);

  DJIMOSensorID sensorID;
  
   uint8_t* data();
  uint8_t  dataLength();
};

class MOSensorUnsubscribePack : public MOPack
{
public:
  MOSensorUnsubscribePack(DJIMOSensorID sensorID);
  MOSensorUnsubscribePack(uint8_t* data);

  DJIMOSensorID sensorID;
  
  uint8_t* data();
  uint8_t  dataLength();
};
}
}

#endif /* dji_mo_sensor_subscription_pack_hpp */
