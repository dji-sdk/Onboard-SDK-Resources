//
// Created by rohit on 4/24/18.
//

#ifndef DJI_MO_PROTOCOL_DJI_MO_FEATURE_ROSNODE_CONTROL_H
#define DJI_MO_PROTOCOL_DJI_MO_FEATURE_ROSNODE_CONTROL_H

#include "dji_mo_feature_base.hpp"
#include "dji_mo_pack.hpp"

namespace DJI
{
namespace MOProtocol
{
  typedef enum : uint8_t {
    ROSCommandUnknown,
    ROSNodeStart,
    ROSNodeStop,
    ROSServiceCall,
    ROSBagRecordStart,
    ROSBagRecordStop
  } ROSCommand;

  /*!
   * @brief This class allows functionality for turning a few preconfigured ROS nodes ON or OFF.
   */
  class ROSNodeControl : public MOFeature
  {
  public:
    ROSNodeControl();
    ~ROSNodeControl(){};

  //Inherited from MOFeature
  public:
    bool start();
    bool stop();


  //Implementation APIs - In this case, on the onboard side
  public:
    /*!
     * @brief This function will make system calls to preconfigured nodes.
     * @note In the future, this API will accept a string input that is the name of the node to be setup.
     * @return True = successfully set up nodes. False = failed to set up at least one node.
     */
    bool startNodes();

    /*!
     * @brief This function will make system calls to shut down preconfigured nodes.
     * @note In the future, this API will accept a string input that is the name of the node to be setup.
     * @return True if nodes are shut down successfully, false if at least one node is still awake.
     */
    bool teardownNodes();

    /*!
     * @brief This function will make system calls to start recording a bag of preconfigured topics.
     * @note In the future, this API will accept a string input that is the name of the topics to be started.
     * @return True if bag is started successfully, false if not.
     */
    bool startRecordingData();
    /*!
     * @brief This function will make system calls to stop recording a bag of preconfigured topics.
     * @note In the future, this API will accept a string input that is the name of the topics to be stopped .
     * @return True if bag is shut down successfully, false if not.
     */
    bool stopRecordingData();


    //Caller APIs - In this case, on the mobile side
  public:
    /*!
     * @brief This function will make system calls to preconfigured nodes.
     * @note In the future, this API will accept a string input that is the name of the node to be setup.
     * @return True = successfully set up nodes. False = failed to set up at least one node.
     */
    bool sendStartNodesCmd();

    /*!
     * @brief This function will make system calls to shut down preconfigured nodes.
     * @note In the future, this API will accept a string input that is the name of the node to be setup.
     * @return True if nodes are shut down successfully, false if at least one node is still awake.
     */
    bool sendTeardownNodesCmd();

    /*!
     * @brief This function will make system calls to start recording a bag of preconfigured topics.
     * @note In the future, this API will accept a string input that is the name of the topics to be started.
     * @return True if bag is started successfully, false if not.
     */
    bool sendStartRecordingDataCmd();
    /*!
     * @brief This function will make system calls to stop recording a bag of preconfigured topics.
     * @note In the future, this API will accept a string input that is the name of the topics to be stopped .
     * @return True if bag is shut down successfully, false if not.
     */
    bool sendStopRecordingDataCmd();

    // Default handling callback
  public:
    void ROSNodeControlDefaultCallback(MOManager* moManager, MOPack* moPack, void * context);

  };

  class ROSNodeControlPack : public MOPack
  {
  public:
    ROSNodeControlPack(ROSCommand command, uint8_t commandNum);
    ROSNodeControlPack(uint8_t* data);
    ~ROSNodeControlPack(){};

    uint8_t* data();
    uint8_t dataLength();

  public:
    DJIMOFeatureID featureID;
    ROSCommand command;
    uint8_t commandNum;
  };

}
}

#endif //DJI_MO_PROTOCOL_DJI_MO_FEATURE_ROSNODE_CONTROL_H
