//
//  dji_mo_sensor.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 9/15/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_sensor_hpp
#define dji_mo_sensor_hpp

#include <cstdint>
#include <iostream>
#include <vector>

#include "dji_mo_feature_base.hpp"
#include "dji_mo_sensor_driver.hpp"
#include "dji_mo_protocol_command_ids.hpp"

namespace DJI
{
    namespace MOProtocol
    {
        class MOManager;
        
        class MOSensorConfiguration
        {
        public:
            MOSensorConfiguration() = default;
            ~MOSensorConfiguration() = default;
        };
        
        class MOSensor
        {
        public:
            MOSensor() = default; //@todo change once the rest of the structure is well-defined
            ~MOSensor() = default;
            
        public:
            DJIMOSensorID sensorID = DJIMOUnknownSensor;
            DJIMOSensorID sensorKeyIdentifier = DJIMOUnknownSensor;
            
            bool offersSubscription = true;
            
            // Link to MOManager allows the sensor to send its data directly at its own pace.
            MOManager *moManager = NULL;
            
            /*
             * Data members common to all sensors
             */
            
        private:
            /*!
             * @brief Sensor header containing frame and timestamps.
             * @details Adapted from ROS std_msgs/Header, but dropped seq since we already have that in MOProtocol.
             */
            class Header
            {
            public:
                Header() = default;
                ~Header() = default;
                
            public:
                uint8_t frameID; /*!<Reference frame of the sensor data.\n 0: World Frame \n 1: Body-Fixed frame \n 2: Gimbal-Fixed frame>*/
                uint32_t timeStampSec; /*!<Timestamp in NTP, seconds part>*/
                uint32_t timeStampNsec; /*!<Timestamp in NTP, nanoseconds part>*/
            };
            
            //! Let's define a member variable of type Header
            Header header;
            
            /*!
             * @brief Sensor diagnostic information, as reported by the sensor itself
             */
            class DiagnosticStatus
            {
            public:
                DiagnosticStatus() = default;
                ~DiagnosticStatus() = default;
                
                //  enum OPERATION_LEVEL
                //  {
                //    OK=  0,
                //    WARN = 1,
                //    ERROR = 2,
                //    STALE = 3
                //  };
                
                // public:
                //  uint32_t hardwareID; /*!<Unique hardware ID for this particular sensor>*/
                //  OPERATION_LEVEL operationLevel; /*!<Can we trust the data coming out of this sensor, according to itself?>*/
            };
            
            //! Let's define a member variable of type DiagnosticStatus
            DiagnosticStatus diag;
            
            //! Each sensor MUST implement its own data structure for the actual sensor data.
            uint8_t* sensorData;
            
            /*
             * Methods common to all sensors
             * These will be implemented in individual sensor instantiations
             */
        public:
            /*!
             * @brief Initiate a connection between MO and sensor
             * @return Connection status. True = Success, False = Failure.
             */
            virtual bool initiate() = 0;
            /*!
             * @brief Configure the sensor after connecting to it.
             * @details This function should handle setting up the sensor as per configuration.
             * @param configList Pass required configuration parameters as required
             * @return Configuration status. True = Success, False = Failure.
             */
            virtual bool configure(MOSensorConfiguration* config) = 0;
            
            /*!
             * @brief Terminate the connection between MO from the sensor.
             * @details This only means that MO no longer deals with the sensor. The sensor might still be working and
             * interacting with other parts of the system.
             * @return Disconnect status. True = Success, False = Failure.
             */
            virtual bool terminate() = 0;
            
            // Here each sensor could implement its own getter or subscription mechnism.
            
            
            /*
             * Driver - to be implemented on the onboard side and provided
             */
        public:
            MOSensorDriver *driver = NULL;
            
            // Called by the driver when the data of the sensor has been updated.
            void driverDidUpdateData();
        };
        
    }
}

#endif /* dji_mo_sensor_hpp */
