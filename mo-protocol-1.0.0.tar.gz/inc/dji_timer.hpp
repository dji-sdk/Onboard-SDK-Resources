//
//  dji_timer.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 9/19/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_timer_hpp
#define dji_timer_hpp

#include <chrono>
#include <cstdint>
#include <ctime>
#include <iostream>
#include <functional>

using namespace std::chrono;

namespace DJI
{
namespace Tools
{

class RunLoop;

class Timer
{

public:
    Timer(double timeInterval, bool repeats, std::function<void(Timer*)> callback);
    //TODO: make a lambda based constructor when more mature
  ~Timer();

  // Runloop accesses
  RunLoop* runloop = NULL;

  void didSchedule(RunLoop* runloop);
  void evaluate();

private:
  double        triggerInterval = 1; // in seconds
  bool          shouldRepeat     = false;
   std::function<void(Timer*)> callback;

  steady_clock::time_point lastTimePoint;
};
}
}

#endif /* dji_timer_hpp */
