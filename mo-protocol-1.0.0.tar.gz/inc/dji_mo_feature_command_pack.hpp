//
//  dji_mo_feature_command_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 8/15/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_feature_command_pack_hpp
#define dji_mo_feature_command_pack_hpp

#include "dji_mo_pack.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

class MOFeatureCommandPack : public MOPack
{
  // TBD
};
}
}

#endif /* dji_mo_feature_command_pack_hpp */
