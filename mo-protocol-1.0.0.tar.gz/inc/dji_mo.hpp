//
//  dji_mo_hpp
//  MOProtocol
//
//  Created by Oksana Yaremchuk on 11/1/18.
//  Copyright © 2018 DJI. All rights reserved.
//

#ifndef dji_mo_hpp
#define dji_mo_hpp

#include "dji_mo_manager.hpp"

using namespace DJI::MOProtocol;

namespace DJI
{
  namespace MOProtocol
  {
    class MO
    {
      MO(MOManager* mo);
      
      ~MO();
      
    private:
      MOManager* _moManager;
      
    public:
      /**
       Send pack to mobile
       
       @param pack data unit that travels from onboard to mobile divices
       */
      void send(MOPack* pack);
      /**
       Register a sensor as to declare it as available for use to the other side.
       
       @param sensor Optional Sensor Object to be provided if the sensor is not
       already implemented inside the SDK
       */
      void registerSensor(MOSensor* sensor);
      /**
       Unregisters a sensor as to declare it as no-longer available for use to the
       other side.
       
       @param sensor to be declared as not available
       */
      void unregisterSensor(MOSensor* sensor);
    };
  }
}
#endif /* dji_mo_hpp */
