//
//  dji_mo_feature.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 9/15/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_feature_hpp
#define dji_mo_feature_hpp

#include <cstdint>
#include <iostream>
#include "dji_mo_protocol_command_ids.hpp"

namespace DJI
{
namespace MOProtocol
{

class MOManager; // Forward Declaration

class MOFeature
{

public:
  MOFeature();
  virtual ~MOFeature();

  // Link to MOManager allows the feature to send its commands directly.
  MOManager *moManager = NULL;

public:
  /*!
   * @brief This variable denotes your feature ID. To create a new feature ID, please go to dji_mo_feature_command_pack.hpp.
   */
  DJIMOFeatureID featureID = DJIMOUnknownFeature;

public:
  /*!
   * @brief Make the feature available.
   * @return Start status. True = Success, False = failure
   */
  virtual bool start();

  /*!
   * @brief Disable the feature
   * @return Stop status. True: Successfully stopped. False = failed to stop.
   */
  virtual bool stop();
};
}
}

#endif /* dji_mo_feature_hpp */
