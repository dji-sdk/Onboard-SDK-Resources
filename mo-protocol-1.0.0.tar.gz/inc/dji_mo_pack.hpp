//
//  dji_mo_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 7/27/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_pack_hpp
#define dji_mo_pack_hpp

#include "dji_mo_protocol_command_ids.hpp"
#include <stdint.h>
#include <iostream>
#include <stdexcept>

namespace DJI
{
namespace MOProtocol
{

typedef enum : uint8_t {
    MOPackUnknownState,
    MOPackSentState,
    MOPackSuccessfulState,
    MOPackErrorState,
    MOPackTimedOutState,
    MOPackCancelledState,
} MOPackState;
    
class MOPack
{
public:
  DJIMOCommandID cmdID =
    DJIMOUnknown; // the command ID associated with this pack
  DJIMOError errorCode = DJIMOErrorNone;

    // Retrying mechanism.
    bool expectsAck = false;
    uint16_t maxRetryCount = 0; // How many times to retry before timeout. 0 means won't retry
    // To implement later, for now every thing retries every second.
    //    uint8_t retryInterval = 1; // how many seconds between each retry
    uint16_t retryAttempts = 0; // How many times retry was attempted. When retryAttempts == retryCount -> Timeout
    DJI::MOProtocol::MOPackState packState = MOPackUnknownState; // Success, timeout, cancel, etc
    
  virtual uint8_t* data()       = 0;
  virtual uint8_t  dataLength() = 0;

  /*
   Note on rawdata constructors:

   The total size will depend on the specific pack
   representation. The first byte will be the cmdID. The second will be the size
   of the data. What follows depends on the specific pack
   */
};
}
}

#endif /* dji_mo_pack_hpp */
