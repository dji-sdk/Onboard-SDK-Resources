//
//  dji_mo_logging_pack.hpp
//  MOProtocol
//
//  Created by Oksana Yaremchuk on 1/16/18.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_logging_pack_hpp
#define dji_mo_logging_pack_hpp

#include "dji_mo_pack.hpp"
#include "dji_mo_protocol_command_ids.hpp"
#include <cstdint>
#include <iostream>
#include <cstring>

namespace DJI
{
namespace MOProtocol
{

class MOOSDKLoggingPack : public MOPack
{

private:

  // Byte order for pack MSG
  const uint8_t OSDK_PAYLOAD_SIZE           = 0;
  const uint8_t OSDK_PAYLOAD_IS_ACK         = 1;
  const uint8_t OSDK_PAYLOAD_CMDID          = 2;
  const uint8_t OSDK_PAYLOAD_FRAME_SEQUENCE = 3;
  const uint8_t OSDK_PAYLOAD_ACK_MSG        = 4;
  const uint8_t OSDK_PAYLOAD_NON_ACK_MSG    = 2;

  // Byte order for reconstructing from raw logging pack array back into pack
  const uint8_t MOOSDK_LOGGING_PACK_DATA_CMDID      = 0;
  const uint8_t MOOSDK_LOGGING_PACK_DATA_SIZE       = 1;
  const uint8_t MOOSDK_LOGGING_PACK_DATA_MSG        = 2;

  #pragma pack(1)
  typedef struct MOOSDKLoggingPackData_t
  {
    uint8_t  cmdID; // MO CMD ID
    uint8_t  size;  // Size of the MOOSDKLoggingPackData_t struct
    uint8_t* msg;   // OSDK logging payload
  } MOOSDKLoggingPackData;
  #pragma pack()

  MOOSDKLoggingPackData* packContainer;
  uint8_t  osdkPayloadSize;

public:
  MOOSDKLoggingPack();
  // Constuct a new pack from raw OSDK payload
  MOOSDKLoggingPack(void* data);
  // Data comes as a raw byte array already representing a looging pack.
  // ( See extractPack() function for usage )
  //
  // TODO rethink design
  MOOSDKLoggingPack(uint8_t* data);
  ~MOOSDKLoggingPack();

  uint8_t* data();
  uint8_t  dataLength();

  bool isACK();
  const uint8_t* getMSG();
  uint8_t getMSGSize();
  uint8_t getOSDKCMDID();
  uint8_t getOSDKFrameSequence();

};

}
}
#endif /* dji_mo_logging_pack_hpp */
