//
// Created by rohit on 5/19/17.
//

#ifndef DJI_MO_FRAME_HPP
#define DJI_MO_FRAME_HPP

#include <cstdint>
#include <iostream>

#define TRANSPARENT_TRANSMISSION_FRAME_SIZE (uint8_t)100
#define OPEN_PROTOCOL_CMD_FRAME_METADATA_SIZE (uint8_t)18

#include "dji_mo_pack.hpp"
using namespace std;

namespace DJI
{
namespace MOProtocol
{

class MOFrame
{
public:
  static const uint8_t MAX_MO_DATA_SIZE =
    TRANSPARENT_TRANSMISSION_FRAME_SIZE - OPEN_PROTOCOL_CMD_FRAME_METADATA_SIZE;

#pragma pack(1)
  typedef struct
  {
    uint8_t seq;
    uint8_t qos : 1;
    uint8_t len : 7;
  } MOHeader;

  typedef struct
  {
    uint8_t data[MAX_MO_DATA_SIZE];
  } MOBody;
#pragma pack()

  /**
   Constructs a Frame from raw data.

   @param rawData raw data representing the frame
   */
  MOFrame(uint8_t* rawData);

  /**
   <#Description#>

   @param seq <#rawData description#>
   @param qos <#rawData description#>
   @param pack <#rawData description#>
   */
  MOFrame(uint8_t seq, uint8_t qos, MOPack* pack);

  /**
   Extracts the pack from the body of the frame

   @return NULL if invalid Pack or a valid MOPack subclass object.
   */
  MOPack* extractPack();

  // TODO: implement later

  /**
   Returns the number of packs in the frame.

   @return 0-n value
   */
  // unsigned int packCount();

  /**
   Returns an array of MOPack objects contained inside the frame.

   @return an array of MOPacks.
   */
  // std::vector<std::shared_ptr<MOPack>>extractAllPacks();

  // END TODO;

  //
  //  Data methods to send through network
  //

  /**
   The data representation of the frame

   @return a pointer to the data representing the frame
   */
  uint8_t* data();

  /**
   The size of the data representation

   @return the size of the data representing the frame
   */
  uint8_t dataLength();

  //
  //  Debug
  //

  /**
   Will print in console data about the frame.
   */
  void printFrame();

private:
  MOHeader header;
  MOBody   body;
};
}
}

#endif // DJI_MO_PROTOCOL_DJI_MO_FRAME_HPP
