//
//  dji_mo_custom_sensor.hpp
//  MOProtocol
//
//  Created by Oksana Yaremchuk on 10/11/18.
//  Copyright © 2018 DJI. All rights reserved.
//

#ifndef dji_mo_custom_sensor_hpp
#define dji_mo_custom_sensor_hpp

#include <vector>
#include <thread>
#include <mutex>
#include <cstring>

#include "dji_mo_sensor.hpp"
#include "dji_mo_sensor_subscription_pack.hpp"
#include "dji_mo_pack.hpp"

// Pack member: cmdID, size, sensorID
const uint8_t PACK_MEMBERS = 3;
// Byte order for reconstructing from raw sensor pack array back into pack
// Must follow this byte order becasue other layers of MO stack use it!
const uint8_t CUSTOM_SENSOR_PACK_DATA_CMDID      = 0;
const uint8_t CUSTOM_SENSOR_PACK_DATA_SIZE       = 1;
const uint8_t CUSTOM_SENSOR_PACK_DATA_SENSOR_ID  = 2;
const uint8_t CUSTOM_SENSOR_PACK_DATA_MSG        = 3;

namespace DJI
{
  namespace MOProtocol
  {
    
    /*
     *  Sensor
     */
    
    class Sensor : public MOSensor
    {
    public:
      Sensor();
      ~Sensor();
      
    public:
      // MOSensor interface;
      bool initiate();
      bool configure(MOSensorConfiguration *config);
      bool terminate();
    };
    
    /*
     * Pack
     */
    
    class MOSensorPack : public MOPack
    {
      
    private:
      
      #pragma pack(1)
      typedef struct MOSensorPackData_t
      {
        uint8_t  cmdID;     // Command identifier
        uint8_t  size;      // Pack   size
        uint8_t  sensorID;  // Unique sensor ID
        uint8_t* msg;       // Sensor payload
      } MOSensorPackData;
      #pragma pack()
      
      MOSensorPackData* packContainer;
      uint16_t		sensorDataSize;
    
    public:
      MOSensorPack();
      
      // Constuct a new pack from raw user data
      MOSensorPack(uint8_t sensorID, uint16_t dataSize, uint8_t* data);
      
      // Data comes as a raw byte array already representing a custom sensor pack.
      // ( See extractPack() function for usage )
      //
      MOSensorPack(uint8_t* data);
      
      ~MOSensorPack();
      
      /*
       * Get pack raw data
       */
      uint8_t* data();
      uint8_t  dataLength();
      uint8_t  getSensorID();
      uint8_t  getCommandID();
      uint16_t  getSensorPayloadSize();
      /*
       * Get sensor raw data
       */
      uint8_t* getSensorPayload();
    };
  }
}

#endif /* dji_mo_custom_sensor_hpp */
