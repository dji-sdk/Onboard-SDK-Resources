//
//  dji_mo_feature_count_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 8/15/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_feature_count_pack_hpp
#define dji_mo_feature_count_pack_hpp

#include <stdio.h>

#include "dji_mo_pack.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

class MOFeatureCountRequestPack : public MOPack
{
public:
  MOFeatureCountRequestPack();
  MOFeatureCountRequestPack(uint8_t* data);

  ~MOFeatureCountRequestPack(){};

public:
  uint8_t* data();
  uint8_t dataLength();

};

class MOFeatureCountAnswerPack : public MOPack
{
public:
  MOFeatureCountAnswerPack(uint8_t count);
  MOFeatureCountAnswerPack(uint8_t* data);

  ~MOFeatureCountAnswerPack(){};

public:
  uint8_t* data();
  uint8_t dataLength();
  uint8_t count; //Potential refactor: make private and add accessors


};
}
}

#endif /* dji_mo_feature_count_pack_hpp */
