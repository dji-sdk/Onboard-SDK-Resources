//
// Created by rohit on 4/24/18.
//

#ifndef DJI_MO_PROTOCOL_DJI_MO_FEATURES_HPP
#define DJI_MO_PROTOCOL_DJI_MO_FEATURES_HPP

#include "dji_mo_feature_base.hpp"
#include "dji_mo_feature_rosnode_control.hpp"

using namespace DJI::MOProtocol;

  /*!
   * @brief Creates a MOFeature object from the featureID
   * @note All MOFeatures supported by MOProtocol will need an implementation here.
   */
  inline MOFeature *createFeature(DJIMOFeatureID featureID)
  {
    MOFeature *feature = NULL;

    switch (featureID)
    {
      case DJIMOROSNodeControl:
        feature = new ROSNodeControl();
        break;
      // Add cases here when you add a new feature
      default:
        break;
    }
    return feature;
  }


#endif //DJI_MO_PROTOCOL_DJI_MO_FEATURES_HPP
