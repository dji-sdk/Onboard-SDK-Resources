//
//  dji_mo_sensors.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 10/02/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_sensors_hpp
#define dji_mo_sensors_hpp

#include "dji_mo_sensor.hpp"
#include "dji_mo_lightware_sf10a_sensor.hpp"
#include "dji_mo_obstacle_sensor.hpp"
#include "dji_mo_custom_sensor.hpp"

/**
 * Creates a proper MOSensor object from the sensorID
 * This lists all included MOSensor supported by MOProtocol
 */
inline DJI::MOProtocol::MOSensor *createSensor(DJIMOSensorID sensorID)
{
    DJI::MOProtocol::MOSensor *sensor = NULL;
    
    switch (sensorID) {
        case DJIMOLightwareSF10ASensor:
            sensor = new DJI::MOProtocol::LightwareSF10ASensor();
            break;
        case DJIMOLidarMapSensor:
            //sensor = new DJI::MOProtocol::LidarMapSensor();
            break;
        case DJIMOObjectDetectionSensor:
            sensor = new DJI::MOProtocol::SmartObstacleSensor();
            break;
        case DJIMOCustomSensor:
            sensor = new DJI::MOProtocol::Sensor();
            break;
        default:
            break;
    }
    
    return sensor;
}

#endif // dji_mo_sensors_hpp
