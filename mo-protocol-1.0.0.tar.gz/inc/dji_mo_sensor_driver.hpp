//
// Created by athiercelin on 9/28/17.
//

#ifndef DJI_MO_PROTOCOL_DJI_MO_SENSOR_DRIVER_HPP
#define DJI_MO_PROTOCOL_DJI_MO_SENSOR_DRIVER_HPP

namespace DJI
{
    namespace MOProtocol
    {
        class MOSensor;

        class MOSensorDriver
        {
	public:
            MOSensor *sensor = 0;
            
            virtual void connect() = 0;

            virtual void disconnect() = 0;
        };
    }
}


#endif //DJI_MO_PROTOCOL_DJI_MO_SENSOR_DRIVER_HPP
