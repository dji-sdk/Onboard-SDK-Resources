//
// Created by athiercelin on 9/28/17.
//

#ifndef AEOLUS_ONBOARD_LIGHTWARE_SF10A_H
#define AEOLUS_ONBOARD_LIGHTWARE_SF10A_H

#include <vector>
#include <thread>
#include <mutex>

#include "dji_mo_sensor.hpp"
#include "dji_mo_sensor_subscription_pack.hpp"
#include "dji_mo_pack.hpp"

namespace DJI
{
  namespace MOProtocol
  {

    /*
     *  Sensor
     */
    
class LightwareSF10ASensor : public MOSensor
{
public:
    LightwareSF10ASensor();
    ~LightwareSF10ASensor();

public:
    // MOSensor interface;
    bool initiate();
    bool configure(MOSensorConfiguration *config);
    bool terminate();
};

/*
 * Pack
 */
    
class LightwareSF10ASensorPack : public MOPack
{

public:
  LightwareSF10ASensorPack(double distance,
                           double latitude,
                           double longitude,
                           double altitude,
                           double roll,
                           double pitch,
                           double yaw,
                           uint8_t rtkYawInfo,
                           uint8_t rtkPosInfo,
                           uint64_t timestamp);
  LightwareSF10ASensorPack(uint8_t *data);

  uint8_t* data();
  uint8_t  dataLength();

  DJIMOSensorID sensorID;
  double distance;
  double latitude;
  double longitude;
  double altitude;
  double roll;
  double pitch;
  double yaw;
  uint8_t rtkYawInfo;
  uint8_t rtkPosInfo;
  uint64_t timestamp;
};
  }
}
#endif //AEOLUS_ONBOARD_LIGHTWARE_SF10A_H
