//
//  dji_mo_feature_list_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 8/15/17.
//  Copyright © 2017-18 DJI. All rights reserved.
//

#ifndef dji_mo_feature_list_pack_hpp
#define dji_mo_feature_list_pack_hpp

#include "dji_mo_pack.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

//class MOFeatureGetRequestPack : public MOPack
//{
//public:
//  MOFeatureGetRequestPack();
//  MOFeatureGetRequestPack(uint8_t* data);
//  ~MOFeatureGetRequestPack(){};
//
//
//
//};
//
//class MOFeatureGetAnswerPack : public MOPack
//{
//};

class MOFeatureGetAllRequestPack : public MOPack
{
public:
  MOFeatureGetAllRequestPack();
  MOFeatureGetAllRequestPack(uint8_t* data);

  ~MOFeatureGetAllRequestPack();

public:
  uint8_t* data();
  uint8_t dataLength();
};

class MOFeatureGetAllAnswerPack : public MOPack
{
public:
  MOFeatureGetAllAnswerPack(DJIMOFeatureID featureIDs[10], uint8_t startIndex, uint8_t endIndex);
  MOFeatureGetAllAnswerPack(uint8_t* data);

  ~MOFeatureGetAllAnswerPack();

public:
  uint8_t* data();
  uint8_t dataLength();

public:
  uint8_t startIndex;
  uint8_t endIndex;
  DJIMOFeatureID featureList[10];

};
}
}

#endif /* dji_mo_feature_list_pack_hpp */
