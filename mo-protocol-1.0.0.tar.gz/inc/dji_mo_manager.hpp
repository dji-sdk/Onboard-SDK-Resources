//
//  dji_mo_manager.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 8/14/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_manager_hpp
#define dji_mo_manager_hpp

#include <chrono>
#include <cstdint>
#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

#include "dji_mo_feature_base.hpp"
#include "dji_mo_frame.hpp"
#include "dji_mo_sensor.hpp"

#include "dji_mo_packs.hpp"
#include "dji_mo_protocol_command_ids.hpp"

#include "dji_runloop.hpp"
#include "dji_timer.hpp"

namespace DJI
{
    namespace MOProtocol
    {
        enum MOManagerMode
        {
            MOMasterMode = 0,
            MOSlaveMode  = 1,
        };

        enum MOManagerPlatform
        {
            MOUnknownPlatform = 0,
            MOMobilePlatform  = 1,
            MOOnBoardPlatform = 2,
        };

        enum MOManagerHeartBeatStage
        {
            MOManagerHeartBeatStagePassive         = 0,
            MOManagerHeartBeatStageDiscovering     = 1,
            MOManagerHeartBeatStageSlowDiscovering = 2,
            MOManagerHeartBeatStageKeepAlive       = 3,
        };

        class MOManager
        {

        public:
            MOManager();
            ~MOManager();

            /*
             *  States
             */
        public:
            /**
             Defines the mode of the MOManager in place.
             MOManagers relate to each other using this mode of communication
             Don't use as a setter.
             */
            MOManagerMode currentMode = MOMasterMode;
        private:
            bool initialHandshake = false;
            uint8_t frameSequence;

            void incrementFrameSequence();
            void decrementFrameSequence();
            void resetFrameSequence();
            uint8_t getFrameSequence();
        public:
            bool getInitialHandshake();
            void setInitialHandshake(bool handshake);

            /**
             The method to be used to set the mode of the manager.

             @param mode a valid MOManagerMode
             */
            void setMode(MOManagerMode mode);

            /**
             This holds a pointer to the instance of the class that this MOManager was created from.
             Is used in the callbacks to get a reference to the instance that created it.
             */
            void* context = NULL;
            
            /**
             Defines which platform this MOManager is running on.
             */
            MOManagerPlatform localPlatform = MOUnknownPlatform;

            DJIMOOSDKVersion connectedOSDKVersion = DJIOSDKVersionUnknown;
            std::string stringifyOSDKVersion(DJIMOOSDKVersion osdkVersion);

            DJIMobileSDKVersion connectedMobileSDKVersion = DJIMobileSDKVersionUnknown; // to be added to handshake req
            std::string stringifyMobileSDKVersion(DJIMobileSDKVersion msdkVersion);
          
            Tools::RunLoop* mainLoop;

            std::chrono::system_clock::time_point* lastMOFrameReceivedDate;

            /*
             *  Pack management
             */
        public:
            /**
             Checks if the raw data passed is a MOPack

             @param data Raw data to be analysed
             @return NULL if not a MOFrame otherwise a valid frame.
             */
            MOFrame* isDataMOFrame(void* data, uint8_t size);

            //
            // Convenience Methods below
            //

            /**
             Creates a frame containing the passed pack.

             @param pack A valid subclass of MOPack
             @return a valid frame or exception if an error occured.
             */
            MOFrame* framePack(MOPack* pack);

            /**
             Get status of a handshake

             @return current status of a handshake
            */  
            bool getHandshakeStatus();

            /**
             Set status of a handshake to true when received by the
             server side

             @param handshake status
            */
            void setHandshakeStatus(bool handshake);
            
            /*
             *  Communication
             */
        public:
            /**
             This callback is provided by the platform which controls communication to its
             counter part.
             It is used by the MOManager instance to talk to the MOManager instance on the
             other side.
             */
            std::function<void(uint8_t*, uint8_t, void*)> dataSendingCallback;
            
            /**
             The method to be called when raw data is received through transparent
             transmission. This will return true if the data received was MO-related and
             handled or false if it wasn't related and therefore not handled.

             @param data the raw data
             @param length the size of the raw data.
             @return Wether or not the data received was MO. If so, MOManager handles it
             and nothing else is to be done. Otherwise, you need to process the data as
             you see fit.
             */
            bool dataReceived(void* data, unsigned int length);

        private:
            std::vector<MOPack *> *pendingPacks;
            Tools::Timer *retryPacksTimer;
            /* Count number of discovery heartbeat retries */
            uint8_t discoveryHeartBeatCounter = 0;
            /** 
             For the server side, keep track of initial 
             handshake to maintain frame secuencing properly 
             for each new connection
            */
            bool handshakeReceived = false;
        public:
            /*!
             * @brief This API is recommended for sending data to the other side.
             * @param pack pack to send.
             */
            void sendMOPack(MOPack *pack);
        public:
            /*@brief Send logs from OSDK to mobile App.
             * 
             */ 
            void sendOSDKLoggingMSG(MOPack *pack);
            void send(MOPack* pack);
        private:
            void retrySendingPacks(Tools::Timer *timer);

            void receiveMOFrame(MOFrame* frame);
            void ackPacks(DJIMOCommandID cmdID);
            
            /*
             *  Heartbeat
             */
        public:
            MOManagerHeartBeatStage heartBeatStage = MOManagerHeartBeatStageDiscovering;
            Tools::Timer *heartBeatTimer;

            void startAppropriateHeartBeat();

            void startDiscoveryHeartBeat();
            void discoveryHeartBeatCallback(Tools::Timer *timer);

            void startSlowDiscoveryHeartBeat();
            void slowDiscoveryHeartBeatCallback(Tools::Timer *timer);

            void startKeepAliveHeartBeat();
            void keepAliveHeartBeatCallback(Tools::Timer *timer);
            
            std::function<void(MOManager *, void *)> onboardDeviceDeactivatedCallBack;

            void stopHeartBeat();

            void answerHeartBeatRequest(MOHeartbeatRequestPack* heartBeatRequestPack);
            
            void handleHeartBeatAnswer(MOHeartbeatAnswerPack* heartBeatAnswerPack);
            
            void handleHeartBeartAnswer(MOHeartbeatAnswerPack* heartBeatAnswerPack);

            void sendSingleHeartBeat();

            /*
             *  Handshake
             */
        public:
            std::chrono::system_clock::time_point* successfulHandshakeDate = NULL;

            std::function<void(MOManager *, void *)>handshakeDidHappenCallback;
          
            void sendHandshakeRequest();

            void answerHandshakeRequest(MOHandshakeRequestPack* handshakeRequestPack);

            void handleHandshakeAnswer(MOHandshakeAnswerPack* handshakeAnswerPack);

            /*
             *  Sensors
             */
        public:
            /**
             *  List of all available sensors
             */
            std::vector<MOSensor*>* availableSensors;

            /**
             Called when the list of sensor has changed.
             */
            std::function<void(MOManager *, void *)> sensorListDidChangeCallback;
            
            /**
             Called whenever some sensor data is received.
             */
            std::function<void(MOManager*, MOPack*, void *)> sensorDataCallback = NULL;
            
            /**
             Register a sensor as to declare it as available for use to the other side.

             @param sensor Optional Sensor Object to be provided if the sensor is not
             already implemented inside the SDK
             */
            void registerSensor(MOSensor* sensor);
            /**
             Unregisters a sensor as to declare it as no-longer available for use to the
             other side.

             @param sensorID A unique identifier for the sensor
             */
            void unregisterSensor(DJIMOSensorID sensorID);

            /**
             Returns the sensor matching the passed identifier if in the list of available
             sensors

             @param sensorID A unique identifier for the sensor
             @return A valid MOSensor object or NULL if no available sensor matched.
             */
            MOSensor* availableSensor(DJIMOSensorID sensorID);
          
            MOSensor* getCustomSensor(DJIMOSensorID sensorID);

            /**
             Sends a message to the remote MOManager requesting the number of available sensors
             */
            void sendSensorCountRequest();

            void answerSensorCountRequest(MOSensorCountRequestPack *pack);

            void handleSensorCountAnswer(MOSensorCountAnswerPack *pack);

            /**
             Sends a request to the remote MOManager for the list of available sensors
             */
            void sendSensorListRequest();

            void answerSensorListRequest(MOSensorListRequestPack *pack);

            void handleSensorListAnswer(MOSensorListAnswerPack *pack);

            /**
             requests the

             @param sensorID the unique identifier of the sensor you want to subscribe to.
             @return true if successful, otheriwse false.
             */

            bool subscribe(DJIMOSensorID sensorID);

            void handleSubscribe(MOSensorSubscribePack *pack);

            /**
             Request to stop the subscription system for the sensor with the given id.

             @param sensorID the unique identifier of the sensor you want to stop the subsription from.
             @return true if successful, otheriwse false.
             */
            bool unsubscribe(DJIMOSensorID sensorID);

            void handleUnsubscribe(MOSensorUnsubscribePack *pack);

            /*
             *  Features
             */
        public:
            std::vector<MOFeature*>* availableFeatures;
             /**
              * Called when the list of sensor has changed.
              */
            std::function<void(MOManager *, void *)> featureListDidChangeCallback;

             /**
              * Called whenever some feature command is received.
              */
            std::function<void(MOManager*, MOPack*, void *)> featureCommandCallback = NULL;

             /**
             Register a feature as to declare it as available for use to the other side.

             @param identifier A unique string representation of the feature.
             @param feature Optional Feature Object to be provided if the feature is not
             already implemented inside the SDK
             */
            void registerFeature(DJIMOFeatureID identifier, MOFeature* feature);
            /**
             Unregisters a feature as to declare it as no-longer available for use to the
             other side.

             @param identifier A unique string representation of the feature.
             */
            void unregisterFeature(DJIMOFeatureID identifier);

            /**
             Returns the feature matching the passed identifier if in the list of available
             sensors

             @param identifier A unique string representation of the feature.
             @return a valid MOFeature object or NULL if no available feature matched.
             */
            MOFeature* availableFeature(DJIMOFeatureID identifier);

          /**
          Sends a message to the remote MOManager requesting the number of available sensors
          */
          void sendFeatureCountRequest();

          void answerFeatureCountRequest(MOFeatureCountRequestPack *pack);

          void handleFeatureCountAnswer(MOFeatureCountAnswerPack *pack);



          /**
           Sends a request to the remote MOManager for the list of available sensors
           */
          void sendFeatureListRequest();

          void answerFeatureListRequest(MOFeatureGetAllRequestPack *pack);

          void handleFeatureListAnswer(MOFeatureGetAllAnswerPack *pack);

            /*
             * MO Logging
             */
        public:

            const uint8_t* loggingData;
          
            void handleOSDKLoggingData(MOOSDKLoggingPack *osdkLoggingPack);
          
            std::string stringifyMobileSDKLogging(const uint8_t* msdkLogging);
          
            std::function<void(MOManager *, void *)>loggingDidHappenCallback;
          
            /**
             * User friendly function to post MOManager logs to logging screen
             * @param msg - user defined logging message
             */
            void postMOManagerLoggingMSGToScreen(std::string msg);
        private:
            /**
             * Post MOManager logs to logging screen
             * @param msg - user defined logging message
             */
            void doPostMOManagerLoggingMSGToScreen(const uint8_t* msg);
        };
    }
}

#endif /* dji_mo_manager_hpp */
