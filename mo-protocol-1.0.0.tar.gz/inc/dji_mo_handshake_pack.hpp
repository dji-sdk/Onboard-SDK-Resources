//
//  dji_mo_handshake_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 7/27/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_handshake_pack_hpp
#define dji_mo_handshake_pack_hpp

#include "dji_mo_pack.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

class MOHandshakeRequestPack : public MOPack
{

public:
  MOHandshakeRequestPack();
  MOHandshakeRequestPack(uint8_t* data);

  uint8_t* data();
  uint8_t  dataLength();
};

class MOHandshakeAnswerPack : public MOPack
{

public:
  MOHandshakeAnswerPack(DJIMOOSDKVersion osdk_version);
  MOHandshakeAnswerPack(uint8_t* data);

  uint8_t* data();
  uint8_t  dataLength();

  DJIMOOSDKVersion osdk_version;
};
}
}

#endif /* dji_mo_handshake_pack_hpp */
