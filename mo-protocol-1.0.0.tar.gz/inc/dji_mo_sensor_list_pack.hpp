//
//  dji_mo_sensor_list_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 8/15/17.
//  Copyright © 2017-18 DJI. All rights reserved.
//

#ifndef dji_mo_sensor_list_pack_hpp
#define dji_mo_sensor_list_pack_hpp

#include "dji_mo_pack.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
  namespace MOProtocol
  {

    class MOSensorListRequestPack : public MOPack
    {
    public:
      MOSensorListRequestPack();
      MOSensorListRequestPack(uint8_t *data);

      uint8_t *data();
      uint8_t dataLength();
    };

    class MOSensorListAnswerPack : public MOPack
    {
    public:
      MOSensorListAnswerPack(DJIMOSensorID sensorIDs[10], uint8_t startIndex, uint8_t endIndex);
      MOSensorListAnswerPack(uint8_t *data);

      uint8_t startIndex;
      uint8_t endIndex;
        DJIMOSensorID sensorIDs[10];
        
      uint8_t *data();
      uint8_t dataLength();
    };
  }
}
#endif /* dji_mo_sensor_list_pack_hpp */
