//
//  dji_runloop.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 9/19/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_runloop_hpp
#define dji_runloop_hpp

#include <cstdint>
#include <iostream>
#include <mutex>
#include <thread>
#include <vector>
#include <algorithm>
#include <future>

namespace DJI
{
    namespace Tools
    {
        class Timer;

        class RunLoop
        {
        public:
            RunLoop();
            ~RunLoop();

            void start();
            void stop();

        private:
            void        asyncStart();
            void evaluateTimers();

            /*
             *  Timers
             */
        private:
            std::shared_ptr<std::thread> loop_thread_ = nullptr;

            enum class RunLoopState {
                CREATED,
                STARTED,
                STOPPING,
                STOPPED,
            };
            RunLoopState state_ = RunLoopState::CREATED;
            std::mutex           state_mutex_;
            std::mutex           timer_mutex_; 
            std::vector<Timer *> timers;
            std::shared_ptr<std::promise<void>> barrier_ = nullptr; 

        public:
            void scheduleTimer(Timer* timer);
            void unscheduleTimer(Timer* timer);
        };
    }
}

#endif /* dji_runloop_hpp */
