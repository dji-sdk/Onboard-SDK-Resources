//
//  dji_mo_protocol_command_ids.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 7/25/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_protocol_command_ids_hpp
#define dji_mo_protocol_command_ids_hpp

#include <stdint.h>

typedef enum : uint8_t {
    DJIMOUnknown                = 0,

    DJIMOHeartbeatReq           = 10,
    DJIMOHeartbeatAnswer        = 11,
    DJIMOHandshakeReq           = 12,
    DJIMOHandshakeAnswer        = 13,
    DJIMOOSDKLoggingData        = 14,

    // Sensors
    DJIMOSensorsCountReq        = 20,
    DJIMOSensorsCountAnswer     = 21,
    DJIMOSensorListReq          = 22,
    DJIMOSensorListAnswer       = 23,
//    DJIMoSensorGetConfig >> to pull specific data out of a sensor since list only gives id.
    DJIMOSensorSubscribe        = 24,
    DJIMOSensorUnsubscribe      = 25,
    DJIMOSensorData             = 26,
      
    // Features
    DJIMOFeaturesCountReq       = 30,
    DJIMOFeaturesCountAnswer    = 31,
    DJIMOFeaturesGetReq         = 32,
    DJIMOFeaturesGetAnswer      = 33,
    DJIMOFeaturesGetAllReq      = 34,
    DJIMOFeaturesGetAllAnswer   = 35,
    DJIMOFeatureCommand         = 36,
      
    DJIMONumCommands            = 255// to fix
} DJIMOCommandID;

typedef enum: uint8_t {
    DJIMOUnknownSensor         = 100,
    DJIMOLightwareSF10ASensor  = 101,
    DJIMOLidarMapSensor        = 102,
    DJIMOObjectDetectionSensor = 103,
    DJIMOCustomSensor          = 104,
} DJIMOSensorID;

typedef enum: uint8_t {
  DJIMOUnknownFeature        = 0,
  DJIMOROSNodeControl        = 1,
} DJIMOFeatureID;


typedef enum: uint8_t {
    DJIMobileSDKVersionUnknown = 0,
    DJIMobileSDKVersion43,
    DJIMobileSDKVersion431,
    DJIMobileSDKVersion44,
    DJIMobileSDKVersion45,
    DJIMobileSDKVersion50
} DJIMobileSDKVersion;

typedef enum: uint8_t {
    DJIOSDKVersionUnknown = 0,
    DJIOSDKVersion330,
    DJIOSDKVersion331,
    DJIOSDKVersion332,
    DJIOSDKVersion360,
    DJIOSDKVersion400,
} DJIMOOSDKVersion;

typedef enum: uint8_t {
    DJIMOErrorNone = 0,
    DJIMOErrorTimeout,
    
} DJIMOError;

#endif /* dji_mo_protocol_command_ids_hpp */
