//
// Created by DJI
//

#ifndef DJI_MO_PROTOCOL_DJI_MO_SENSOR_SMART_OBSTACLE_H
#define DJI_MO_PROTOCOL_DJI_MO_SENSOR_SMART_OBSTACLE_H

#include <vector>
#include <thread>
#include <mutex>

#include "dji_mo_sensor.hpp"
#include "dji_mo_sensor_subscription_pack.hpp"
#include "dji_mo_pack.hpp"

namespace DJI
{
namespace MOProtocol
{

class SmartObstacleSensorConfiguration: public MOSensorConfiguration
{
public:
  SmartObstacleSensorConfiguration();
  ~SmartObstacleSensorConfiguration();

public:
  uint8_t detectionModel;
  uint8_t numberOfObjectsToDetect;
  uint8_t* objectsToDetect;
  uint8_t probabilityThreshold;
};

/*
 *  Sensor
 */

class SmartObstacleSensor : public MOSensor
{
public:
  SmartObstacleSensor();
  ~SmartObstacleSensor();

public:
  // MOSensor interface;
  bool initiate();
  bool configure(MOSensorConfiguration* config);
  bool terminate();
};

/*
 *  DetectionBox
 */

#pragma pack(1)
struct DetectionBox
{

public:
  DetectionBox(uint8_t object,
               uint16_t topLeftUInPixel,
               uint16_t topLeftVInPixel,
               uint16_t widthInPixel,
               uint16_t heightInPixel,
               float xInMeter,
               float yInMeter,
               float zInMeter,
               uint8_t probability
  );
  DetectionBox(uint8_t *data);
  DetectionBox();
  ~DetectionBox();

  uint8_t* data();
  uint8_t  dataLength();

  uint8_t object;
  uint16_t topLeftUInPixel;
  uint16_t topLeftVInPixel;
  uint16_t widthInPixel;
  uint16_t heightInPixel;
  float xInMeter;
  float yInMeter;
  float zInMeter;
  uint8_t probability;
};
#pragma pack()
/*
 *  Pack
 */

class SmartObstacleSensorDataPack : public MOPack
{

public:
  SmartObstacleSensorDataPack(uint32_t seq,
                              uint32_t timeStampSec,
                              uint32_t timeStampNSec,
                              uint8_t cameraFrameID,
                              uint8_t numberOfDetections,
                              const DetectionBox *const detectionBoxes
  );
  SmartObstacleSensorDataPack(uint8_t *data);
  ~SmartObstacleSensorDataPack();

  uint8_t* data();
  uint8_t  dataLength();

  DJIMOSensorID sensorID;
  uint32_t seq;
  uint32_t timeStampSec;
  uint32_t timeStampNSec;
  uint8_t cameraFrameID;
  uint8_t numberOfDetections;
  DetectionBox* detectionBoxes;
};

class SmartObstacleSensorConfigurationPack : public MOPack
{

public:
  SmartObstacleSensorConfigurationPack(uint8_t detectionModel,
                                       uint8_t numberOfObjectsToDetect,
                                       uint8_t *objectsToDetect,
                                       uint8_t probabilityThreshold
  );
  SmartObstacleSensorConfigurationPack(uint8_t *data);

  uint8_t* data();
  uint8_t  dataLength();

  DJIMOSensorID sensorID;
  uint8_t detectionModel;
  uint8_t numberOfObjectsToDetect;
  uint8_t* objectsToDetect;
  uint8_t probabilityThreshold;
};
}
}

#endif
