//
//  dji_mo_sensor_count_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 7/28/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_sensor_count_pack_hpp
#define dji_mo_sensor_count_pack_hpp

#include "dji_mo_pack.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

class MOSensorCountRequestPack : public MOPack
{

public:
  MOSensorCountRequestPack();
  MOSensorCountRequestPack(uint8_t *data);
  
  uint8_t* data();
  uint8_t  dataLength();
};

class MOSensorCountAnswerPack : public MOPack
{
public:
  MOSensorCountAnswerPack(uint8_t count);
  MOSensorCountAnswerPack(uint8_t* data);

  uint8_t count;
  
  uint8_t* data();
  uint8_t  dataLength();
};
}
}

#endif /* dji_mo_sensor_count_pack_hpp */
