//
//  dji_mo_heartbeat_pack.hpp
//  MOProtocol
//
//  Created by Arnaud Thiercelin on 7/28/17.
//  Copyright © 2017 DJI. All rights reserved.
//

#ifndef dji_mo_heartbeat_pack_hpp
#define dji_mo_heartbeat_pack_hpp

#include "dji_mo_pack.hpp"
#include "dji_mo_protocol_command_ids.hpp"
#include <cstdint>
#include <iostream>

namespace DJI
{
namespace MOProtocol
{

class MOHeartbeatRequestPack : public MOPack
{

private:
  uint8_t heartbeatCount = 0; // will loop back to 0
  uint8_t heartbeatStage;

public:
  MOHeartbeatRequestPack();
  MOHeartbeatRequestPack(uint8_t* data);

  void increaseBeatCount();
  uint8_t getHeartBeatCount();
  void setHeartBeatCount(uint8_t count);

  /*
   * Gettest and setters for heartbeat stage
   */
  uint8_t getHeartbeatStage();
  void setHeartbeatStage(uint8_t stage);

  uint8_t* data();
  uint8_t  dataLength();
};

class MOHeartbeatAnswerPack : public MOPack
{
private:
  uint8_t heartbeatStage;
public:
  MOHeartbeatAnswerPack();
  MOHeartbeatAnswerPack(uint8_t* data);

  /*
   * Gettest and setters for heartbeat stage
   */
  uint8_t getHeartbeatStage();
  void setHeartbeatStage(uint8_t stage);

  uint8_t* data();
  uint8_t  dataLength();
};
}
}
#endif /* dji_mo_heartbeat_pack_hpp */
