#ifndef DJI_OCCUPANCY_GRID_BUILDER_H
#define DJI_OCCUPANCY_GRID_BUILDER_H

#include "ros/ros.h"
#include "sensor_msgs/PointCloud2.h"
#include "visualization_msgs/MarkerArray.h"

#include "octomap_ros/conversions.h"
#include <octomap_msgs/conversions.h>

#include "std_msgs/String.h"

#include "pcl_conversions/pcl_conversions.h"
#include <pcl/point_types.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>

#include <message_filters/subscriber.h>

#include <tf/transform_listener.h>
#include <tf/message_filter.h>

class OccupancyGridBuilder
{
public:
    OccupancyGridBuilder(ros::NodeHandle private_nh_ = ros::NodeHandle("~"));

    ~OccupancyGridBuilder();

    // Callback functions
    // 1. Callback when a velodyne_points message is received
    void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr &cloud);

protected:
    ros::NodeHandle m_nh;
    tf::TransformListener m_tfListener;

    // Subscribers
    //1. Subscriber to /velodyne_points message. We tried 2 kinds of subscriber.
    // One is through a message_filter, and the other is a bare subscriber
    message_filters::Subscriber<sensor_msgs::PointCloud2> *m_pointCloudSub;
    ros::Subscriber m_barePointCloudSub;

    //2. Subscriber to TF for pointcloud2
    tf::MessageFilter<sensor_msgs::PointCloud2>* m_tfSub;

    //Publishers
    ros::Publisher m_transformedPointCloudPub;  //pointcloud in map frame
    ros::Publisher m_debugPub;                  //debug message
    ros::Publisher m_occupiedMarkerPub;                 //occupied cells marker
    ros::Publisher m_binaryMapPub;

    sensor_msgs::PointCloud2Ptr m_pc;
    octomap::OcTree *m_pOcTree;

    std::string m_worldFrameName;
    double m_res;

private:
    void insertScan(const sensor_msgs::PointCloud2::ConstPtr &msg, octomap::OcTree *myTree);
    void transformPointCloud(const sensor_msgs::PointCloud2::ConstPtr msg_source, std::string target_frame=std::string("/map"));
    octomap::OcTree *createNewOcTree(void);
    octomap::OcTree * maintainOcTree(octomap::OcTree * tree_in);
    void publishAll(octomap::OcTree *myTree);
    void publishOccupiedGrid(octomap::OcTree *myTree, bool publishMarkerArray);
    void publishOcTree(octomap::OcTree *myTree);
};

#endif //DJI_OCCUPANCY_GRID_BUILDER_H