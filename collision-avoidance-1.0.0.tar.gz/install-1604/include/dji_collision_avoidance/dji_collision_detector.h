//
// Created by Zhiyuan Li on 11/7/16.
//
#ifndef DJI_COLLISION_DETECTOR_H
#define DJI_COLLISION_DETECTOR_H

#include "ros/ros.h"
#include "sensor_msgs/PointCloud2.h"
#include "visualization_msgs/MarkerArray.h"

#include "std_msgs/String.h"
#include "geometry_msgs/Vector3.h"

#include "pcl_conversions/pcl_conversions.h"
#include <pcl/point_types.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>

#include <message_filters/subscriber.h>

#include <tf/transform_listener.h>
#include <tf/message_filter.h>

#include <octomap_msgs/conversions.h>
#include <octomap/octomap.h>
#include <octomap_msgs/Octomap.h>
#include <octomap_msgs/GetOctomap.h>
#include <octomap_ros/conversions.h>

#include <dji_sdk/Velocity.h>
#include <dji_sdk/RCChannels.h>

#include <sstream>
#include <Eigen/Core>

class CollisionDetector
{
public:
    //CollisionDetector(ros::NodeHandle private_nh_ = ros::NodeHandle("~"));
    CollisionDetector();
    ~CollisionDetector();
    bool getDroneOrigin(void);


protected:
    ros::NodeHandle m_nh;

    // Subscribers
    // 1. subscribe to N-E-U velocity
    ros::Subscriber m_velocitySub; // = nh.subscribe("dji_sdk/velocity", 20, velCallback);
    // 2. subscribe to binary octree published by dji_octree_builder
    ros::Subscriber m_binaryOctreeSub;

    ros::Subscriber m_rcSub;

    // Publishers:
    ros::Publisher m_velocityVisulizationPub;
    ros::Publisher m_collisionVisulizationPub;
    ros::Publisher m_rcVisualizationPub;
    ros::Publisher m_raycastVisulizationPub;
    ros::Publisher m_debugQueryPub;
    ros::Publisher m_collisionInfoPub;

    ros::Publisher m_debugCollisionPub;
    geometry_msgs::Vector3 forDebug;

    tf::TransformListener m_tfListener;
    Eigen::Vector3f droneOriginInWorld;
    bool originFound;

private:
    Eigen::Vector3f m_currentVel;
    Eigen::Vector3f m_currentCmd;
    octomap::point3d m_collisionPoint;

    // Need to manually manage memory here, be careful
    octomap::OcTree *m_octree;
    octomap::AbstractOcTree *m_tempTree;

    void velCallback(const dji_sdk::Velocity::ConstPtr msg);

    void velCallback_ver2(const dji_sdk::Velocity::ConstPtr msg);

    void rcCallback(const dji_sdk::RCChannels msg);

    void octomapCallback(const octomap_msgs::OctomapConstPtr msg);

    void queryForward(octomap::OcTree *myTree, Eigen::Vector3f vel, double distance = 10.0);
    void queryForward_ver2(octomap::OcTree *myTree, Eigen::Vector3f vel, double distance = 10.0);
    void queryForward_ver3(octomap::OcTree *myTree, Eigen::Vector3f vel, double distance = 10.0);


    void displayVelocityVector(Eigen::Vector3f vel);
    void displayRaycast(Eigen::Vector3f vel, double distance);

    void displayRC(Eigen::Vector3f rc);

    void displayCollision(octomap::OcTree * m_octree);

};


#endif
