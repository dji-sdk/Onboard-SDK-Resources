//
// Created by rohit on 11/10/16.
//

#ifndef ONBOARDSDK_INTERNAL_TRAJECTORYROSINTERFACE_H
#define ONBOARDSDK_INTERNAL_TRAJECTORYROSINTERFACE_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string>
#include <sstream>
#include <iostream>
#include <pthread.h>

#pragma pack (1)
typedef struct {
  //! Velocity
  double vx;
  double vy;
  double vz;
  //! Velocity Health - can we trust the velocity?
  uint32_t health_flag;
  //! Attitude
  double q0;
  double q1;
  double q2;
  double q3;
  //! Command velocity
  double ux;
  double uy;
  double uz;
} stateData;
#pragma pack()

class TrajectoryROSInterface {
 public:
  TrajectoryROSInterface(int port){this->port = port; pauseLock = PTHREAD_MUTEX_INITIALIZER;}

  int setupSubscriber();
  stateData readOnce(int sockfd);
  bool getPause();
  void setPause(bool pauseVal);

 private:
  int subscriberWrite();
  void lockPause () {pthread_mutex_lock(&this->pauseLock);}
  void unlockPause () {pthread_mutex_unlock(&this->pauseLock);}
  void error(const char *msg);

  int port;
  bool pause;
  pthread_mutex_t pauseLock;
};

#endif //ONBOARDSDK_INTERNAL_TRAJECTORYROSINTERFACE_H
