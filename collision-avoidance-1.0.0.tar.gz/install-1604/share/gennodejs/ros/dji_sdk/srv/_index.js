
"use strict";

let MissionWpUpload = require('./MissionWpUpload.js')
let DroneArmControl = require('./DroneArmControl.js')
let MessageFrequencyControl = require('./MessageFrequencyControl.js')
let VelocityControl = require('./VelocityControl.js')
let GimbalAngleControl = require('./GimbalAngleControl.js')
let MissionFmSetTarget = require('./MissionFmSetTarget.js')
let MissionFmUpload = require('./MissionFmUpload.js')
let MissionWpGetSpeed = require('./MissionWpGetSpeed.js')
let AttitudeControl = require('./AttitudeControl.js')
let LocalPositionControl = require('./LocalPositionControl.js')
let VirtualRCEnableControl = require('./VirtualRCEnableControl.js')
let VersionCheck = require('./VersionCheck.js')
let SendDataToRemoteDevice = require('./SendDataToRemoteDevice.js')
let MissionWpDownload = require('./MissionWpDownload.js')
let GimbalSpeedControl = require('./GimbalSpeedControl.js')
let Activation = require('./Activation.js')
let MissionHpSetRadius = require('./MissionHpSetRadius.js')
let CameraActionControl = require('./CameraActionControl.js')
let MissionPause = require('./MissionPause.js')
let VirtualRCDataControl = require('./VirtualRCDataControl.js')
let MissionCancel = require('./MissionCancel.js')
let MissionHpDownload = require('./MissionHpDownload.js')
let SyncFlagControl = require('./SyncFlagControl.js')
let DroneTaskControl = require('./DroneTaskControl.js')
let MissionHpSetSpeed = require('./MissionHpSetSpeed.js')
let MissionStart = require('./MissionStart.js')
let MissionHpUpload = require('./MissionHpUpload.js')
let MissionWpSetSpeed = require('./MissionWpSetSpeed.js')
let SDKPermissionControl = require('./SDKPermissionControl.js')
let GlobalPositionControl = require('./GlobalPositionControl.js')
let MissionHpResetYaw = require('./MissionHpResetYaw.js')

module.exports = {
  MissionWpUpload: MissionWpUpload,
  DroneArmControl: DroneArmControl,
  MessageFrequencyControl: MessageFrequencyControl,
  VelocityControl: VelocityControl,
  GimbalAngleControl: GimbalAngleControl,
  MissionFmSetTarget: MissionFmSetTarget,
  MissionFmUpload: MissionFmUpload,
  MissionWpGetSpeed: MissionWpGetSpeed,
  AttitudeControl: AttitudeControl,
  LocalPositionControl: LocalPositionControl,
  VirtualRCEnableControl: VirtualRCEnableControl,
  VersionCheck: VersionCheck,
  SendDataToRemoteDevice: SendDataToRemoteDevice,
  MissionWpDownload: MissionWpDownload,
  GimbalSpeedControl: GimbalSpeedControl,
  Activation: Activation,
  MissionHpSetRadius: MissionHpSetRadius,
  CameraActionControl: CameraActionControl,
  MissionPause: MissionPause,
  VirtualRCDataControl: VirtualRCDataControl,
  MissionCancel: MissionCancel,
  MissionHpDownload: MissionHpDownload,
  SyncFlagControl: SyncFlagControl,
  DroneTaskControl: DroneTaskControl,
  MissionHpSetSpeed: MissionHpSetSpeed,
  MissionStart: MissionStart,
  MissionHpUpload: MissionHpUpload,
  MissionWpSetSpeed: MissionWpSetSpeed,
  SDKPermissionControl: SDKPermissionControl,
  GlobalPositionControl: GlobalPositionControl,
  MissionHpResetYaw: MissionHpResetYaw,
};
