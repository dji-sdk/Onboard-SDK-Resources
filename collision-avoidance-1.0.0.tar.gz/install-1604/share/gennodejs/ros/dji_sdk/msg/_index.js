
"use strict";

let A3GPS = require('./A3GPS.js');
let MissionStatusWaypoint = require('./MissionStatusWaypoint.js');
let MissionWaypointTask = require('./MissionWaypointTask.js');
let TransparentTransmissionData = require('./TransparentTransmissionData.js');
let Waypoint = require('./Waypoint.js');
let A3RTK = require('./A3RTK.js');
let MissionStatusFollowme = require('./MissionStatusFollowme.js');
let MissionHotpointTask = require('./MissionHotpointTask.js');
let Compass = require('./Compass.js');
let Velocity = require('./Velocity.js');
let PowerStatus = require('./PowerStatus.js');
let MissionEventWpUpload = require('./MissionEventWpUpload.js');
let WaypointList = require('./WaypointList.js');
let MissionPushInfo = require('./MissionPushInfo.js');
let LocalPosition = require('./LocalPosition.js');
let MissionWaypoint = require('./MissionWaypoint.js');
let MissionFollowmeTarget = require('./MissionFollowmeTarget.js');
let GlobalPosition = require('./GlobalPosition.js');
let MissionEventWpAction = require('./MissionEventWpAction.js');
let TimeStamp = require('./TimeStamp.js');
let MissionWaypointAction = require('./MissionWaypointAction.js');
let FlightControlInfo = require('./FlightControlInfo.js');
let MissionStatusHotpoint = require('./MissionStatusHotpoint.js');
let MissionEventWpReach = require('./MissionEventWpReach.js');
let MissionStatusOther = require('./MissionStatusOther.js');
let Acceleration = require('./Acceleration.js');
let AttitudeQuaternion = require('./AttitudeQuaternion.js');
let RCChannels = require('./RCChannels.js');
let MissionFollowmeTask = require('./MissionFollowmeTask.js');
let Gimbal = require('./Gimbal.js');
let DroneTaskResult = require('./DroneTaskResult.js');
let GlobalPositionNavigationAction = require('./GlobalPositionNavigationAction.js');
let WaypointNavigationFeedback = require('./WaypointNavigationFeedback.js');
let DroneTaskActionFeedback = require('./DroneTaskActionFeedback.js');
let DroneTaskGoal = require('./DroneTaskGoal.js');
let WaypointNavigationActionGoal = require('./WaypointNavigationActionGoal.js');
let DroneTaskActionResult = require('./DroneTaskActionResult.js');
let GlobalPositionNavigationFeedback = require('./GlobalPositionNavigationFeedback.js');
let WaypointNavigationActionFeedback = require('./WaypointNavigationActionFeedback.js');
let LocalPositionNavigationActionFeedback = require('./LocalPositionNavigationActionFeedback.js');
let DroneTaskFeedback = require('./DroneTaskFeedback.js');
let GlobalPositionNavigationGoal = require('./GlobalPositionNavigationGoal.js');
let DroneTaskAction = require('./DroneTaskAction.js');
let LocalPositionNavigationGoal = require('./LocalPositionNavigationGoal.js');
let WaypointNavigationActionResult = require('./WaypointNavigationActionResult.js');
let LocalPositionNavigationResult = require('./LocalPositionNavigationResult.js');
let GlobalPositionNavigationResult = require('./GlobalPositionNavigationResult.js');
let LocalPositionNavigationActionGoal = require('./LocalPositionNavigationActionGoal.js');
let LocalPositionNavigationActionResult = require('./LocalPositionNavigationActionResult.js');
let LocalPositionNavigationFeedback = require('./LocalPositionNavigationFeedback.js');
let GlobalPositionNavigationActionFeedback = require('./GlobalPositionNavigationActionFeedback.js');
let WaypointNavigationGoal = require('./WaypointNavigationGoal.js');
let GlobalPositionNavigationActionGoal = require('./GlobalPositionNavigationActionGoal.js');
let GlobalPositionNavigationActionResult = require('./GlobalPositionNavigationActionResult.js');
let WaypointNavigationAction = require('./WaypointNavigationAction.js');
let WaypointNavigationResult = require('./WaypointNavigationResult.js');
let LocalPositionNavigationAction = require('./LocalPositionNavigationAction.js');
let DroneTaskActionGoal = require('./DroneTaskActionGoal.js');

module.exports = {
  A3GPS: A3GPS,
  MissionStatusWaypoint: MissionStatusWaypoint,
  MissionWaypointTask: MissionWaypointTask,
  TransparentTransmissionData: TransparentTransmissionData,
  Waypoint: Waypoint,
  A3RTK: A3RTK,
  MissionStatusFollowme: MissionStatusFollowme,
  MissionHotpointTask: MissionHotpointTask,
  Compass: Compass,
  Velocity: Velocity,
  PowerStatus: PowerStatus,
  MissionEventWpUpload: MissionEventWpUpload,
  WaypointList: WaypointList,
  MissionPushInfo: MissionPushInfo,
  LocalPosition: LocalPosition,
  MissionWaypoint: MissionWaypoint,
  MissionFollowmeTarget: MissionFollowmeTarget,
  GlobalPosition: GlobalPosition,
  MissionEventWpAction: MissionEventWpAction,
  TimeStamp: TimeStamp,
  MissionWaypointAction: MissionWaypointAction,
  FlightControlInfo: FlightControlInfo,
  MissionStatusHotpoint: MissionStatusHotpoint,
  MissionEventWpReach: MissionEventWpReach,
  MissionStatusOther: MissionStatusOther,
  Acceleration: Acceleration,
  AttitudeQuaternion: AttitudeQuaternion,
  RCChannels: RCChannels,
  MissionFollowmeTask: MissionFollowmeTask,
  Gimbal: Gimbal,
  DroneTaskResult: DroneTaskResult,
  GlobalPositionNavigationAction: GlobalPositionNavigationAction,
  WaypointNavigationFeedback: WaypointNavigationFeedback,
  DroneTaskActionFeedback: DroneTaskActionFeedback,
  DroneTaskGoal: DroneTaskGoal,
  WaypointNavigationActionGoal: WaypointNavigationActionGoal,
  DroneTaskActionResult: DroneTaskActionResult,
  GlobalPositionNavigationFeedback: GlobalPositionNavigationFeedback,
  WaypointNavigationActionFeedback: WaypointNavigationActionFeedback,
  LocalPositionNavigationActionFeedback: LocalPositionNavigationActionFeedback,
  DroneTaskFeedback: DroneTaskFeedback,
  GlobalPositionNavigationGoal: GlobalPositionNavigationGoal,
  DroneTaskAction: DroneTaskAction,
  LocalPositionNavigationGoal: LocalPositionNavigationGoal,
  WaypointNavigationActionResult: WaypointNavigationActionResult,
  LocalPositionNavigationResult: LocalPositionNavigationResult,
  GlobalPositionNavigationResult: GlobalPositionNavigationResult,
  LocalPositionNavigationActionGoal: LocalPositionNavigationActionGoal,
  LocalPositionNavigationActionResult: LocalPositionNavigationActionResult,
  LocalPositionNavigationFeedback: LocalPositionNavigationFeedback,
  GlobalPositionNavigationActionFeedback: GlobalPositionNavigationActionFeedback,
  WaypointNavigationGoal: WaypointNavigationGoal,
  GlobalPositionNavigationActionGoal: GlobalPositionNavigationActionGoal,
  GlobalPositionNavigationActionResult: GlobalPositionNavigationActionResult,
  WaypointNavigationAction: WaypointNavigationAction,
  WaypointNavigationResult: WaypointNavigationResult,
  LocalPositionNavigationAction: LocalPositionNavigationAction,
  DroneTaskActionGoal: DroneTaskActionGoal,
};
