// Auto-generated. Do not edit!

// (in-package dji_sdk_web_groundstation.msg)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');

//-----------------------------------------------------------

class MapNavSrvCmd {
  constructor() {
    this.cmdCode = 0;
    this.tid = 0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type MapNavSrvCmd
    // Serialize message field [cmdCode]
    bufferInfo = _serializer.uint8(obj.cmdCode, bufferInfo);
    // Serialize message field [tid]
    bufferInfo = _serializer.uint64(obj.tid, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type MapNavSrvCmd
    let tmp;
    let len;
    let data = new MapNavSrvCmd();
    // Deserialize message field [cmdCode]
    tmp = _deserializer.uint8(buffer);
    data.cmdCode = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [tid]
    tmp = _deserializer.uint64(buffer);
    data.tid = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a message object
    return 'dji_sdk_web_groundstation/MapNavSrvCmd';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '321f9fe469695036c44374febd41879e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #command code
    uint8 cmdCode
    #task id
    uint64 tid
    
    `;
  }

};

module.exports = MapNavSrvCmd;
