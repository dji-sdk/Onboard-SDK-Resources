#!/usr/bin/env python  

import roslib
import rospy

import numpy as np
import tf

from dji_sdk.msg import AttitudeQuaternion

def callback(msg):
    #print "Got Quaternion, generating transform"

    br = tf.TransformBroadcaster()

    # Map (N-W-U) --(static)--> World (N-E-D) --(dynamic)--> Drone (Forward-Right-Down) --(static)--> Velodyne (Back-Right-Up)

    # Map to World
    br.sendTransform( (0.0, 0.0, 0.0),
                      tf.transformations.quaternion_from_euler(3.1415926, 0.0, 0.0),
                      rospy.get_rostime(),
                      "world",
                      'map'
                      )


    q_w_to_drone = (msg.q1, msg.q2, msg.q3, msg.q0)
    normcheck = np.linalg.norm(q_w_to_drone)

#    q=tf.transformations.quaternion_inverse(q_w_to_drone)
#     m=tf.transformations.quaternion_matrix((0.,0.,0.,1.))
#     m[2][2]=-1.0
#     
#     q_drone_to_velo = tf.transformations.quaternion_from_euler(3.1415926,0,0,'sxyz')
    
   # q_w_to_velo = tf.transformations.quaternion_multiply(q_drone_to_velo, q_w_to_drone)

    # World to drone
    if (normcheck>0.99 and normcheck<1.01):
        br.sendTransform((0.0,0.0, -0.01),
                         q_w_to_drone,
                          rospy.get_rostime(),
                         'drone',
                         'world'
                         )
    else:
        rospy.loginfo("Bad Quaternion is received: (%f, %f, %f, %f)", msg.q1, msg.q2, msg.q3, msg.q0)

    # Drone to velodyne
    br.sendTransform( (0.0, 0.0, 0.2),
                      #tf.transformations.quaternion_about_axis(3.1415926, [0,1,0]),
                      tf.transformations.quaternion_from_euler(0.0, 0.0, -3.1415926/2.0), # this is for the new M600 mount
                      rospy.get_rostime(),
                      'velodyne',
                      'drone'
                    )

                       #tf.transformations.quaternion_from_euler(3.1415926, 0.0, 0.0),


#     br.sendTransform((0.5,0.5,0.5),
#                      q_drone_to_velo,
#                       rospy.get_rostime(),
#                      'velodyne',
#                      'drone'
#                      )
                     
    

def listener():
    rospy.init_node('py_drone_tf', anonymous=True)
    rospy.Subscriber('dji_sdk/attitude_quaternion', AttitudeQuaternion, callback)
    
#     x= tf.transformations.rotation_matrix(0.123, (1, 2, 3))
#     print x
#     
#     y=tf.transformations.quaternion_matrix((0,0,0,1))
#     print y
#     
#     m=tf.transformations.quaternion_matrix((0.,0.,0.,1.))
#     m[2][2]=-1.0
#     q_drone_to_velo = tf.transformations.quaternion_from_euler(0,0,3.1415926,'szyx')
#     print m
#     
#     print q_drone_to_velo
    rospy.spin()

if __name__ == '__main__':
    listener()
