//
//  dji_common_network_manager.hpp
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/13.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_network_manager_hpp
#define dji_common_network_manager_hpp

#include <stdio.h>
#include "network/dji_common_network_defines.h"

namespace dji {
    namespace common {
        class NetworkManager {
        public:
            NetworkManager( const NetworkManager& ) = delete;
            NetworkManager& operator=(const NetworkManager&) = delete;
            
            static NetworkManager& GetInstance();
            
            /**
             * 设置发送网络请求的实现
             */
            void SetNetworkSendRequestHandle(const NetworkRequestHandle& handle);
            
            /**
             * 设置下载文件用的网络请求实现
             */
            void SetNetworkDownloadDataHandle(NetworkDownloadDataHandle handle);
            
            /**
             *  设置取消文件下载请求
             */
            void SetNetworkDownloadStopHandle(NetworkDownloadStopHandle handle);
            
            /**
             * 网络请求
             */
            void SendRequest(std::shared_ptr<NetworkRequest> request, ResponseCallback callback);
            
            /**
             * 文件下载
             */
            int DownloadFile(const std::string& url, const std::string& filePath, DownloadProgressCallback progress_callback, BoolResponseCallback callback);
            
            /**
             *  取消文件下载
             */
            void StopDownloadFile(int net_op_id);
            
        protected:
            NetworkManager() {};
            virtual ~NetworkManager() {};
        private:
            NetworkRequestHandle send_request_handle_;
            NetworkDownloadDataHandle download_data_handle_;
            NetworkDownloadStopHandle download_stop_handle_;
        };
    }
}


#endif /* dji_common_network_manager_hpp */
