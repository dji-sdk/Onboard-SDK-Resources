//
//  dji_common_interface.hpp
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/16.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_interface_hpp
#define dji_common_interface_hpp

#include <stdio.h>
#include <packmanager/djicommonpackmanagerdefines.hpp>
#include <network/dji_common_network_defines.h>
#include <djicommoncommondefines.hpp>

namespace dji {
    namespace common {
// Register Device
        void RegisterDevice(uint64_t);
        void UnregisterDevice(uint64_t device_id);
        
// PackManager
        //Pack send handle
        void SetDJICommonPackManagerSendPackHandle(PackReqHandle handle);
        void SetDJICommonPackManagerDirectSendPackHandle(PackDirectReqHandle handle);
        //Push Pack Listen handle
        void UpdatePushPackInfo(uint64_t device_id, PackType push_type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, uint16_t seq_num, const void *data, int data_length);
        
// Network
        void SetNetworkSendRequestHandle(const NetworkRequestHandle& handle);
        void SetNetworkDownloadDataHandle(NetworkDownloadDataHandle handle);
        void SetNetworkDownloadStopHandle(NetworkDownloadStopHandle handle);

// Provider
        void SetIsNetworkConnectedHandle(ReturnBoolValueHandle handle);
        void SetPhoneLocationHandle(ReturnLocationValueHandle handle);
        void SetCountryCodeHandle(ReturnStringValueHandle handle);
        void SetClientVersionHandle(ReturnStringValueHandle handle);
        void SetClientOSHandle(ReturnStringValueHandle handle);
        void SetClientLanguageHandle(ReturnSystemLanguageValueHandle handle);
        //account
        void SetGetTokenHandle(ReturnStringValueHandle handle);
        //device
        void SetIsDeviceConnectedHandle(ReturnDeviceBoolValueHandle handle);
        void SetDeviceRCModeHandle(ReturnDeviceRCModeValueHandle handle);
        void SetDeviceSerialNumberHandle(ReturnDeviceStringValueHandle handle);
        void SetDeviceMotorOnHandle(ReturnDeviceBoolValueHandle handle);
        void SetIsDeviceSupportGEOHandle(ReturnDeviceBoolValueHandle handle);
        void SetDeviceMCProtocolVersionHandle(ReturnDeviceIntValueHandle handle);
        void SetIsDeviceUseDJIFlightDBHandle(ReturnDeviceBoolValueHandle handle);
        void SetIsDeviceSupportDynamicDBHandle(ReturnDeviceBoolValueHandle handle);
        void SetIsDeviceUseLicenseUnlockHandle(ReturnDeviceBoolValueHandle handle);
        void SetIsDeviceInGoHomeModeHandle(ReturnDeviceBoolValueHandle handle);
        void SetIsDeviceInSmartModeHandle(ReturnDeviceBoolValueHandle handle);
        void SetDeviceUnlockAreaIdsHandle(ReturnDeviceIntVectorValueHandle handle);
        void SetIsDeviceIsOsmoHandle(ReturnDeviceBoolValueHandle handle);
        void SetDeviceDroneTypeValueHandle(ReturnDeviceDroneTypeValueHandle handle);
        void SetDeviceRCDroneTypeValueHandle(ReturnDeviceRCDroneTypeValueHandle handle);
        void SetIsDeviceSupportNavigationModeHandle(ReturnDeviceBoolValueHandle handle);
        void SetDeviceProductTypeValueHandle(ReturnDeviceProductTypeValueHandle handle);
        void SetDeviceLocationHandle(ReturnDeviceLocationValueHandle handle);
		void SetIsSupportWPV2Handle(ReturnDeviceBoolValueHandle handle);
// State Change
        void UpdateDeviceState(uint64_t device_id, DeviceEvent event);
        void UpdateSystemState(SystemEvent event);
        
// Account Data
        //设置获取用户账号信息实现调用者
        void SetAccountDataProviderGetTokenHandle(ReturnStringValueHandle handle);
        void SetAccountDataProviderGetUserAPICenterIDHandle(ReturnStringValueHandle handle);
        void SetAccountDataProviderGetEmailHandle(ReturnStringValueHandle handle);
        void SetAccountDataProviderGetPhoneNumbertHandle(ReturnStringValueHandle handle);
        void SetAccountDataProviderIsTokenValidHandle(ReturnBoolValueHandle handle);
        void SetAccountDataProviderIsUserLoginHandle(ReturnBoolValueHandle handle);

// Log Center
        //设置日志系统实现调用者(可选)
        void SetLogCenterDebugLogHandle(LogActionHandle handle);
        void SetLogCenterInfoLogHandle(LogActionHandle handle);
        void SetLogCenterErrorLogHandle(LogActionHandle handle);

        
    }
}

#endif /* dji_common_interface_hpp */
