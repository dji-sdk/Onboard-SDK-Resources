//
//  djiwaypointv2abstractioncachedata.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 09/05/2018.
//

#ifndef djiwaypointv2abstractioncachedata_hpp
#define djiwaypointv2abstractioncachedata_hpp

#include <packmanager/djicommonpackmanagermcstructs.h>
#include <djicommoncommondefines.hpp>
#include <dji_waypointv2_protocol_struct_defines.hpp>
#include <WaypointV2.pb.h>

namespace dji {
	namespace waypointv2 {
		using namespace common;
		class WaypointMission;
		class AbstractionCacheData {
		public:
			AbstractionCacheData();
			~AbstractionCacheData();
			
			void Reset();
			void ResetMissionStatusStruct();
			bool IsMissionStatusInited();
			bool IsMissionStatusChanged(dji_fc2_set_API_WP2_DATA_PUSH_req status, uint64_t length);
			bool IsMissionValid();
			void UpdateMissionStatus(dji_fc2_set_API_WP2_DATA_PUSH_req status, uint64_t length);
			
			dji_fc2_set_API_WP2_DATA_PUSH_req* cache_mission_status_ = nullptr;
			uint64_t cache_mission_status_length_ = 0;
			
			std::shared_ptr<WaypointMission> mission_ = nullptr;
            std::vector<WaypointActionConfig> actions_;
            std::pair<int32_t, int32_t> action_range_;

            int prev_uploaded_index = -1;
            int prev_uploaded_action_index_ = -1;
            uint8_t prev_paused_exec_state = None;
		};
	}
}

#endif /* djiwaypointv2abstractioncachedata_hpp */
