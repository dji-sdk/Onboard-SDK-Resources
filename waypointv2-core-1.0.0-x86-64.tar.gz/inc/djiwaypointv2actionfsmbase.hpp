//
//  djiwaypointv2actionfsmbase.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djiwaypointv2actionfsmbase_hpp
#define djiwaypointv2actionfsmbase_hpp

#include <statemachine/djicommonfinitestatemachine.hpp>
#include <packmanager/djicommonpackmanagerdefines.hpp>
#include "djiwaypointv2fsmtempstatetimer.hpp"

namespace dji {
	namespace waypointv2 {
		using namespace common;
		
		#define DEFAULT_TIMEOUT_FOR_OPERATION (0.5)
		
		class ActionStateListener {
		public:
			ActionStateListener(){};
			virtual ~ActionStateListener(){};
			
			virtual void didUpdateState(uint64_t device_id, int prev_state, int cur_state, int event, const std::string& data_infos) = 0;
		};
		
		class ActionFSMBase {
		public:
			ActionFSMBase();
			virtual ~ActionFSMBase();
			//子类来实现
			virtual void SetupActionFSM() = 0;
			
// State
			
			void SetFilteringActionStates(const std::vector<int>& states);
			void CleanFilteringActionStates();
			std::set<int> GetFilteringActionStates();
			int GetCurrentActionState();
			bool TryTransitToTempActionState(int state, const std::vector<int>& filtering_states = {});
			bool TryTransitToActionState(int state, int event, std::function<std::string()> data_generator);
			void ForceTransitToActionState(int state, int event, std::function<std::string()> data_generator);
			void TransitToActionState(int state, int event, std::function<std::string()> data_generator);
			void TriggerActionEvent(int event, std::function<std::string()> data_generator);
			void NotifyActionListeners(int prev_state, int cur_state, int event, std::function<std::string()> data_generator);
			
// Listeners
			
			void AddActionListener(const std::shared_ptr<ActionStateListener> listener);
			void RemoveActionListener(const std::shared_ptr<ActionStateListener> listener);
			void RemoveAllActionListener(const std::shared_ptr<ActionStateListener> listener);
			
// Operation Callback
			CommonErrorCallback  CommonErrorCallbackForActionOperation(int temp_state, const std::set<int>& desired_states, int failure_state, int failure_event, CommonErrorCallback ori_callback, float time_out_in_seconds = DEFAULT_TIMEOUT_FOR_OPERATION);
		protected:
			FiniteStateMachine<int> action_fsm_;
			uint64_t action_fsm_device_id_ = 0;
			std::set<int> action_filtering_states_;
			std::shared_ptr<FSMTempStateTimer> action_fsm_temp_state_timer_ = nullptr;
			std::set<std::shared_ptr<ActionStateListener>> action_listeners_;
		};
	}
}

#endif /* djiwaypointv2actionfsmbase_hpp */
