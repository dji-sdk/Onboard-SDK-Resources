//
//  djiwaypointv2abstractionfsmbase.hpp
//  DJICSDKCommon
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djiwaypointv2abstractionfsmbase_hpp
#define djiwaypointv2abstractionfsmbase_hpp

#include <statemachine/djicommonfinitestatemachine.hpp>
#include <packmanager/djicommonpackmanagerdefines.hpp>
#include "djiwaypointv2fsmtempstatetimer.hpp"

namespace dji {
	namespace waypointv2 {
		using namespace common;
		
		#define DEFAULT_TIMEOUT_FOR_OPERATION (0.5)
		
		class AbstractionListener {
		public:
			AbstractionListener(){};
			virtual ~AbstractionListener(){};
			
			virtual void didUpdateState(uint64_t device_id, int prev_state, int cur_state, int event, const std::string& data_infos) = 0;
		};
		
		class AbstractionFSMBase {
		public:
			AbstractionFSMBase();
			virtual ~AbstractionFSMBase();
			//子类来实现
			virtual void SetupFSM() = 0;
			
// State
			
			void SetFilteringStates(const std::vector<int>& states);
			void CleanFilteringStates();
			std::set<int> GetFilteringStates();
			int GetCurrentState();
			bool TryTransitToTempState(int state, const std::vector<int>& filtering_states = {});
			bool TryTransitToState(int state, int event, std::function<std::string()> data_generator);
			void ForceTransitToState(int state, int event, std::function<std::string()> data_generator);
			void TransitToState(int state, int event, std::function<std::string()> data_generator);
			void TriggerEvent(int event, std::function<std::string()> data_generator);
			void NotifyListeners(int prev_state, int cur_state, int event, std::function<std::string()> data_generator);
			
// Listeners
			
			void AddListener(const std::shared_ptr<AbstractionListener> listener);
			void RemoveListener(const std::shared_ptr<AbstractionListener> listener);
			void RemoveAllListener(const std::shared_ptr<AbstractionListener> listener);
			
// Operation Callback
			CommonErrorCallback  CommonErrorCallbackForOperation(int temp_state, const std::set<int>& desired_states, int failure_state, int failure_event, CommonErrorCallback ori_callback, float time_out_in_seconds = DEFAULT_TIMEOUT_FOR_OPERATION);
		protected:
			FiniteStateMachine<int> fsm_;
			uint64_t fsm_device_id_ = 0;
			std::set<int> filtering_states_;
			std::shared_ptr<FSMTempStateTimer> fsm_temp_state_timer_ = nullptr;
			std::set<std::shared_ptr<AbstractionListener>> listeners_;
		};
	}
}

#endif /* djiwaypointv2abstractionfsmbase_hpp */
