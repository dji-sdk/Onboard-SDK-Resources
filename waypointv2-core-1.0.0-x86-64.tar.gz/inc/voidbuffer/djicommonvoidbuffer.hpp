//
//  djicommonvoidbuffer.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djicommonvoidbuffer_hpp
#define djicommonvoidbuffer_hpp

#include <stdio.h>
#include <memory>

#if defined (__linux__)
#include <cstring>
#endif

namespace dji {
	namespace common {
		class VoidBuffer {
		public:
			VoidBuffer(const void *data, int length);
			~VoidBuffer() { data_ = nullptr; };
			std::shared_ptr<void> data_ = nullptr;
			int data_length_ = 0;
		};
	}
}
#endif /* djicommonvoidbuffer_hpp */
