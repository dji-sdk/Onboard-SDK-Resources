//
//  dji_common_system_event_dispatcher.hpp
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/13.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_system_event_dispatcher_hpp
#define dji_common_system_event_dispatcher_hpp

#include <stdio.h>
#include <vector>
#include <functional>
#include <map>
#include <djicommoncommondefines.hpp>

namespace dji {
    namespace common {
        //这个类只负责通知状态改变，具体当前状态应该通过 SystemStateProvider/AccountDataProvider 去拿。
        
        class ISystemEventListener {
        public:
            virtual ~ISystemEventListener() {}
        };
        
        typedef std::function<void(SystemEvent)> EventCallback;
        
        //方便以后扩展, 如回调队列
        struct SystemEventListenerWrapper {
            SystemEventListenerWrapper(ISystemEventListener* listener, SystemEvent event, const EventCallback& callback) : listener_(listener), callback_(callback), event_(event)  {}
            ~SystemEventListenerWrapper() {};
            
            ISystemEventListener* listener_;
            EventCallback callback_;
            SystemEvent event_;
        };
        
        class SystemEventDispatcher {
        public:
            SystemEventDispatcher(const SystemEventDispatcher&) = delete;
            SystemEventDispatcher& operator=(const SystemEventDispatcher&) = delete;
            
            static SystemEventDispatcher& GetInstance();
            //上层通知状态改变Event 上层的消息不确定在哪个线程
            void SystemStateChanged(SystemEvent event);
            
            void AddSystemStateChangedListener(ISystemEventListener* listener, SystemEvent event, const EventCallback& callback);
            void AddSystemStateChangedListener(ISystemEventListener* listener, std::vector<SystemEvent> events, const EventCallback& callback);
            
            void RemoveListener(ISystemEventListener* listener, SystemEvent event);
            void RemoveListener(ISystemEventListener* listener);
            
        private:
            SystemEventDispatcher() {};
            ~SystemEventDispatcher() {};
        private:
            std::map<SystemEvent, std::vector<SystemEventListenerWrapper>> listeners_;
        };
    }
}

#endif /* dji_common_system_event_dispatcher_hpp */
