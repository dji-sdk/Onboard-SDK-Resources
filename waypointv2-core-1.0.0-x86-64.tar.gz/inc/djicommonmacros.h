//
//  djicommonmacros.h
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djicommonmacros_h
#define djicommonmacros_h


#include "log/djicommonlogsystemprovider.hpp"
#include <assert.h>

#define Common_Debug_Log(fmt, ...)\
dji::common::LogCenterProvider::GetInstance().DebugLog(fmt, ##__VA_ARGS__)

#define Common_Info_Log(fmt, ...)\
dji::common::LogCenterProvider::GetInstance().INFOLog(fmt, ##__VA_ARGS__)

#define Common_Error_Log(fmt, ...)\
dji::common::LogCenterProvider::GetInstance().ERRORLog(fmt, ##__VA_ARGS__)

#define SAFE_LAMBDA(lambda, ...) if(lambda){lambda(__VA_ARGS__);}

#if DEBUG
#define DEBUG_ASSERT assert(0);
#else
#define DEBUG_ASSERT
#endif

#endif /* djicommonmacros_h */
