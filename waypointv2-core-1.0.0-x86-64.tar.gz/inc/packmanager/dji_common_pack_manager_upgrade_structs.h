//
//  dji_common_pack_manager_upgrade_structs.h
//  DJIFirmwareUpgradeCore
//
//  Created by jason zheng on 2018/5/10.
//  Copyright © 2018年 DJI. All rights reserved.
//

#ifndef dji_common_pack_manager_upgrade_structs_h
#define dji_common_pack_manager_upgrade_structs_h

#include <stdint.h>

namespace dji {
    namespace common {
// Enum
        typedef enum : uint8_t {
            //cfg文件
            DJICommonConfigFileType_VersionDes = 1,
            //升级log
            DJICommonConfigFileType_UpgradeLog = 2,
            //1860所有license文件
            DJICommonConfigFileType_License    = 3,
        } DJICommonConfigFileType;
        
        typedef enum : uint8_t {
            DJICommonFileTransferSubCommand_Request = 1, //请求接收数据
            DJICommonFileTransferSubCommand_Send    = 2, //传输数据
            DJICommonFileTransferSubCommand_Verify  = 3, //校验传输完整性
            //支持loss list ack的传输方式
            DJICommonFileTransferSubCommand_LoseListSend = 4,
        } DJICommonFileTransferSubCommand;
        
        //校验传输完整的方法
        typedef enum : uint8_t {
            DJICommonFileTransferVerifyMethod_None = 0,
            DJICommonFileTransferVerifyMethod_MD5 = 1,
            DJICommonFileTransferVerifyMethod_CRC16 = 2,
            DJICommonFileTransferVerifyMethod_CRC32 = 3,
        } DJICommonFileTransferVerifyMethod;
        
        //通用文件传输回包方式（240开始有该字段）
        typedef enum : uint8_t {
            DJICommonFileTransferProtocolType_AckEveryOne = 0, //每个丢包丢ack
            DJICommonFileTransferProtocolType_AckLostList = 1, //定时ack+lost list
        } DJICommonFileTransferProtocolType;
        
        typedef enum : uint8_t {
            DJICommonFileTransferFileType_Common = 0,
            DJICommonFileTransferFileType_Firmware = 1,
            DJICommonFileTransferFileType_Pano = 2,
            DJICommonFileTransferFileType_QuickShot = 3,
        } DJICommonFileTransferFileType;
        
        typedef enum : uint8_t {
            DJIFirmwarePushUpgradeState_Unknown = 0,
            DJIFirmwarePushUpgradeState_Checking = 1,
            DJIFirmwarePushUpgradeState_UserConfirm = 2,
            DJIFirmwarePushUpgradeState_OnGoing = 3,
            DJIFirmwarePushUpgradeState_End = 4,
            DJIFirmwarePushUpgradeState_Upgrading = 5, //表明是数据拷贝的升级方式，即数据库升级方式
        } DJIFirmwarePushUpgradeState;
        
        typedef enum : uint8_t {
            //升级成功
            DJIUpgradeEndReason_Success = 1,
            //升级失败
            DJIUpgradeEndReason_Failed = 2,
            DJIUpgradeEndReason_FirmwareError= 3,           //固件错误
            DJIUpgradeEndReason_SameVersion= 4,             //版本号一致
            DJIUpgradeEndReason_UserCancel= 5,              //用户取消
            DJIUpgradeEndReason_TimeOut = 6,                //等待超时取消
            DJIUpgradeEndReason_MotorRunning = 7,           //电机起转
            DJIUpgradeEndReason_FirmwareNotMatch = 8,       //固件不匹配
            DJIUpgradeEndReason_InvalidateRollBack = 9,     //非法降级
            DJIUpgradeEndReason_AirDataLinkError = 10,      //天空端数据链路不通
            DJIUpgradeEndReason_AirSDRError = 11,           //天空端SDR故障
            DJIUpgradeEndReason_GroundSDRError = 12,        //地面端SDR鼓掌
            DJIUpgradeEndReason_TransferError = 13,         //固件传输错误
            DJIUpgradeEndReason_AirControlLinkError = 14,   //天空端控制链路不通
            DJIUpgradeEndReason_AirFirmwarePackError = 15,  //天空端固件打包错误
            DJIUpgradeEndReason_NotFindConfigFile = 16,     //找不到升级配置文件
            DJIUpgradeEndReason_GlassFimrwarePackError = 17,//眼镜端固件错误
            //地面端和眼镜端天地反转后失联
            DJIUpgradeEndReason_GroundDisconnectGlassFirstTime = 18,
            //地面端和眼镜端天地反转2次后失联
            DJIUpgradeEndReason_GroundDisconnectGlassSecondeTime = 19,
            //地面端向眼镜端传输固件失败
            DJIUpgradeEndReason_GroundToGlassError = 20,
            //大包解压缩出错
            DJIUpgradeEndReason_FirmwarePackExtractError = 21,
            //相机推来了100,同是成功
            DJIUpgradeEndReason_CameraSuccess = 100,
        } DJIUpgradeEndReason;
        
        typedef enum : uint8_t {
            DJIUpgradeCopyDataState_Success              = 0,//成功
            DJIUpgradeCopyDataState_Failed               = 1,//失败
            DJIUpgradeCopyDataState_FirmwareError        = 2,//固件错误
            DJIUpgradeCopyDataState_WaitTimeout          = 3,//超时
            DJIUpgradeCopyDataState_AirDataLinkDown      = 4,//天空端链接不通
            DJIUpgradeCopyDataState_AirSDRError          = 5,//天空端SDK故障
            DJIUpgradeCopyDataState_GroundSDRError       = 6,//地面端SDK故障
            DJIUpgradeCopyDataState_GroundToAirFail      = 7,//地面向天空端传输固件失败
            DJIUpgradeCopyDataState_AirControlLinkDown   = 8,
            DJIUpgradeCopyDataState_ReqAirReceiveError   = 9,//请求飞机接收数据应答有误
            DJIUpgradeCopyDataState_PackUnzipError       = 10,//解压失败
            DJIUpgradeCopyDataState_SigVerifyError       = 11,//签名验证错误
            DJIUpgradeCopyDataState_DataCopyError        = 12,//数据拷贝错误
            DJIUpgradeCopyDataState_FTPTransferError     = 13,//FTP传输失败
        } DJIUpgradeCopyDataState;

        typedef enum : uint8_t {
            DJISubModuleUpgradeState_Completed                      = 0, //已完成
            DJISubModuleUpgradeState_Upgrading                      = 1, //进行中
            DJISubModuleUpgradeState_Waiting                        = 2,  //等待中
            DJISubModuleUpgradeState_Error                          = 3,  //错误
            DJISubModuleUpgradeState_CanNotCheck                    = 4,  //设备不能检查到
            DJISubModuleUpgradeState_VersionMatch                   = 5, //版本一致无需升级
            DJISubModuleUpgradeState_FirmwareError                  = 6, //固件错误
            DJISubModuleUpgradeState_EnterUpgradeModeFail           = 7, //请求进入升级模式失败
            DJISubModuleUpgradeState_ReqReceiveFirmwareDataError    = 8, //请求接收固件失败
            DJISubModuleUpgradeState_TransferErrorByV1              = 9, //通过V1协议传输失败
            DJISubModuleUpgradeState_TransferErrorByFtp             = 10, //通过FTP传输固件失败
            DJISubModuleUpgradeState_HardwareError                  = 11,  //硬解故障
            DJISubModuleUpgradeState_RefreshFirmwareError           = 12, //刷入固件失败
            DJISubModuleUpgradeState_LoadFirmwreToMemoryError       = 13, //加载固件到内存失败
            DJISubModuleUpgradeState_AccessFileSystemError          = 14, //访问文件系统失败
            DJISubModuleUpgradeState_WirteFileError                 = 15, //写文件失败
            DJISubModuleUpgradeState_ExtractFirmwareError           = 16, //解压固件失败
        } DJISubModuleUpgradeState;
        
        typedef enum : uint8_t {
            DJIUpgradeSetActionType_Cancel          = 0,
            DJIUpgradeSetActionType_Start           = 1,
            DJIUpgradeSetActionType_Pause           = 2,
            DJIUpgradeSetActionType_Terminate       = 3,
            DJIUpgradeSetActionType_StopAutoPush    = 4, //升级进度到100%结束时可以告知飞控停止推送
            DJIUpgradeSetActionType_Reboot          = 5,
        } DJICommonUpgradeSetActionType;

#pragma pack(1)
// Req cfg File
        typedef struct
        {
            DJICommonConfigFileType req_file_type;//请求文件类型
            uint32_t offset;                      //文件的偏移
            //请求的数据长度，0xFFFFFFFF(-1) 表示请求到文件结尾
            uint32_t data_length;
        } DJIGetConfigFileReqStruct;
        
        typedef struct
        {
            uint32_t data_length;     //数据长度
            uint32_t left_length;     //剩余长度
            uint8_t data[0];          //收到的实际数据
        } DJIGetConfigFileRspStruct;
        
// Enter Upgrade Mode
        typedef struct
        {
            uint8_t m_encryption_type;
            uint8_t m_reserved[8];
        } DJICommonEnterUpgradeModeReqStruct;
        
        typedef struct
        {
            uint8_t support_v1:1;  //V1协议升级
            uint8_t support_ftp:1; //FTP 升级
            uint8_t transfer_option_reserve:6;
            uint8_t support_serial_upgrade:1;   //是否允许串行升级
            uint8_t support_parallel_upgrade:1; //是否允许并行升级
            uint8_t support_tar_upgrade:1;      //是否使用tar打包升级
            //是否支持数据拷贝升级方式，一般是1860数据文件更新
            uint8_t support_data_copy_upgrade:1;
            uint8_t upgrade_option_reserve:4;
        } DJICommonEnterUpgradeModeRspStruct;
        
        typedef struct
        {
            uint8_t req_status;
        } DJICommonStatusReqStruct;
        
        typedef struct{
            uint8_t minorVersion:4; //次要版本号
            uint8_t majorVersion:4; //主要版本号
            //每一位表示一种状态
            //[0] – 0表示正常模式，1表示loader模式
            //[1] – 0表示已经重新上电，1升级后未重新上电
            uint32_t status;
        } DJICommonStatusStruct;
        
        typedef struct
        {
            uint8_t m_encryption_type;
            uint32_t m_firmware_size;
            uint8_t m_reserved[6];
            uint8_t transfer_by_v1:1;
            uint8_t transfer_by_ftp:1;
            uint8_t transfer_type_reserve:6;
            uint8_t serial_upgrade:1;
            uint8_t parallel_upgrade:1;
            uint8_t upgrade_with_tar:1;
            uint8_t upgrade_copy_data:1;
            uint8_t upgrade_type_reserve:4;
        } DJICommonUpgradeReqReceiveFirmwareStruct;

        typedef struct {
            union {
                struct{
                    uint16_t frag_lenth;
                    uint8_t reserve[68];
                };
                struct{
                    uint8_t ip[4];
                    uint16_t port;
                    char path[64];
                };
            };
        } DJICommonUpgradeReqReceiveFirmwareV1RspStruct;
        
        typedef struct {
            uint32_t ip;
            uint16_t port;
            uint8_t file_path[64];
        } DJICommonUpgradeReqReceiveFirmwareFTPRspStruct;
        
// Send Firmware Data
        typedef struct
        {
            uint8_t m_encryption_type;
            uint32_t m_block_number;
            uint16_t m_block_size;
            uint8_t m_block_data[0];
        } DJICommonSendFirmwareDataStruct;
        
// Send Common File
        //请求的基本结构体
        typedef struct {
            DJICommonFileTransferSubCommand sub_command; //子命令
            uint8_t sub_command_body[0]; //子命令内容
        } DJICommonFileTransferReqBody;
        
        
        //请求接收文件子命令的结构体，对应DJICommonFileTransferSubCommand_Request
        //由两部分组成，第一部分用于兼容旧协议，第二部分是新协议扩展
        //a. 请求接收文件子命令的结构体，第一部分内容，兼容旧协议
        typedef struct {
            uint32_t file_size;
            uint8_t file_name_length;
            char file_name[0];
        } DJICommonFTReqBaseBody;
        
        //b. 请求接收文件子命令的结构体，第二部分内容，新协议扩展
        typedef struct {
            uint8_t file_type; //文件类型，参照 `DJICommonFileTransferFileType`
            uint8_t info_length; //扩展信息数据长度
            uint8_t info_data[0]; //扩展信息内容
        } DJICommonFTReqExtBody;
        
        //c. 请求接收文件子命令回包
        typedef struct {
            uint16_t pack_size; //每次发数据的分片大小
            uint16_t window_size; //滑动窗口大小
            DJICommonFileTransferVerifyMethod verify_method; //校验数据方法
            DJICommonFileTransferProtocolType protocol_type; //回包方法
        } DJICommonFTReqRspBody;
        
        //发送数据片子命令请求，对应DJICommonFileTransferSubCommand_Send
        //a. 发送数据片子命令请求
        typedef struct {
            uint32_t pack_sequence; //分片序号
            uint8_t data[0]; //分片内容
        } DJICommonFTSendReqBody;
        
        //b. 发送数据片子命令回包
        typedef struct {
            uint32_t current_ack_sequence;
            uint32_t current_receive_window_index;
        } DJICommonFTSendRspBody;
        
        typedef struct {
            uint32_t location;
            uint32_t length;
        } DJICommonFTSendLostRange;
        
        typedef struct {
            uint32_t current_receive_window_index;
            DJICommonFTSendLostRange lost_list[0];
        } DJICommonFTSendRspLostListBody;
        
        //验证数据子命令请求
        typedef struct {
            uint8_t verify_data[0];
        } DJICommonFTVerifyReqBody;

// Finish Firmware Data Send
        //该结构体实际没用，数据均为0进行发送即可
        typedef struct
        {
            uint8_t m_encryption_type;
            uint8_t mMD5[16];
        } DJICommonFirmwareDataSendFinishReqBody;
        
// Reboot Devicce
        //有些设备升级完成需要app触发重启设备
        typedef struct{
            uint8_t encryption_type; //加密类型, 目前没有实现。
            uint8_t reset_type; // 0 = Warm Reset; 1 = Cold Reset; 其他 ＝ 保留。
            uint32_t reset_delay_time; //重启延迟时间（即执行重启操作前等待的时间长度。单位：毫秒。LSB在前，MSB在后)。
            uint8_t remains[8]; //保留 注：可以用于握手认证，防止恶意进入升级模式
        } DJICommonRebootDeviceReqBody;

// Get Version
        //version list的方式要通过这种方式获取各模块版本信息
        typedef struct{
            uint8_t minor_version:4; //次版本号
            uint8_t major_version:4; //主版本号 , 0x10表示支持的通信协议版本为v1.0。
            //硬件版本（CHAR8型字串，以"\0"作为结束符），包含模块类型、硬件版本号等信息。
            uint8_t hardware_version[16];
            //Loader版本（LSB在前，MSB在后）注：0xAABBCCDD表示的版本为：AA.BB.CC.DD。
            uint8_t loader_version[4];
            //固件版本，包含主版本号、次版本号和编译次数等信息。（LSB在前，MSB在后）息。注：
            //1）App只显示AA.BB即可。
            //2）三段的固件版本，可以只使用AA.BB.CC，DD保留并以0来填充；或者将CC和DD合并起来。如相机版本v1.0.2028可以表示为0x010007EC
            uint8_t firmware_version[4];
            
            //所支持的命令集
            uint32_t is_support_common:1;
            uint32_t is_support_special:1;
            uint32_t is_support_camera:1;
            uint32_t is_support_mc:1;
            uint32_t is_support_gimbal:1;
            uint32_t is_support_center:1;
            uint32_t is_support_rcc:1;
            uint32_t is_support_wifi:1;
            uint32_t is_support_DM368:1;
            uint32_t is_support_OFDM:1;   //是否支持OFDM命令集，以下同上
            uint32_t reserved:20;  //保留字段
            uint32_t is_support_safe_upgrade:1; //是否支持安全升级
            uint32_t is_mass_product:1;//1代表是量产飞机，经过加密，0是试产，没有加密的
        } DJICommonGetVersionRspStruct;

// Upgrade State Push
        typedef struct {
            uint8_t left_time; //等待用户确认剩余升级时间，单位秒
            uint8_t reserve;  //保留
        } DJICommonUpgradeUserConfirmInfo;
        
        typedef struct {
            uint8_t upgrade_progress;    //升级进度
            uint8_t description_count:5; //当前固件描述项数目
            uint8_t on_going_step_index:3; //当前固件升级到第几轮
        } DJICommonUpgradeOnGoingInfo;

        typedef struct {
            DJIUpgradeEndReason end_reason; //升级失败原因
            uint8_t description_count; //当前固件描述项数目
        } DJICommonUpgradeEndInfo;
        
        typedef struct {
            uint8_t progress;
            DJIUpgradeCopyDataState state;
        } DJICommonCopyDataInfo;

        typedef struct {
            uint8_t module_id; //模块id
            uint8_t firmware_type;//固件类型
            uint32_t firmware_version;//固件版号
            DJISubModuleUpgradeState firmware_upgrade_state;//固件升级状态
            uint8_t upgrade_process;//固件升级进度
        } DJICommonUpgradePushStatusDescribeInfo;

        //固件升级请求推送命令，结构体是变长结构体，所以结构体长度不定
        typedef struct {
            DJIFirmwarePushUpgradeState upgradeState;//升级阶段
            union {
                DJICommonUpgradeUserConfirmInfo confirm_info;
                DJICommonUpgradeOnGoingInfo on_going_info;
                DJICommonUpgradeEndInfo end_info;
                DJICommonCopyDataInfo copy_data_info;
            };
            DJICommonUpgradePushStatusDescribeInfo upgrade_description[0]; //固件描述项
        } DJICommonUpgradePushStatusInfoRspBody;
        
#pragma pack()
        
    }
}


#endif /* dji_common_pack_manager_upgrade_structs_h */
