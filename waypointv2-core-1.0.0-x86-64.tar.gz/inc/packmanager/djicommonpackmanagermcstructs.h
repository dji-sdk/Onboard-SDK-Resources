//
//  djicommonpackmanagermcstructs.h
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 04/05/2018.
//

#ifndef djicommonpackmanagermcstructs_h
#define djicommonpackmanagermcstructs_h

#include <math.h>
#include <stdint.h>

namespace dji {
	namespace waypointv2 {

#pragma pack(1)

typedef struct{
	double longitude;   //经度（弧度）
	double latitude;    //纬度（弧度）
	
	//以上共16字节
	//float altitude;     //高度（1m）
	int16_t barometerHeight;    //气压计高度(0.1m) relative to home point.
	int16_t speedX;     //对地X轴速度(0.1m/s)
	int16_t speedY;     //对地Y轴速度(0.1m/s)
	int16_t speedZ;     //对地Z轴速度(0.1m/s)
	int16_t pitch;      //俯仰轴角度，(0.1度，有效范围+-180.0度)
	int16_t roll;        //横滚轴角度，(0.1度，有效范围+-180.0度)
	int16_t yaw;        //朝向角度，(0.1度，有效范围+-180.0度)
	
	//以上共30字节
	/*********控制模式*********/
	uint8_t mode:7;       //控制模式 ,DJIMCModeType
	uint8_t failsafe:1;    //遥控器是否失控
	uint8_t latestCmd;      //最后一条执行的App命令。
	
	/*********功能状态提示******以上共32字节**/
	bool canIOCWork:1;    //智能航向功能是否可开启
	uint8_t groundOrSky:2;    //飞机是否在地上，0 ＝ 不能判断飞机在地上，1 = 飞机在地上，2 = 飞机在空中 DJIAircraftPosition
	bool isMotorUp:1;   //电机是否起转
	bool isUltrasonicUsed:1;    //超声波是否工作
	
	uint8_t goHomeState:3; // 返航阶段状态 (DJIGoHomeState)
	//  0 = 返航准备中（gohome standby）
	//  1 = 返航预备上升（gohome preascending）
	//  2 = 返航航向角度调整（gohome align）
	//  3 = 返航自主巡航（gohome cruise）
	//  4 = 返航下降（gohome descending）
	//  5 = 返航完成（gohome finish）
	
	//以上共33字节
	bool isVisionUsed:1;    //视觉是否工作
	uint8_t batteryWarning:2;   //0 = 正常，1 = 一级报警，2 = 二级报警
	bool isHorseProtectOpen:1;  //脚架保护功能是否打开
	bool isIMUHeatFinished: 1; //预热是否完成
	uint16_t modeChannel:2; //模式通道档位（遥控器控制 DJIMCModeChannelType） 2 = GPS模式 1 = 姿态模式 0 = 功能通道IOC。3 = 信号丢失
	uint16_t isGPSValid:1;  //GPS的功能是否可用
	
	/*********错误提示**********以上共34字节**/
	bool isCompassError:1;  //指南针错误
	bool isUltrasoudLock:1;  //超声波
	uint8_t gpsSignalLevel:4; //主控版本6或以后新增的功能。
	uint8_t batteryType: 2;   //电池类型，0未知，1非智能，2智能
	
	//以上共35字节
	uint8_t acceOutRange:1;     //加速度计超量程
	uint8_t aircraftVibrate:1;  //飞行器振动
	uint8_t barometerDeadInAir:1;    //气压计空中卡死 或 电调短路（version11之后）
	uint8_t motorBlocked:1;   //电机堵转。
	uint8_t notEnoughForce:1;   //飞行器没有足够的动力
	uint8_t noBladeOnMotor:1;   //电机射桨
	uint8_t isGoHomeHeightModified:1; // 航高度修改状态推送，只推送一次
	uint8_t isOutOfDistanceLimit:1; // 是否飞出了限飞圈
	
	//以上共36字节
	uint8_t gpsNum;     //卫星数
	uint8_t flightActionReason;   //返航原因 DJIFlightActionReason
	
	union{
		struct{
			//hide version <= 25
			uint8_t takeoffFailReason:7;  //起飞失败原因
			bool isTakeoffFail:1;    //是否起飞失败(从0变为1的时候提示相关的起飞失败)
		};
		uint8_t takeoffFailReasonExt; //hide version >= 26, 使用整个byte
	};
	
	uint8_t nonGPSModeReason:4; //进入非GPS模式的原因 DJINonGPSReason
	uint8_t isWPInLowerAltitudeLimitedMode:1; // Way Point 进入限低模式
	uint8_t isShowQuickCircleTips:1;//提示用户quickcircle
	uint8_t isShowNearGroundTips:1;//提示是否触发近地保护
	uint8_t isShowTripodErrTips:1; //是否提示用户脚架异常，注意降落环境安全
	
	//以上共40字节
	uint8_t powerPercentReserve;    //电池电量保留字段（准备删除）
	uint8_t visionHieght;   //视觉和超声波测得的飞机高度，单位0.1米，超声波工作时该数据才有意义
	uint16_t lastFlightTime;   //启动至今的时间
	uint8_t startUpTimes;  //启动次数
	
	//以上45字节
	uint8_t batteryWarningValueReserve:7;  //低电压报警数值 （移动到DJIElectricityDataStruct）中，新版本开始禁用此字段
	uint8_t isBatteryWarningEnableReserve:1;   //是否开启低电压报警 （移动到DJIElectricityDataStruct）中，新版本开始禁用此字段
	uint8_t seriousBatteryWarningValueReserve:7;   //严重低电压报警数值（移动到DJIElectricityDataStruct）中，新版本开始禁用此字段
	uint8_t isSeriousBatteryWarningEnableReserve:1;    //是否开启严重低电压报警（移动到DJIElectricityDataStruct）中，新版本开始禁用此字段
	uint8_t versionC;   //版本号A.B.C.D中的C版本号，用于匹配协议，当协议不匹配时,进行相关的处理(进行保护)(现在仅提示)
	uint8_t droneType;  //飞机的类型 DJIDroneType
	uint8_t imuInitFailedReason;   //IMU初始化失败原因 DJIIMUInitFaileReason
	
	//以上50字节
	uint8_t motorStopReason;   //电机关闭原因
	uint8_t motorStartErrorCode; //电机无法启动原因
	uint8_t sdkControlDevice; //当前SDK控制者 DJIMCSDKControllerDeviceType, 需要主控版本11以上
	
}DJIOsdStruct;

typedef struct
{
	uint32_t version :2;        //版本，当前为第一版 1
	uint32_t all_gyr_acc :1;    //gyr_acc 这一类设备是否有异常 1=异常
	uint32_t all_mag :1;        //mag     这一类设备是否有异常 1=异常
	uint32_t all_baro :1;       //baro    这一类设备是否有异常 1=异常
	uint32_t all_gps :1;        //gps     这一类设备是否有异常 1=异常
	uint32_t all_ns :1;         //ns      这一类设备是否有异常 1=异常
	uint32_t reserved1 :5;      //
	
	uint32_t busy_gyr_acc :1;   //gyr_acc 正在使用的设备是否有异常 1=异常
	uint32_t busy_mag :1;       //mag     正在使用的设备是否有异常 1=异常
	uint32_t busy_baro :1;      //baro    正在使用的设备是否有异常 1=异常
	uint32_t busy_gps :1;       //gps     正在使用的设备是否有异常 1=异常
	uint32_t busy_ns :1;        //ns      正在使用的设备是否有异常 1=异常
	uint32_t reserved2 :5;      //
	
	uint32_t switch_gyr_acc :1; //gyr_acc 每翻转一次表示正在使用的设备发生了改变
	uint32_t switch_mag :1;     //mag     每翻转一次表示正在使用的设备发生了改变
	uint32_t switch_baro :1;    //baro    每翻转一次表示正在使用的设备发生了改变
	uint32_t switch_gps :1;     //gps     每翻转一次表示正在使用的设备发生了改变
	uint32_t switch_ns :1;      //ns      每翻转一次表示正在使用的设备发生了改变
	uint32_t reserved3 :5;      //
} DJIFCRedundancyStatus;

typedef struct{
	double longitude;   //GPS Home点经度(弧度)
	double latitude;    //GPS Home点纬度(弧度)
	float altitude;     //起飞海拔高度(单位：0.1米) height above sea-level
	//20字节
	
	uint16_t recordCount:1; //home点是否被记录，0为没有，1为有
	uint16_t goHomeMethod:1;    //0 = 普通返航，1 ＝ 固定高度返航
	uint16_t goHomeHead:1;  //0 = 机尾朝向Home点返航，1 = 机头朝向Home点返航
	uint16_t dynaimcHomePointOpen:1;    //动态Home点功能是否开启，0 = 未开启 1 = 已经开启
	
	uint16_t isNearDistanceLimit:1; //是否接近设定的限制半径
	uint16_t isNearHeightLimit:1;   //是否接近设定的限制高度
	uint16_t isMultipleModeOpen:1; //是否开放高级模式
	uint16_t reserve1:1;
	
	//21字节
	uint16_t compassState:2;    //指南针校准状态指示 0 = 校准阶段一, 1 = 校准阶段二, 2 = 校准成功, 3 = 校准出错
	uint16_t isCompassAdjust:1; //指南针是否进入校准状态 0 = 未进入校准 1 = 进入校准状态
	uint16_t isBeginnerMode:1;  //是否新手模式
	uint16_t isIOCOpen:1;   //IOC功能是否开启
	uint16_t IOCMode:3; //0未进入IOC功能，1 = 方向锁定 2 = 热点环绕 3 = home点锁定
	
	//22字节
	uint16_t goHomeHeight;  //固定返航的高度(范围20米到500米)
	int16_t iocCourseLockAngle;   //航向锁定角度   单位是：0.001 弧度
	
	//26字节
	uint8_t flightRecordSDState;   //飞行记录SD卡状态，0 正常，1 格式化中，2 格式化失败 ，（从 1 到 0 表示格式化成功）
	uint8_t recordSDCapacityPercent;   // 飞行记录仪剩余容量百分比
	uint16_t recordSDLeftTime;          // 飞行记录仪剩余记录时间百分比
	
	//30字节
	uint16_t currentFlightRecordIndex;  // 飞行记录仪当前记录文件索引
	
	//32字节
	uint32_t simulatorOpen:1;   //是否开启了模拟模式
	uint32_t navigationOpen:1;  //是否开启了智能飞行模式
	uint32_t shakeInAir:1;
	uint32_t impactInAir:1;
	uint32_t impactOnGrd:1;
	uint32_t randomFly:1;
	uint32_t flyAway:1;
	uint32_t heightCtrlFail:1;
	uint32_t tiltCtrlFail:1;
	uint32_t headCtrlFail:1;
	uint32_t altitudeWarnning:1;
	uint32_t motorUnbalance:1;
	uint32_t brokenOar:1; //断桨
	uint32_t single_aerial_status:1;//单人飞手模式
	uint32_t gale_warning:1; //大风警告, hideVersion >= 16
	uint32_t msd_mode_flag:1;
	uint32_t gohome_paused:1;
	uint32_t adv_gohome_mode:1;
	uint32_t adv_landing_mode:1;
	uint32_t close_go_home_mode:1;
	uint32_t gale_serious_warning:1; //风速很大不适合
	uint32_t paddle_check:2;//浆叶情况 0正常， 1高原使用平原桨 2平原使用高原桨叶
	uint32_t compass_install_err:1;//指南针安装错误
	uint32_t imu_install_err:1;//imu安装错误
	uint32_t esc_temperature_high:1;//电调温度过高,hide version>=23
	uint32_t prop_sys_current_large:1;//桨叶结冰监测
	uint32_t at_least_one_esc_disconnected:1;//至少一个电调无连接
	uint32_t gps_yaw_error:1;//gps航向异常
	uint32_t prop_cover_need_check:1;//桨保护罩设置需要确认,hiddenVer >=28
	uint32_t gps_blocked_by_gimbal:1;//主GPS信号被云台遮挡
	uint32_t protection_cover:1;  //桨保护罩识别开关 0 未检出 1 检测到
	
	//36字节
	uint8_t limit_height_reason:5; //当前限高的原因 DJIMCLimitHeightReason
	uint8_t is_limit_height_releative_height:1; //是否使用相对（超声波）限高
	uint8_t reserved3:2;
	
	//37字节
	float limit_height_meter; //限高高度（米）
	uint32_t motorEscmState;//电调状态，4*8bit,最多8个电机
	//45字节
	uint8_t touchdown_confirm_limit_height; //wm220 开始，限低降落高度，0.1米为单位
	//46字节
	DJIFCRedundancyStatus redunancyStatus; // 冗余系统状态
	uint16_t redunancyAction;
	uint8_t productId[16];
	uint8_t windSpeed; // 风速 0.1m/s
}DJILowFreqOsdStruct;
		
#pragma pack()
	}
}

#endif /* djicommonpackmanagermcstructs_h */
