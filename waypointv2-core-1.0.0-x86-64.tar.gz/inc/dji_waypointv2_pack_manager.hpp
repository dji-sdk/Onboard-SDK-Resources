//
//  dji_waypointv2_pack_manager.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 06/07/2018.
//

#ifndef dji_waypointv2_pack_manager_hpp
#define dji_waypointv2_pack_manager_hpp

#include <packmanager/djicommonpackmamanger.hpp>

namespace dji {
	namespace waypointv2 {
		using namespace common;
		class  PackManager : public IPackManager {
		public:
			virtual void SendPack(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data,
								  int req_data_length, int retry_time, int retry_interval, PackRspCallback rsp_cb, uint16_t seq_num = 0) override;
			virtual bool DirectSendPack(uint64_t device_id, PackType type, DJIPackCmdTypeStruct cmd_type, DJIPackSenderStruct sender, DJIPackSenderStruct receiver, const void *req_data, int req_data_length, int retry_time, int retry_interval) override;
			virtual int RegisterPushPackInfoListener(PackType type, PackDataSourceCallback cb) override;
			virtual void unRegisterPushPackInfoListener(PackType type, int register_id) override;
		};
	}
}


#endif /* dji_waypointv2_pack_manager_hpp */
