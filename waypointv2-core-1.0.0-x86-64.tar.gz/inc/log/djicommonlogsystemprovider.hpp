//
//  djicommonlogsystemprovider.hpp
//  DJIWaypointV2Core
//
//  Created by Tim Lee on 03/05/2018.
//

#ifndef djicommonlogsystemprovider_hpp
#define djicommonlogsystemprovider_hpp

#include <stdio.h>
#include <memory>
#include "djicommoncommondefines.hpp"

#if defined (__linux__)
#include <cstring>
#endif

namespace dji {
	namespace common {
		
		class LogCenterProvider {
		public:
			LogCenterProvider(const LogCenterProvider&) = delete;
			LogCenterProvider& operator=(const LogCenterProvider&) = delete;
			
			void DebugLog(const char *fmt,...);
			void INFOLog(const char *fmt,...);
			void ERRORLog(const char *fmt,...);
			
			void SetDebugLogHandle(LogActionHandle handle);
			void SetInfoLogHandle(LogActionHandle handle);
			void SetErrorLogHandle(LogActionHandle handle);
			
			static LogCenterProvider& GetInstance() {
				static LogCenterProvider instance;
				return instance;
			}
		private:
			LogCenterProvider() {};
			~LogCenterProvider() {};
		private:
			std::string string_format(const char* fmt, va_list argp);
			LogActionHandle debug_handle_;
			LogActionHandle info_handle_;
			LogActionHandle error_handle_;
		};
	}
}

#endif /* djicommonlogsystemprovider_hpp */
